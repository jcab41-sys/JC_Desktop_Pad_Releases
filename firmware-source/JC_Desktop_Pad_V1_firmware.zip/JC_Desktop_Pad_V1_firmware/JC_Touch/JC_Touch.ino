// HCD-S3-TOUCH (liaison USB ou Bluetooth LE) : un seul code pour les deux versions du pad.
//   V1 (JC_BOARD 1) : ESP32-S3 mini + écran ILI9341 2,8" 320x240, tactile résistif XPT2046 — firmware 0.7.x
//   V2 (JC_BOARD 2) : Freenove ESP32-S3-WROOM (8 Mo flash, 8 Mo PSRAM) + écran LAFVIN 4,0" ST7796S 480x320,
//                     tactile résistif XPT2046 — firmware 2.x
// Choisir la version ci-dessous avant de compiler.
#ifndef JC_BOARD
#define JC_BOARD 2
#endif
// Code complet intégrant tous les correctifs

#include <Arduino.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <ArduinoJson.h>
#include <Adafruit_NeoPixel.h>
#include <driver/gpio.h>
#include <driver/rtc_io.h>
#include <esp_sleep.h>
#include "tusb.h"
static bool usbHostPresent();      // définie après usbMouse
#include <USB.h>
#include "esp32-hal-tinyusb.h"
#include <USBHIDKeyboard.h>
#include <USBHIDMouse.h>
#include <USBHIDConsumerControl.h>
#include <vector>
#include <nvs.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#if JC_BOARD == 2
#include <WiFi.h>
#endif
#include <BLEHIDDevice.h>
#if defined(CONFIG_NIMBLE_ENABLED)
#include "host/ble_gap.h"
#include "host/ble_gatt.h"
#include "host/ble_hs_mbuf.h"
#endif

#define LGFX_USE_V1
#include <LovyanGFX.hpp>

// Types utilisés dans les signatures de fonctions
enum Mode { M_MENU, M_PAD, M_VOL, M_GAMES, M_JUMP, M_SNAKE, M_WEATHER, M_SHORT };   // jeux et météo : pad V2 seulement
struct Slot {
  bool used = false;
  bool folder = false;
  bool isMode = false;
  String label;
  String icon;
  uint32_t color = 0x34495e;
  JsonVariantConst item;
};

// ---------------------------------------------------------------- Broches ---
// Écran (SPI partagé avec le tactile)
static const int PIN_SCK  = 12;
static const int PIN_MOSI = 11;
static const int PIN_MISO = 13;
static const int PIN_TFT_CS  = 10;
#if JC_BOARD == 2
// Fils de l'ampli (BCLK 40, LRC 41, DIN 15) mis à 0 le plus tôt possible : avant setup(), pendant le démarrage
// (test de la PSRAM, etc.), ils flottent et l'ampli fait « bzzz ». Ce constructeur passe avant tout le reste.
#include <driver/gpio.h>
__attribute__((constructor(101))) static void earlyQuietAmp() {
  const gpio_num_t pins[] = {GPIO_NUM_40, GPIO_NUM_41, GPIO_NUM_15};
  for (gpio_num_t p : pins) { gpio_reset_pin(p); gpio_set_direction(p, GPIO_MODE_OUTPUT); gpio_set_level(p, 0); }
}
#endif
static const int PIN_TFT_DC  = 9;
static const int PIN_TFT_RST = -1;   // RESET relié au 3V3 (V1 et V2)
#if JC_BOARD == 2
static const int PIN_TOUCH_CS = 39;  // V2 : T_CS sur 39, pour libérer le GPIO 7 (entrée analogique) pour la batterie
static const int PIN_BATT = 7;       // V2 : tension de la batterie par un pont de 2 x 100 kΩ (+ 100 nF vers GND)
#else
static const int PIN_TOUCH_CS = 7;
#endif
static const int PIN_BL = 5;         // Rétro-éclairage

// Commandes analogiques / numériques
static const int PIN_POT    = 1;     // Potentiomètre - ADC1
static const int PIN_JOY_X  = 2;     // Joystick X - ADC1
static const int PIN_JOY_Y  = 4;     // Joystick Y - ADC1
static const int PIN_JOY_SW = 6;     // Clic joystick (vers GND)
static const int PIN_CHRG = 42;              // détection de charge : plot CHRG du TP4056 via 470 Ω (bas = en charge)
static const int PIN_NAV_BTN = 3;            // bouton-poussoir optionnel vers GND : active/désactive la navigation au joystick
#if JC_BOARD == 2
// Sur la carte Freenove, TX (43) et RX (44) sont reliés à la puce USB-série : touche 3 et ruban déplacés.
static const int PIN_KEY[3] = {8, 18, 17};   // 3 touches sensitives TTP223 (sortie OUT, active à l'état haut)
static const int PIN_LEDS   = 47;    // Données du ruban WS2812
#else
static const int PIN_KEY[3] = {8, 18, 43};   // 3 touches physiques (vers GND)
static const int PIN_LEDS   = 44;    // Données du ruban WS2812 (RX)
#endif

// LEDs d'état
static const int PIN_LED_KEY[3] = {14, 16, 21};   // LEDs individuelles sous touches
static const int PIN_LED_STATUS = 38;             // Voyant vert "module allumé"

// Ruban WS2812
static const int LED_COUNT = 4;
static const int LED_BAR_IX = 0;

// Le nom distingue les deux cartes pour JCharles desktop (choix du firmware à installer, taille de l'aperçu).
// La V2 est numérotée 2.x : un ancien logiciel ne lui proposera jamais le firmware de la V1 (0.7.x).
#if JC_BOARD == 2
static const char* FW_NAME = "HCD-S3-TOUCH-V2";
static const char* FW_VERSION = "2.4.3";
#else
static const char* FW_NAME = "HCD-S3-TOUCH";
static const char* FW_VERSION = "0.9.1";
#endif

// ---------------------------------------------------------- Lecture ADC stable ---
static int readADC(int pin) {
  analogRead(pin); // Commutation à vide du multiplexeur ADC
  delayMicroseconds(20);
  int sum = 0;
  for (int i = 0; i < 8; i++) {
    sum += analogRead(pin);
  }
  return sum >> 3; // Moyenne glissante sur 8 échantillons
}

// ------------------------------------------------------------------ Écran ---
// Sens de l'écran (paysage) : V2 = 3 (connecteur à gauche, comme sur le pad monté), V1 = 1 ; « flip » ajoute 180°.
static int screenRotation();
static bool uiReady = false;             // fin de setup() : l'écran peut être redessiné
// V2 : si les couleurs s'affichent en négatif (fond blanc au lieu de noir), passer à true.
static const bool PANEL_INVERT = false;
// Tactile résistif XPT2046 avec seuil de pression réglable (la bibliothèque impose une pression assez forte).
// zMin bas = écran plus sensible ; trop bas = touchers fantômes. Réglage « touchz » dans le logiciel.
class TouchXPT : public lgfx::Touch_XPT2046 {
public:
  uint32_t zMin = 160;
  uint_fast8_t getTouchRaw(lgfx::touch_point_t* tp, uint_fast8_t count) override {
    if (!_inited || count == 0) return 0;
    tp->size = 0;
    uint8_t data[57];
    memset(data, 0, 8);
    data[0] = 0x91; data[2] = 0xB1; data[4] = 0xD1; data[6] = 0xC1;
    data[56] = 0x80;
    memcpy(&data[8], data, 8);
    memcpy(&data[16], data, 16);
    memcpy(&data[32], data, 24);
    lgfx::spi::beginTransaction(_cfg.spi_host, _cfg.freq, 0);
#if JC_BOARD == 2
    // Sur ces modules ST7796, l'écran reste à l'écoute pendant la lecture du tactile : les octets du tactile
    // arrivaient comme des points en haut de la dernière zone dessinée (traits rouges, traînée de Bip).
    // On envoie d'abord la commande NOP à l'écran : les octets qui suivent sont alors ignorés.
    {
      static const uint8_t nop = 0x00;
      lgfx::gpio_lo(PIN_TFT_DC);
      lgfx::gpio_lo(PIN_TFT_CS);
      lgfx::spi::writeBytes(_cfg.spi_host, &nop, 1);
      lgfx::gpio_hi(PIN_TFT_CS);
      lgfx::gpio_hi(PIN_TFT_DC);
    }
#endif
    lgfx::gpio_lo(_cfg.pin_cs);
    lgfx::spi::readBytes(_cfg.spi_host, data, 57);
    lgfx::gpio_hi(_cfg.pin_cs);
    lgfx::spi::endTransaction(_cfg.spi_host);
    size_t ix = 0, iy = 0, iz = 0;
    uint_fast16_t xt[7], yt[7], zt[7];
    for (size_t j = 0; j < 7; ++j) {
      auto d = &data[j * 8];
      int x = (d[5] << 8 | d[6]) >> 3;
      int y = (d[1] << 8 | d[2]) >> 3;
      int z = 0x3200 + y - x + (((d[3] << 8 | d[4]) - (d[7] << 8 | d[8])) >> 1);
      if (x > 128 && x <= 3968) xt[ix++] = x;
      if (y > 128 && y <= 3968) yt[iy++] = y;
      if (z > 0) zt[iz++] = z;
    }
    if (ix < 3 || iy < 3 || iz < 3) return 0;
    std::sort(xt, xt + ix); std::sort(yt, yt + iy); std::sort(zt, zt + iz);
    tp->x = xt[ix >> 1];
    tp->y = yt[iy >> 1];
    uint32_t z = zt[iz >> 1];
    tp->size = z >> 4 ? z >> 4 : 1;
    return z >= zMin ? 1 : 0;
  }
};

class LGFX : public lgfx::LGFX_Device {
public:
  TouchXPT& touchDev() { return _touch; }
  void setWriteFreq(uint32_t hz) { auto c = _bus.config(); c.freq_write = hz; _bus.config(c); }
#if JC_BOARD == 2
  lgfx::Panel_ST7796 _panel;
#else
  lgfx::Panel_ILI9341 _panel;
#endif
  lgfx::Bus_SPI _bus;
  lgfx::Light_PWM _light;
  TouchXPT _touch;

public:
  LGFX() {
    {
      auto c = _bus.config();
      c.spi_host = SPI2_HOST;
      c.spi_mode = 0;
      c.freq_write = 20000000;          // 20 MHz ; la V2 lit le réglage « spimhz » avant d'allumer l'écran (setWriteFreq)
      c.freq_read = 16000000;
      c.pin_sclk = PIN_SCK;
      c.pin_mosi = PIN_MOSI;
      c.pin_miso = PIN_MISO;
      c.pin_dc = PIN_TFT_DC;
#if JC_BOARD == 2
      // V2 : pas de DMA. Sur l'ESP32-S3, l'envoi par DMA des images rangées en PSRAM (tuiles, en-tête, jeux)
      // pouvait se bloquer en plein transfert : lignes décalées, couleurs fausses, quelle que soit la vitesse.
      c.dma_channel = 0;
#endif
      _bus.config(c);
      _panel.setBus(&_bus);
    }
    {
      auto c = _panel.config();
      c.pin_cs = PIN_TFT_CS;
      c.pin_rst = PIN_TFT_RST;
#if JC_BOARD == 2
      c.panel_width = 320;
      c.panel_height = 480;
      c.readable = false;               // SDO(MISO) de l'écran non relié : seul T_DO du tactile va sur MISO
      c.invert = PANEL_INVERT;
#else
      c.panel_width = 240;
      c.panel_height = 320;
      c.readable = true;
      c.invert = false;
#endif
      c.rgb_order = false;
      c.bus_shared = true;
      _panel.config(c);
    }
    {
      auto c = _light.config();
      c.pin_bl = PIN_BL;
      c.invert = false;
      c.freq = 44100;
      c.pwm_channel = 7;
      _light.config(c);
      _panel.setLight(&_light);
    }
    {
      auto c = _touch.config();
      c.x_min = 300; c.x_max = 3900;
      c.y_min = 300; c.y_max = 3900;
      c.pin_int = -1;
      c.bus_shared = true;
      c.offset_rotation = 0;
      c.spi_host = SPI2_HOST;
      c.freq = 1000000;
      c.pin_sclk = PIN_SCK;
      c.pin_mosi = PIN_MOSI;
      c.pin_miso = PIN_MISO;
      c.pin_cs = PIN_TOUCH_CS;
      _touch.config(c);
      _panel.setTouch(&_touch);
    }
    setPanel(&_panel);
  }
};

static LGFX lcd;
// Tampon d'image : en PSRAM si la carte en a (la mémoire interne est réservée au Wi-Fi, à l'USB...), sinon en interne.
// (Les défauts d'image de la V2 venaient du tactile, pas de la PSRAM : voir TouchXPT.)
static bool makeSprite(LGFX_Sprite& s, int w, int h) {
  s.setColorDepth(16);
  s.setPsram(psramFound());
  if (s.createSprite(w, h)) return true;
  s.setPsram(!psramFound());
  return s.createSprite(w, h) != nullptr;
}
static Adafruit_NeoPixel strip(LED_COUNT, PIN_LEDS, NEO_GRB + NEO_KHZ800);

// -------------------------------------------------------------------- USB ---
USBHIDKeyboard usbKeyboard;
USBHIDMouse usbMouse;

// Un PC est présent si la carte est énumérée ET que l'endpoint HID se vide encore. Sans détection de VBUS, un câble débranché
// ou un simple chargeur laisse « mounted » à vrai ; mais sans PC, un rapport envoyé n'est jamais lu et l'endpoint reste occupé.
// On envoie donc régulièrement un rapport souris vide (sans effet) et on vérifie qu'il part.
static int dbgM = 0, dbgR = 0; static uint32_t dbgAge = 0;     // affichage de contrôle (mode automatique)
static bool usbHostPresent() {
  static uint32_t lastAlive = 0, lastPing = 0;
  uint32_t n = millis();
  if (!tud_mounted()) { lastAlive = 0; dbgM = 0; dbgR = 0; dbgAge = 0; return false; }
  // Câble débranché (sans détection de VBUS) : plus de trames du PC, le bus passe en « suspendu » mais la carte
  // reste « montée ». En suspendu, la bibliothèque n'envoie pas le rapport de test (elle tente de réveiller le PC),
  // si bien que l'endpoint semblait toujours libre : le mode automatique ne passait jamais en Bluetooth.
  if (tud_suspended()) { dbgM = 1; dbgR = 0; dbgAge = n - lastAlive; return false; }
  if (!lastAlive) { lastAlive = n; lastPing = n; }
  if (tud_hid_ready()) {
    lastAlive = n;
    if (n - lastPing > 700) { lastPing = n; usbMouse.move(0, 0, 0, 0); }
  }
  dbgM = 1; dbgR = tud_hid_ready() ? 1 : 0; dbgAge = n - lastAlive;
  return n - lastAlive < 3000;
}
USBHIDConsumerControl usbConsumer;

// ------------------------------------------------ Liaison HID : USB ou Bluetooth LE
// Le choix se fait dans HCD Studio (page Matériel) ou en maintenant les touches 1 et 2 au démarrage.
// Il est mémorisé ; la carte redémarre quand il change. Le port USB reste toujours actif pour HCD Studio.
static int linkMode = 0;                 // 0 = USB, 1 = Bluetooth LE (mode réellement utilisé)
static uint8_t linkPref = 0;             // choix mémorisé : 0 = USB, 1 = Bluetooth, 2 = automatique (USB si un PC est relié, sinon Bluetooth)
static bool bleOn = false;               // pile Bluetooth démarrée (mode Bluetooth uniquement)
static volatile bool bleConnected = false;
static uint32_t restartAt = 0;
static bool joyLeftHeld = false;          // manche poussé franchement à gauche (après inversions/échange)
static void enterDownloadMode();

static BLEServer* bleServer = nullptr;
static BLECharacteristic* bleInKb = nullptr;
static BLECharacteristic* bleInCons = nullptr;
static BLECharacteristic* bleInMouse = nullptr;

// Clavier (rapport 1, 8 octets), touches multimédia (rapport 2, 2 octets), souris (rapport 3, 5 octets)
static const uint8_t BLE_HID_DESC[] = {
  0x05,0x01, 0x09,0x06, 0xA1,0x01, 0x85,0x01,
  0x05,0x07, 0x19,0xE0, 0x29,0xE7, 0x15,0x00, 0x25,0x01, 0x75,0x01, 0x95,0x08, 0x81,0x02,
  0x95,0x01, 0x75,0x08, 0x81,0x01,
  0x95,0x05, 0x75,0x01, 0x05,0x08, 0x19,0x01, 0x29,0x05, 0x91,0x02,
  0x95,0x01, 0x75,0x03, 0x91,0x01,
  0x95,0x06, 0x75,0x08, 0x15,0x00, 0x25,0x65, 0x05,0x07, 0x19,0x00, 0x29,0x65, 0x81,0x00,
  0xC0,
  0x05,0x0C, 0x09,0x01, 0xA1,0x01, 0x85,0x02,
  0x15,0x00, 0x26,0xFF,0x03, 0x19,0x00, 0x2A,0xFF,0x03, 0x75,0x10, 0x95,0x01, 0x81,0x00,
  0xC0,
  0x05,0x01, 0x09,0x02, 0xA1,0x01, 0x85,0x03, 0x09,0x01, 0xA1,0x00,
  0x05,0x09, 0x19,0x01, 0x29,0x05, 0x15,0x00, 0x25,0x01, 0x95,0x05, 0x75,0x01, 0x81,0x02,
  0x95,0x01, 0x75,0x03, 0x81,0x01,
  0x05,0x01, 0x09,0x30, 0x09,0x31, 0x09,0x38, 0x15,0x81, 0x25,0x7F, 0x75,0x08, 0x95,0x03, 0x81,0x06,
  0x05,0x0C, 0x0A,0x38,0x02, 0x15,0x81, 0x25,0x7F, 0x75,0x08, 0x95,0x01, 0x81,0x06,
  0xC0, 0xC0
};

// journal Bluetooth (affiché dans le logiciel par HCD_LOG, et à l'écran) : 1 connexion, 2 déconnexion,
// 3 appairage réussi, 4 appairage refusé
static volatile uint8_t bleEvt = 0;
static volatile int bleEvtArg = 0;
class HcdBleCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer*) override {
    bleConnected = true;
    bleEvt = 1;
    BLEDevice::startAdvertising();       // reste visible : le logiciel du PC peut ouvrir la liaison de données
  }
  void onDisconnect(BLEServer* s) override {
    bleConnected = s && s->getConnectedCount() > 1;   // compte encore la connexion qui se ferme
    bleEvt = 2;
    BLEDevice::startAdvertising();       // redevient visible pour une nouvelle connexion
  }
};
// ---- Liaison de données Bluetooth (service « Nordic UART ») : mêmes lignes HCD_* qu'en USB, pour que le logiciel
// du PC puisse recevoir les actions PC (ouvrir un site, un programme...) et envoyer l'heure, la météo, les tuiles
// en direct, les pages automatiques sans câble. Les gros envois (menu, icônes, fond d'écran) restent en USB.
static BLECharacteristic* bleNusTx = nullptr;
static char bleRx[1024];
static volatile uint16_t bleRxHead = 0, bleRxTail = 0;
static portMUX_TYPE bleRxMux = portMUX_INITIALIZER_UNLOCKED;
class NusRxCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* c) override {
    String v = c->getValue();
    portENTER_CRITICAL(&bleRxMux);
    for (size_t i = 0; i < v.length(); i++) {
      uint16_t nh = (bleRxHead + 1) % sizeof(bleRx);
      if (nh == bleRxTail) break;        // plein : on jette le reste
      bleRx[bleRxHead] = v[i];
      bleRxHead = nh;
    }
    portEXIT_CRITICAL(&bleRxMux);
  }
};
static int bleRxGet() {
  int c = -1;
  portENTER_CRITICAL(&bleRxMux);
  if (bleRxTail != bleRxHead) { c = (uint8_t)bleRx[bleRxTail]; bleRxTail = (bleRxTail + 1) % sizeof(bleRx); }
  portEXIT_CRITICAL(&bleRxMux);
  return c;
}

// Écoute directe des connexions Bluetooth : avec cette version de la bibliothèque, les rappels du serveur
// (onConnect) ne sont pas appelés quand Windows se connecte au clavier ; le pad croyait n'être jamais relié.
static volatile int bleConnCount = 0;
static volatile bool bleNeedAdv = false;
#if defined(CONFIG_NIMBLE_ENABLED)
static struct ble_gap_event_listener bleGapListener;
static volatile uint16_t bleConnH[4] = {0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF};   // connexions ouvertes (poignées NimBLE)
static int bleGapCb(struct ble_gap_event* ev, void*) {
  if ((ev->type == BLE_GAP_EVENT_CONNECT && ev->connect.status == 0) || ev->type == BLE_GAP_EVENT_DISCONNECT)
    bleNeedAdv = true;                           // le relevé des connexions se fait dans bleScanConns()
  return 0;
}
// Notification envoyée directement à chaque connexion : la bibliothèque n'envoie rien quand elle croit n'avoir
// aucune connexion (ce qui arrive ici), et les touches comme les réponses au logiciel se perdaient.
// Les connexions ouvertes sont relevées directement auprès de la pile Bluetooth (ni les rappels de la bibliothèque
// ni l'écoute des événements ne signalent la connexion de Windows avec cette version) : relevé toutes les 300 ms.
static void bleScanConns() {
  static uint32_t last = 0;
  if (millis() - last < 300) return;
  last = millis();
  uint16_t hs[4] = {0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF};
  int n = 0;
  struct ble_gap_conn_desc d;
  for (uint16_t h = 0; h < 32 && n < 4; h++) if (ble_gap_conn_find(h, &d) == 0) hs[n++] = h;
  bool was = bleConnCount > 0;
  for (int i = 0; i < 4; i++) bleConnH[i] = hs[i];
  bleConnCount = n;
  bleConnected = n > 0;
  if ((n > 0) != was) { bleEvt = n > 0 ? 1 : 2; bleNeedAdv = true; }
}
static bool bleDiag = false;            // HCD_BLE_DIAG 1 : le pad raconte par l'USB ce qui passe en Bluetooth
static int bleRxLines = 0;
static volatile int bleNotifyRc = 0, bleNotifyN = 0, bleNotifyConns = 0;   // diagnostic (HCD_BLE_DIAG)
static void bleNotifyRaw(BLECharacteristic* c, const uint8_t* d, size_t n) {
  uint16_t ah = c->getHandle();
  int conns = 0;
  for (int i = 0; i < 4; i++) {
    uint16_t h = bleConnH[i];
    if (h == 0xFFFF) continue;
    conns++;
    struct os_mbuf* om = ble_hs_mbuf_from_flat(d, n);
    if (om) bleNotifyRc = ble_gatts_notify_custom(h, ah, om);
  }
  bleNotifyConns = conns;
  bleNotifyN++;
}
#endif
#if defined(CONFIG_NIMBLE_ENABLED)
class HcdSecCallbacks : public BLESecurityCallbacks {
  void onAuthenticationComplete(ble_gap_conn_desc* d, int status) override {
    bleEvtArg = status; bleEvt = status == 0 ? 3 : 4;
    (void)d;
  }
};
#endif
static void bleStart() {
  BLEDevice::init("JCharles desktop");      // nom vu par Windows (Bluetooth)
  bleServer = BLEDevice::createServer();
  bleServer->setCallbacks(new HcdBleCallbacks());
  BLEHIDDevice* hid = new BLEHIDDevice(bleServer);
  bleInKb = hid->inputReport(1);
  bleInCons = hid->inputReport(2);
  bleInMouse = hid->inputReport(3);
  hid->manufacturer()->setValue(String("HackMan3D"));
  hid->pnp(0x02, 0x303A, 0x1001, 0x0100);
  hid->hidInfo(0x00, 0x01);
#if defined(CONFIG_NIMBLE_ENABLED)
  BLEDevice::setSecurityCallbacks(new HcdSecCallbacks());
  ble_gap_event_listener_register(&bleGapListener, bleGapCb, nullptr);
#endif
  BLESecurity* sec = new BLESecurity();
  sec->setAuthenticationMode(ESP_LE_AUTH_BOND);
  sec->setCapability(ESP_IO_CAP_NONE);
  sec->setInitEncryptionKey(ESP_BLE_ENC_KEY_MASK | ESP_BLE_ID_KEY_MASK);
  hid->reportMap((uint8_t*)BLE_HID_DESC, sizeof(BLE_HID_DESC));
  // service de données AVANT startServices() : celui-ci démarre le serveur GATT, qui n'accepte plus de service ensuite
  {
    BLEService* nus = bleServer->createService("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    bleNusTx = nus->createCharacteristic("6e400003-b5a3-f393-e0a9-e50e24dcca9e", BLECharacteristic::PROPERTY_NOTIFY);
    bleNusTx->addDescriptor(new BLE2902());
    BLECharacteristic* rx = nus->createCharacteristic("6e400002-b5a3-f393-e0a9-e50e24dcca9e",
        BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
    rx->setCallbacks(new NusRxCallbacks());
    nus->start();
  }
  hid->startServices();
  hid->setBatteryLevel(100);
  BLEAdvertising* adv = bleServer->getAdvertising();
  adv->setAppearance(0x03C1);            // clavier
  adv->addServiceUUID(hid->hidService()->getUUID());
  adv->start();
  bleOn = true;
}

// relié en Bluetooth : rappel de connexion OU nombre de connexions du serveur (plus fiable avec Windows)
static bool bleLinked() { return bleOn && (bleConnCount > 0 || bleConnected || (bleServer && bleServer->getConnectedCount() > 0)); }
static void bleSend(BLECharacteristic* c, const uint8_t* d, size_t n) {
  if (!bleOn || !c) return;
  // En Bluetooth, le PC ne lit qu'un rapport par « intervalle de connexion » (7,5 à 30 ms) : des rapports envoyés
  // coup sur coup (Ctrl, puis Ctrl+C, puis relâché) se perdaient et le raccourci n'arrivait pas. On les espace.
  static uint32_t lastUs = 0;
  uint32_t gap = micros() - lastUs;
  if (c != bleInMouse && gap < 16000) delayMicroseconds(16000 - gap);   // la souris garde son débit
  c->setValue((uint8_t*)d, n);
#if defined(CONFIG_NIMBLE_ENABLED)
  bleNotifyRaw(c, d, n);
#else
  c->notify();
#endif
  lastUs = micros();
}

// Sortie des réponses HCD_* : port USB et, en Bluetooth, la liaison de données (par lignes, paquets de 20 octets).
class HcdOut : public Print {
  char line[420];
  size_t n = 0;
  void flushBle() {
    if (bleOn && bleNusTx && n) {
      for (size_t i = 0; i < n; i += 20) {
        size_t k = (n - i < 20) ? n - i : 20;
        bleNusTx->setValue((uint8_t*)line + i, k);
#if defined(CONFIG_NIMBLE_ENABLED)
        bleNotifyRaw(bleNusTx, (uint8_t*)line + i, k);
#else
        bleNusTx->notify();
#endif
        delay(3);
      }
    }
    n = 0;
  }
 public:
  size_t write(uint8_t c) override {
    Serial.write(c);
    if (n < sizeof(line)) line[n++] = (char)c;
    if (c == '\n' || n >= sizeof(line)) flushBle();
    return 1;
  }
  size_t write(const uint8_t* b, size_t len) override { for (size_t i = 0; i < len; i++) write(b[i]); return len; }
};
static HcdOut Out;

// Codes « Arduino » (KEY_xxx, ASCII) -> usages HID, comme la bibliothèque Keyboard (clavier US)
static bool kbUsage(uint8_t k, uint8_t& usage, uint8_t& mod) {
  usage = 0; mod = 0;
  if (k >= 136) { usage = k - 136; return true; }
  if (k >= 128) { mod = 1 << (k - 128); return true; }
  const uint8_t SH = 0x02;
  if (k >= 'a' && k <= 'z') { usage = 4 + (k - 'a'); return true; }
  if (k >= 'A' && k <= 'Z') { usage = 4 + (k - 'A'); mod = SH; return true; }
  if (k >= '1' && k <= '9') { usage = 0x1E + (k - '1'); return true; }
  if (k == '0') { usage = 0x27; return true; }
  struct { char c; uint8_t u; bool sh; } t[] = {
    {' ',0x2C,false},{'!',0x1E,true},{'@',0x1F,true},{'#',0x20,true},{'$',0x21,true},{'%',0x22,true},
    {'^',0x23,true},{'&',0x24,true},{'*',0x25,true},{'(',0x26,true},{')',0x27,true},{'-',0x2D,false},
    {'_',0x2D,true},{'=',0x2E,false},{'+',0x2E,true},{'[',0x2F,false},{'{',0x2F,true},{']',0x30,false},
    {'}',0x30,true},{'\\',0x31,false},{'|',0x31,true},{';',0x33,false},{':',0x33,true},{'\'',0x34,false},
    {'"',0x34,true},{'`',0x35,false},{'~',0x35,true},{',',0x36,false},{'<',0x36,true},{'.',0x37,false},
    {'>',0x37,true},{'/',0x38,false},{'?',0x38,true},{'\n',0x28,false},{'\t',0x2B,false},{'\b',0x2A,false},
  };
  for (auto& e : t) if ((uint8_t)e.c == k) { usage = e.u; if (e.sh) mod = SH; return true; }
  return false;
}

static uint8_t bleMods = 0;
static uint8_t bleKeys[6] = {0, 0, 0, 0, 0, 0};
static uint8_t bleButtons = 0;

static void bleKbSend() {
  uint8_t r[8] = {bleMods, 0, bleKeys[0], bleKeys[1], bleKeys[2], bleKeys[3], bleKeys[4], bleKeys[5]};
  bleSend(bleInKb, r, 8);
}

class HidKeyboard {
 public:
  void begin() { usbKeyboard.begin(); }
  size_t press(uint8_t k) {
    if (linkMode == 0) return usbKeyboard.press(k);
    uint8_t u, m;
    if (!kbUsage(k, u, m)) return 0;
    bleMods |= m;
    if (u) {
      bool have = false;
      for (int i = 0; i < 6; i++) if (bleKeys[i] == u) have = true;
      if (!have) for (int i = 0; i < 6; i++) if (!bleKeys[i]) { bleKeys[i] = u; break; }
    }
    bleKbSend();
    return 1;
  }
  size_t release(uint8_t k) {
    if (linkMode == 0) return usbKeyboard.release(k);
    uint8_t u, m;
    if (!kbUsage(k, u, m)) return 0;
    bleMods &= ~m;
    if (u) for (int i = 0; i < 6; i++) if (bleKeys[i] == u) bleKeys[i] = 0;
    bleKbSend();
    return 1;
  }
  void releaseAll() {
    if (linkMode == 0) { usbKeyboard.releaseAll(); return; }
    bleMods = 0;
    for (int i = 0; i < 6; i++) bleKeys[i] = 0;
    bleKbSend();
  }
  size_t print(const char* s) {
    if (linkMode == 0) return usbKeyboard.print(s);
    size_t n = 0;
    for (; s && *s; s++) {
      uint8_t c = (uint8_t)*s;
      if (c >= 128) continue;                         // caractères non US ignorés, comme en USB
      press(c); delay(8); release(c); delay(8);
      n++;
    }
    return n;
  }
};

class HidMouse {
 public:
  void begin() { usbMouse.begin(); }
  void move(int8_t x, int8_t y, int8_t wheel = 0, int8_t pan = 0) {
    if (linkMode == 0) { usbMouse.move(x, y, wheel, pan); return; }
    uint8_t r[5] = {bleButtons, (uint8_t)x, (uint8_t)y, (uint8_t)wheel, (uint8_t)pan};
    bleSend(bleInMouse, r, 5);
  }
  void press(uint8_t b = MOUSE_LEFT) {
    if (linkMode == 0) { usbMouse.press(b); return; }
    bleButtons |= b; move(0, 0);
  }
  void release(uint8_t b = MOUSE_LEFT) {
    if (linkMode == 0) { usbMouse.release(b); return; }
    bleButtons &= ~b; move(0, 0);
  }
};

class HidConsumer {
 public:
  void begin() { usbConsumer.begin(); }
  void press(uint16_t c) {
    if (linkMode == 0) { usbConsumer.press(c); return; }
    uint8_t r[2] = {(uint8_t)(c & 0xFF), (uint8_t)(c >> 8)};
    bleSend(bleInCons, r, 2);
  }
  void release() {
    if (linkMode == 0) { usbConsumer.release(); return; }
    uint8_t r[2] = {0, 0};
    bleSend(bleInCons, r, 2);
  }
};

HidKeyboard keyboard;
HidMouse mouse;
HidConsumer consumer;

static const uint16_t CC_PLAY_PAUSE = 0x00CD;
static const uint16_t CC_NEXT       = 0x00B5;
static const uint16_t CC_PREV       = 0x00B6;
static const uint16_t CC_STOP       = 0x00B7;
static const uint16_t CC_MUTE       = 0x00E2;
static const uint16_t CC_VOL_UP     = 0x00E9;
static const uint16_t CC_VOL_DOWN   = 0x00EA;
static const uint16_t CC_BRIGHT_UP  = 0x006F;
static const uint16_t CC_BRIGHT_DN  = 0x0070;

// ------------------------------------------------------------- Constantes ---
#if JC_BOARD == 2
// Polices lissées (DejaVu Sans, avec accents) ; repli sur les polices bitmap si le chargement échoue.
#include "JC_Fonts.h"
static lgfx::PointerWrapper fwS, fwM, fwL, fwXL;
static lgfx::VLWfont vlwS, vlwM, vlwL, vlwXL;
static bool fontsOk = false;
static void fontsBegin() {
  fwS.set(VLW_S, sizeof(VLW_S)); fwM.set(VLW_M, sizeof(VLW_M));
  fwL.set(VLW_L, sizeof(VLW_L)); fwXL.set(VLW_XL, sizeof(VLW_XL));
  fontsOk = vlwS.loadFont(&fwS) && vlwM.loadFont(&fwM) && vlwL.loadFont(&fwL) && vlwXL.loadFont(&fwXL);
}
#define FONT_S (fontsOk ? (const lgfx::IFont*)&vlwS : (const lgfx::IFont*)&fonts::lgfxJapanGothic_16)
#define FONT_M (fontsOk ? (const lgfx::IFont*)&vlwM : (const lgfx::IFont*)&fonts::lgfxJapanGothic_20)
#define FONT_L (fontsOk ? (const lgfx::IFont*)&vlwL : (const lgfx::IFont*)&fonts::lgfxJapanGothic_24)
#define FONT_XL (fontsOk ? (const lgfx::IFont*)&vlwXL : (const lgfx::IFont*)&fonts::FreeSansBold24pt7b)
#else
#define FONT_S (&fonts::lgfxJapanGothic_12)
#define FONT_M (&fonts::lgfxJapanGothic_16)
#define FONT_L (&fonts::lgfxJapanGothic_20)
#endif
static const int ROWS = 2;
#if JC_BOARD == 2
static const int SCREEN_W = 480, SCREEN_H = 320, HEADER_H = 36;
#else
static const int SCREEN_W = 320, SCREEN_H = 240, HEADER_H = 28;
#endif
// Coordonnée prévue pour l'écran 320x240, ramenée à l'écran réel (identique en V1).
#define SX(v) ((v) * SCREEN_W / 320)
#define SY(v) ((v) * SCREEN_H / 240)
static const int CELL_H = (SCREEN_H - HEADER_H) / ROWS;
static const uint32_t LONG_PRESS_MS = 600;
static const int SWIPE_MIN_PX = SX(50);
#if JC_BOARD == 2
static const int MOVE_THRESHOLD_PX = 24;   // écran résistif de 4" : la position saute au début d'un appui léger
static const uint32_t TOUCH_SETTLE_MS = 80; // pendant ce temps, le point de départ suit le doigt (pas de « glissé »)
#else
static const int MOVE_THRESHOLD_PX = 10;
#endif
#if JC_BOARD == 2
static const int ICON_PX = 64;          // V2 : icônes plus grandes (le logiciel les envoie à cette taille)
#else
static const int ICON_PX = 48;
#endif
static const size_t ICON_BYTES = ICON_PX * ICON_PX * 2;

static const char* MENU_FILE = "/menu.json";
static const char* HW_FILE = "/hw.json";
static const size_t MENU_MAX = 48 * 1024;
static const size_t HW_MAX = 2048;

static const char* DEFAULT_MENU = R"JSON({
 "v":3,"name":"Accueil","cols":4,
 "keys":[
  {"label":"Copier","type":"hotkey","mods":["ctrl"],"key":"c","led_color":"#f1c40f","led_mode":"press"},
  {"label":"Coller","type":"hotkey","mods":["ctrl"],"key":"v","led_color":"#2980b9","led_mode":"press"},
  {"label":"Muet","type":"media","key":"mute","led_color":"#e74c3c","led_mode":"toggle"}],
 "combos":[{"key":0,"src":"pot","pot":"pc_screen"},{"key":1,"src":"pot","pot":"mic"}],
 "pages":[{"items":[
  {"label":"Media","color":"#8e44ad","type":"folder","pages":[{"items":[
    {"label":"Lecture","type":"media","key":"play_pause"},
    {"label":"Suivant","type":"media","key":"next"},
    {"label":"Precedent","type":"media","key":"prev"},
    {"label":"Vol +","type":"media","key":"vol_up"},
    {"label":"Vol -","type":"media","key":"vol_down"}]}]},
  {"label":"Edition","color":"#2980b9","type":"folder","pages":[{"items":[
    {"label":"Copier","type":"hotkey","mods":["ctrl"],"key":"c"},
    {"label":"Coller","type":"hotkey","mods":["ctrl"],"key":"v"},
    {"label":"Annuler","type":"hotkey","mods":["ctrl"],"key":"z"}]}]},
  {"label":"Fusion 3D","color":"#e67e22","type":"mode","mode":"pad"},
  {"label":"Volume","color":"#27ae60","type":"mode","mode":"volume"},
  {"label":"Micro","color":"#c0392b","type":"hotkey","mods":["ctrl","shift"],"key":"m"},
  {"label":"Muet","color":"#7f8c8d","type":"media","key":"mute"},
  {"label":"Capture","color":"#16a085","type":"hotkey","mods":["win","shift"],"key":"s"},
  {"label":"Bureau","color":"#34495e","type":"hotkey","mods":["win"],"key":"d"}
 ]}]})JSON";

// ---------------------------------------------------------- Configuration ---
enum PotMode { P_OFF, P_VOL_USB, P_VOL_PC, P_SCREEN, P_LED, P_MIC, P_PCBRI };
enum JoyMode { J_OFF, J_MOUSE, J_ORBIT, J_PAN, J_SCROLL };
enum BarMode { B_OFF, B_TOUCH, B_SOLID };

static const char* const POT_NAMES[] = {"off", "vol_usb", "vol_pc", "screen", "led"};
static const char* const JOY_NAMES[] = {"off", "mouse", "orbit", "pan", "scroll"};
static const char* const BAR_NAMES[] = {"off", "touch", "solid"};
static const char* const LEDMODE_NAMES[] = {"off", "press", "toggle", "always"};

struct Hw {
  int screen = 200;
  int ledStatus = 60;
  int ledKeys = 180;
  int ledBar = 120;
  BarMode barMode = B_TOUCH;
  int dimS = 0;               // secondes avant de baisser l'écran (0 = jamais)
  int offS = 0;               // secondes avant d'éteindre l'écran (0 = jamais)
#if JC_BOARD == 2
  int sleepMin = 5;           // minutes sans toucher avant la veille profonde, sur batterie ou en Bluetooth (0 = jamais)
#else
  int sleepMin = 0;           // minutes avant la veille profonde, en Bluetooth seulement (0 = jamais)
#endif
  bool chrgDetect = false;    // la LED verte respire quand le TP4056 charge
  bool stripSimple = false;   // ruban à une seule couleur (COB, via MOSFET) : PWM sur la broche au lieu de WS2812
  uint32_t barColor = 0xFFFFFF;
  PotMode pot = P_VOL_USB;
  bool potInv = false;
  JoyMode joy = J_MOUSE;
  int joySpeed = 6;
  int joyDead = 20;        // Zone morte (%), agrandie automatiquement si le bruit est fort
  bool joyInvX = false;    // Inversion des axes : réglable dans HCD Studio (ou joy_inv_x / joy_inv_y)
  bool joyInvY = false;
  bool joySwap = false;    // Échanger X et Y (module monté tourné de 90°, ou fils inversés)
  bool joySw = true;
  bool joyNav = false;     // navigation dans les tuiles au joystick (état au démarrage / réglage Studio)
  int rot180 = 600;
  bool battShow = true;    // V2 : jauge de batterie dans la barre d'état (masquée si aucun pont n'est câblé)
  bool saverClock = true;  // V2 : écran « éteint » = horloge en faible luminosité au lieu d'un écran noir
  bool volBar = true;      // V2 : curseur de volume toujours visible à droite du menu
  bool games = true;       // V2 : menu « Jeux » autorisé (réglage du logiciel)
  bool flip = false;       // écran retourné de 180° par rapport au montage par défaut
  int touchZ = 160;        // V2 : pression minimale sur l'écran tactile (bas = plus sensible)
  int touchMs = 60;        // touches TTP223 : durée minimale du toucher pour qu'il compte (filtre les effleurements)
  int sound = 60;          // V2 : volume du haut-parleur (0 = muet), ampli MAX98357A
  bool music = true;       // V2 : musique dans le jeu de plateformes
  int wifiMode = 0;        // V2 : 0 Wi-Fi coupé, 1 connexions courtes (30 min), 2 permanent
#if JC_BOARD == 2
  bool keyTouch = true;    // touches sensitives TTP223 : appuyé = état HAUT (sinon touche vers GND : appuyé = BAS)
#else
  bool keyTouch = false;
#endif
} hw;

static int enumFrom(const char* s, const char* const* names, int n, int def) {
  if (!s) return def;
  for (int i = 0; i < n; i++) if (!strcmp(s, names[i])) return i;
  return def;
}

// ------------------------------------------------------------------- État ---
static Mode mode = M_MENU;

// Navigation dans les tuiles avec le joystick (activée par l'action « joynav » ou le réglage HCD Studio)
static bool joyNav = false;
static int navSel = 0;

struct Level {
  JsonArrayConst pages;
  int page = 0;
  String name;
};

static JsonDocument menuDoc;
static Level cur;
static std::vector<Level> stack;
static int COLS = 4;
static int slots() { return COLS * ROWS; }
#if JC_BOARD == 2
static const int VB_W = 52;                                   // largeur du curseur de volume (à droite)
static int gridW() { return hw.volBar ? SCREEN_W - VB_W : SCREEN_W; }
#else
static int gridW() { return SCREEN_W; }
#endif
static int cellW() { return gridW() / COLS; }

struct KeyCfg { uint32_t color = 0x00AAFF; int mode = 1; bool hasLong = false; bool hasCombo = false; };
static KeyCfg keyCfg[3];
// Combinaisons : touche maintenue + potentiomètre (réglage) ou joystick (action). Voir "combos" dans le menu.
struct Combo { int8_t key; int8_t src; int8_t fn; int8_t idx; };   // src : 0 pot, 1 haut, 2 bas, 3 gauche, 4 droite
static Combo combos[16];
static int nCombos = 0;
static bool comboUsed[3] = {false, false, false};
static bool keyDown[3] = {false, false, false};
static bool keyToggled[3] = {false, false, false};

static uint32_t lastPing = 0;
static bool pcConnected() { return lastPing != 0 && millis() - lastPing < 3000; }

static bool padPan = false;
static int volLevel = 50;
static bool volMuted = false;   // état du son ; le vrai niveau est envoyé par JCharles desktop (HCD_VOL) en USB
static uint32_t lastActivity = 0;
static int screenState = 0;              // 0 allumé, 1 atténué, 2 éteint
static void markActivity();
static uint32_t activityUntil = 0;       // le ruban reste allumé un court instant après une action (touche, tuile…)
static bool stripReady = false, stripSimpleInit = false;
static uint8_t ledMaster = 255;
static bool ledForce = true;

struct TouchState {
  bool down = false, moved = false, longDone = false;
  int32_t sx = 0, sy = 0, lx = 0, ly = 0;
  uint32_t t0 = 0, tlast = 0;
  int slot = -1;
  int region = 0;
  int acc = 0;
} T;

// ------------------------------------------------------------ Utilitaires ---
static uint32_t parseColor(const char* s, uint32_t fallback) {
  if (!s || s[0] != '#' || strlen(s) != 7) return fallback;
  return (uint32_t)strtoul(s + 1, nullptr, 16);
}

static uint16_t rgb565(uint32_t rgb, int lighten = 0) {
  int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
  r = min(255, r + lighten); g = min(255, g + lighten); b = min(255, b + lighten);
  return lcd.color565(r, g, b);
}

static int8_t clamp8(int v) { return (int8_t)constrain(v, -127, 127); }

static String toastText;
static uint32_t toastUntil = 0;
static void drawHeader();

static void toast(const String& s) {
  if (toastText != s || millis() > toastUntil) {
    toastText = s;
    toastUntil = millis() + 1200;
    drawHeader();
  }
}

static void changePage(int delta);
static void goHomeAndDraw();

// --------------------------------------------------------------- Actions ---
static void pressNamedKey(const char* k) {
  if (!k || !*k) return;
  if (strlen(k) == 1) { keyboard.press((uint8_t)k[0]); return; }
  struct { const char* n; uint8_t c; } map[] = {
    {"enter", KEY_RETURN}, {"tab", KEY_TAB}, {"esc", KEY_ESC},
    {"backspace", KEY_BACKSPACE}, {"delete", KEY_DELETE}, {"space", ' '},
    {"up", KEY_UP_ARROW}, {"down", KEY_DOWN_ARROW},
    {"left", KEY_LEFT_ARROW}, {"right", KEY_RIGHT_ARROW},
    {"home", KEY_HOME}, {"end", KEY_END},
    {"pageup", KEY_PAGE_UP}, {"pagedown", KEY_PAGE_DOWN},
    {"f1", KEY_F1}, {"f2", KEY_F2}, {"f3", KEY_F3}, {"f4", KEY_F4},
    {"f5", KEY_F5}, {"f6", KEY_F6}, {"f7", KEY_F7}, {"f8", KEY_F8},
    {"f9", KEY_F9}, {"f10", KEY_F10}, {"f11", KEY_F11}, {"f12", KEY_F12},
  };
  for (auto& e : map) if (!strcasecmp(k, e.n)) { keyboard.press(e.c); return; }
}

static void pressModifier(const char* m) {
  if (!strcasecmp(m, "ctrl")) keyboard.press(KEY_LEFT_CTRL);
  else if (!strcasecmp(m, "shift")) keyboard.press(KEY_LEFT_SHIFT);
  else if (!strcasecmp(m, "alt")) keyboard.press(KEY_LEFT_ALT);
  else if (!strcasecmp(m, "gui") || !strcasecmp(m, "win") || !strcasecmp(m, "cmd"))
    keyboard.press(KEY_LEFT_GUI);
}

static void sendConsumer(const char* k) {
  struct { const char* n; uint16_t c; } map[] = {
    {"play_pause", CC_PLAY_PAUSE}, {"next", CC_NEXT}, {"prev", CC_PREV},
    {"stop", CC_STOP}, {"mute", CC_MUTE}, {"vol_up", CC_VOL_UP},
    {"vol_down", CC_VOL_DOWN}, {"bright_up", CC_BRIGHT_UP}, {"bright_down", CC_BRIGHT_DN},
  };
  for (auto& e : map) if (!strcmp(k, e.n)) {
    consumer.press(e.c);
    delay(15);
    consumer.release();
    return;
  }
}

static void drawAll();

// Recalibrage du tactile depuis le menu (action « nav » / « calibrate ») : suivez les flèches aux coins.
static void runTouchCalibration() {
  uint16_t cal[8];
  lcd.fillScreen(TFT_BLACK);
  lcd.setFont(FONT_M);
  lcd.setTextColor(TFT_WHITE);
  lcd.setTextDatum(middle_center);
  lcd.drawString("Touchez les fleches aux coins", SCREEN_W / 2, SCREEN_H / 2);
  lcd.calibrateTouch(cal, TFT_WHITE, TFT_BLACK, 20);
  Preferences pr;
  pr.begin("hcd", false);
  pr.putBytes("cal", cal, sizeof(cal));
  pr.end();
  T.down = false; T.slot = -1;
  delay(300);
  drawAll();
  toast("Ecran calibre");
}

static void toggleJoyNav() {
  joyNav = !joyNav; navSel = 0;
  drawAll();
  toast(joyNav ? "Joystick : tuiles" : "Joystick : normal");
}

static void execute(JsonVariantConst a) {
  activityUntil = millis() + 350;
  markActivity();
  const char* type = a["type"] | "";
  if (!strcmp(type, "hotkey")) {
    for (JsonVariantConst m : a["mods"].as<JsonArrayConst>()) pressModifier(m.as<const char*>());
    pressNamedKey(a["key"] | "");
    delay(25);
    keyboard.releaseAll();
  } else if (!strcmp(type, "text")) {
    keyboard.print(a["text"] | "");
  } else if (!strcmp(type, "media")) {
    sendConsumer(a["key"] | "");
  } else if (!strcmp(type, "pc")) {
    Out.printf("HCD_EVT %s\n", a["id"] | "");
  } else if (!strcmp(type, "nav")) {
    const char* d = a["dir"] | "";
    if (mode == M_MENU) {
      if (!strcmp(d, "next")) changePage(+1);
      else if (!strcmp(d, "prev")) changePage(-1);
      else if (!strcmp(d, "home")) goHomeAndDraw();
      else if (!strcmp(d, "calibrate")) runTouchCalibration();
      else if (!strcmp(d, "joynav")) toggleJoyNav();
    }
  }
}

// Images envoyées par le logiciel (icônes, fond d'écran) : RGB565 « petit-boutiste ». LovyanGFX lit par défaut un
// tableau uint16_t avec les octets inversés : il faut le lui dire, sinon le bleu sort vert, rouge ou rose.
static void pushRaw565(LovyanGFX* t, int x, int y, int w, int h, const uint16_t* data, int key = -1) {
  bool sw = t->getSwapBytes();
  t->setSwapBytes(true);
  if (key >= 0) t->pushImage(x, y, w, h, data, (uint16_t)key);
  else t->pushImage(x, y, w, h, data);
  t->setSwapBytes(sw);
}

// ---------------------------------------------------------------- Icônes ---
static bool drawIcon(const char* name, int x, int y, LovyanGFX* g = nullptr) {
  if (!name || !*name) return false;
  String p = String("/ic/") + name + ".raw";
  File f = LittleFS.open(p, "r");
  if (!f) return false;
  static uint16_t buf[ICON_PX * ICON_PX];
#if JC_BOARD == 2
  if (f.size() == 48 * 48 * 2) {            // icône 48 px envoyée par un ancien logiciel (0.15) : agrandie à 64 px
    static uint16_t src[48 * 48];
    f.read((uint8_t*)src, sizeof(src));
    f.close();
    for (int yy = 0; yy < ICON_PX; yy++)
      for (int xx = 0; xx < ICON_PX; xx++) buf[yy * ICON_PX + xx] = src[(yy * 48 / ICON_PX) * 48 + xx * 48 / ICON_PX];
    pushRaw565(g ? g : (LovyanGFX*)&lcd, x, y, ICON_PX, ICON_PX, buf, 0xF81F);
    return true;
  }
#endif
  if (f.size() != ICON_BYTES) { f.close(); return false; }
  f.read((uint8_t*)buf, ICON_BYTES);
  f.close();
  pushRaw565(g ? g : (LovyanGFX*)&lcd, x, y, ICON_PX, ICON_PX, buf, 0xF81F);     // magenta = transparent
  return true;
}

// ------------------------------------------------------------ Menu / slots --
static JsonArrayConst curItems() {
  if (cur.pages.isNull() || cur.pages.size() == 0) return JsonArrayConst();
  if (cur.page >= (int)cur.pages.size()) cur.page = 0;
  return cur.pages[cur.page]["items"].as<JsonArrayConst>();
}

static Slot getSlot(int i) {
  Slot s;
  JsonArrayConst items = curItems();
  if (!items.isNull() && (size_t)i < items.size()) {
    JsonVariantConst it = items[i];
    s.used = true;
    s.item = it;
    s.label = String(it["label"] | "?");
    s.icon = String(it["icon"] | "");
    const char* t = it["type"] | "";
    s.folder = !strcmp(t, "folder");
    s.isMode = !strcmp(t, "mode");
    s.color = parseColor(it["color"] | "", s.folder ? 0x2c3e50 : 0x34495e);
  }
  return s;
}

static void goHome() {
  stack.clear();
  cur.pages = menuDoc["pages"].as<JsonArrayConst>();
  cur.page = 0;
  cur.name = String(menuDoc["name"] | "Accueil");
}

static void cacheKeys() {
  for (int k = 0; k < 3; k++) {
    JsonVariantConst kk = menuDoc["keys"][k];
    keyCfg[k].color = parseColor(kk["led_color"] | "", 0x00AAFF);
    keyCfg[k].mode = enumFrom(kk["led_mode"] | "press", LEDMODE_NAMES, 4, 1);
    keyCfg[k].hasLong = !kk["long"].isNull();
    keyCfg[k].hasCombo = false;
  }
  nCombos = 0;
  JsonArrayConst cs = menuDoc["combos"].as<JsonArrayConst>();
  int idx = 0;
  for (JsonVariantConst c : cs) {
    int key = c["key"] | -1;
    const char* src = c["src"] | "";
    if (nCombos < 16 && key >= 0 && key < 3) {
      int sv = !strcmp(src, "pot") ? 0 : !strcmp(src, "up") ? 1 : !strcmp(src, "down") ? 2 : !strcmp(src, "left") ? 3 : !strcmp(src, "right") ? 4 : -1;
      int fv = P_OFF;
      if (sv == 0) {
        const char* f = c["pot"] | "";
        fv = !strcmp(f, "screen") ? P_SCREEN : !strcmp(f, "mic") ? P_MIC : !strcmp(f, "pc_screen") ? P_PCBRI : !strcmp(f, "vol_pc") ? P_VOL_PC
           : !strcmp(f, "vol_usb") ? P_VOL_USB : !strcmp(f, "led") ? P_LED : P_OFF;
      }
      if (sv >= 0) {
        combos[nCombos++] = {(int8_t)key, (int8_t)sv, (int8_t)fv, (int8_t)idx};
        keyCfg[key].hasCombo = true;
      }
    }
    idx++;
  }
}

static bool loadMenuFromFile() {
  File f = LittleFS.open(MENU_FILE, "r");
  if (!f) return false;
  menuDoc.clear();
  DeserializationError err = deserializeJson(menuDoc, f);
  f.close();
  if (err || !menuDoc["pages"].is<JsonArray>()) return false;
  COLS = constrain(menuDoc["cols"] | 4, 3, 4);
  goHome();
  cacheKeys();
  return true;
}

static void writeFile(const char* path, const String& body) {
  File f = LittleFS.open(path, "w");
  if (f) { f.print(body); f.close(); }
}

// -------------------------------------------------------------- Affichage ---
#if JC_BOARD == 2
// =============================== V2 : barre d'état, batterie, heure, fond d'écran, horloge de veille ======
static bool saverOn = false;             // horloge de veille affichée
static int battMv = 0;                   // tension batterie lissée (mV), 0 = pas encore mesurée
static uint16_t* wall = nullptr;         // fond d'écran (PSRAM), 480x320 RGB565
static bool wallOk = false;
static const char* WALL_FILE = "/wall.raw";
static const size_t WALL_BYTES = (size_t)SCREEN_W * SCREEN_H * 2;
static int16_t touchX = -1, touchY = -1; // point touché (rond lumineux sur la tuile)
static int flashSlot = -1;               // tuile qui affiche la coche de confirmation
static uint32_t flashUntil = 0;

static bool isGameMode() { return mode == M_GAMES || mode == M_JUMP || mode == M_SNAKE; }
static int hdrSndX = -1;                 // jeux : début (x) de la zone « volume » dans l'en-tête, -1 = absente
static void gamesDraw();
static void gamesTask();
static void gameTouchDown(int x, int y);
static void gameTouchUp();
static String gameHud;                   // texte de l'en-tête pendant une partie
static void drawWeather();               // JC_Weather.h
static void drawShortcuts();             // écran « Raccourcis » (toucher l'en-tête)
static void shortcutTap(int x, int y);
static String wxTileText();

// ---- Tuiles vivantes : une tuile qui porte "live" affiche une valeur envoyée par le PC (HCD_LIVE) ou calculée ici.
//   cpu / ram : charge du PC en % ; music : titre en cours ; clock : heure de la carte.
static const char* LIVE_KEYS[] = {"cpu", "ram", "music"};
static String liveVal[3];
static int liveIndex(const char* k) { for (int i = 0; i < 3; i++) if (!strcmp(k, LIVE_KEYS[i])) return i; return -1; }

// ---- Minuteur / Pomodoro : tuile « Mode spécial » timer:N (N minutes) ou pomodoro (25 min travail, 5 min pause).
static String timerMode;                 // mode de la tuile qui a lancé le minuteur ("" = arrêté)
static uint32_t tmrEnd = 0;            // millis() de fin
static uint8_t timerPhase = 0;           // 0 minuteur simple, 1 travail, 2 pause (Pomodoro)
static uint32_t alarmUntil = 0, alarmColor = 0;   // fin de la séquence de clignotement du ruban

static bool timeKnown() { return time(nullptr) > 1700000000; }   // l'heure est envoyée par JCharles desktop (HCD_TIME)
static bool localTm(struct tm& tm) {
  if (!timeKnown()) return false;
  time_t t = time(nullptr);
  gmtime_r(&t, &tm);                     // le PC envoie déjà l'heure locale
  return true;
}
static bool battPresent() { return hw.battShow && battMv > 2800; }
static bool charging() { return hw.chrgDetect && digitalRead(PIN_CHRG) == LOW; }
static int battPctRaw() {                // courbe approchée d'un accu Li-ion (au repos)
  static const int mv[] = {3300, 3500, 3600, 3700, 3750, 3800, 3900, 4000, 4100, 4180};
  static const int pc[] = {0, 3, 8, 20, 32, 42, 62, 79, 90, 100};
  if (battMv <= mv[0]) return 0;
  for (int i = 1; i < 10; i++)
    if (battMv <= mv[i]) return pc[i - 1] + (pc[i] - pc[i - 1]) * (battMv - mv[i - 1]) / (mv[i] - mv[i - 1]);
  return 100;
}
// Pourcentage affiché : il ne remonte pas sur batterie (sauf vraie recharge), pour ne pas « sautiller ».
static int battShown = -1;
static int battPct() {
  int p = battPctRaw();
  if (battShown < 0 || charging() || p < battShown || p >= battShown + 4) battShown = p;
  return battShown;
}
static void battTask() {
  static uint32_t t = 0;
  if (millis() - t < 1000) return;
  t = millis();
  int r[15];
  for (int i = 0; i < 15; i++) r[i] = analogReadMilliVolts(PIN_BATT);
  std::sort(r, r + 15);
  int v = r[7] * 2;                      // pont diviseur par 2 ; médiane : le module 5 V fait des pointes
  // Sous charge, la tension de l'accu baisse (écran, Bluetooth...) : la courbe est celle d'un accu au repos.
  // On compense selon ce qui consomme, sinon la jauge affiche 15 à 25 % de moins que la réalité.
  int comp = 70;                                           // carte, ampli, LED au repos
  if (screenState == 0) comp += 40 + hw.screen * 110 / 255;  // rétroéclairage (le plus gros consommateur)
  else if (screenState == 1) comp += 40;
  if (bleOn) comp += 20;
  if (WiFi.status() == WL_CONNECTED) comp += 40;
  v += comp;
  // lissage lent (~40 s) : la tension suit la consommation et ferait défiler les % comme un compte à rebours
  // gros écart (câble branché/débranché, fin de charge) : on prend la nouvelle valeur après 3 mesures concordantes
  static int far = 0;
  if (battMv && abs(v - battMv) > 150) { if (++far >= 3) { battMv = v; battShown = -1; far = 0; } return; }
  far = 0;
  if (!battMv) battMv = v;
  else battMv = (battMv * 39 + v + 20) / 40;
}

static void loadWall() {
  wallOk = false;
  File f = LittleFS.open(WALL_FILE, "r");
  if (!f) return;
  if (f.size() == WALL_BYTES) {
    if (!wall) wall = (uint16_t*)ps_malloc(WALL_BYTES);
    if (wall) wallOk = f.read((uint8_t*)wall, WALL_BYTES) == WALL_BYTES;
  }
  f.close();
}

static void glyphUsb(LovyanGFX& g, int cx, int cy, uint16_t c) {
  g.drawWideLine(cx, cy + 8, cx, cy - 6, 1.2f, c);
  g.fillTriangle(cx, cy - 10, cx - 4, cy - 5, cx + 4, cy - 5, c);
  g.drawWideLine(cx, cy + 3, cx - 6, cy - 1, 1.0f, c);
  g.fillCircle(cx - 6, cy - 2, 2, c);
  g.drawWideLine(cx, cy + 1, cx + 6, cy - 3, 1.0f, c);
  g.fillRect(cx + 4, cy - 6, 4, 4, c);
  g.fillCircle(cx, cy + 8, 3, c);
}
static void glyphBt(LovyanGFX& g, int cx, int cy, uint16_t c) {
  const int P[][2] = {{-5, -5}, {5, 5}, {0, 10}, {0, -10}, {5, -5}, {-5, 5}};
  for (int i = 0; i < 5; i++) g.drawWideLine(cx + P[i][0], cy + P[i][1], cx + P[i + 1][0], cy + P[i + 1][1], 1.1f, c);
}
static void glyphBattery(LovyanGFX& g, int x, int cy, int pct, bool chg) {
  const int w = 26, h = 13, y = cy - h / 2;
  uint16_t col = pct > 40 ? 0x2EA9 : pct > 15 ? 0xFD20 : 0xF800;
  g.drawRoundRect(x, y, w, h, 3, 0xBDF7);
  g.fillRect(x + w, cy - 3, 2, 6, 0xBDF7);
  int fw = (w - 4) * constrain(pct, 0, 100) / 100;
  if (fw > 0) g.fillRect(x + 2, y + 2, fw, h - 4, col);
  if (chg) {                                                     // éclair : en charge
    g.fillTriangle(x + 14, y - 1, x + 8, cy + 1, x + 13, cy + 1, TFT_YELLOW);
    g.fillTriangle(x + 12, y + h + 1, x + 18, cy - 1, x + 13, cy - 1, TFT_YELLOW);
  }
}

static void drawSaver() {
  lcd.fillScreen(TFT_BLACK);
  lcd.setTextDatum(middle_center);
  struct tm tm;
  if (localTm(tm)) {
    static const char* J[] = {"Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"};
    static const char* M[] = {"janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
                              "septembre", "octobre", "novembre", "décembre"};
    char b[8];
    snprintf(b, sizeof(b), "%02d:%02d", tm.tm_hour, tm.tm_min);
    lcd.setFont(&fonts::Font7);
    lcd.setTextSize(2);
    lcd.setTextColor(0xC618);
    lcd.drawString(b, SCREEN_W / 2, SCREEN_H / 2 - 30);
    lcd.setTextSize(1);
    lcd.setFont(FONT_L);
    lcd.setTextColor(0x8410);
    lcd.drawString(String(J[tm.tm_wday]) + " " + tm.tm_mday + " " + M[tm.tm_mon], SCREEN_W / 2, SCREEN_H / 2 + 52);
  } else {
    lcd.setFont(FONT_M);
    lcd.setTextColor(0x8410);
    lcd.drawString("Touchez l'écran", SCREEN_W / 2, SCREEN_H / 2);
  }
  if (battPresent()) {
    lcd.setFont(FONT_M);
    lcd.setTextColor(0x8410);
    lcd.drawString(String(charging() ? "En charge  " : "Batterie  ") + battPct() + " %", SCREEN_W / 2, SCREEN_H - 30);
  }
  lcd.setTextSize(1);
}

static void drawHeaderV2() {
  static LGFX_Sprite hdr(&lcd);
  static bool ok = false;
  if (saverOn) return;
  if (!ok) ok = makeSprite(hdr, SCREEN_W, HEADER_H);
  LovyanGFX& g = ok ? (LovyanGFX&)hdr : (LovyanGFX&)lcd;
  const int cy = HEADER_H / 2;
  g.fillRect(0, 0, SCREEN_W, HEADER_H, 0x101820);
  g.drawFastHLine(0, HEADER_H - 1, SCREEN_W, 0x2945);

  int x = SCREEN_W - 8;                                          // éléments de droite, posés de droite à gauche
  g.fillCircle(x - 6, cy, 6, pcConnected() ? TFT_GREEN : TFT_RED);
  x -= 22;
  if (battPresent()) {
    int pc = battPct();
    g.setFont(FONT_S);
    g.setTextDatum(middle_right);
    g.setTextColor(0xDEFB);
    String t = String(pc) + "%";
    g.drawString(t, x, cy);
    x -= g.textWidth(t) + 32;
    glyphBattery(g, x, cy, pc, charging());
    x -= 12;
  }
  hdrSndX = -1;
  if (isGameMode()) {                                            // jeux : volume du haut-parleur, touchable
    g.setFont(FONT_S);
    g.setTextDatum(middle_right);
    g.setTextColor(hw.sound ? 0xDEFB : 0xF8A2);
    String t = hw.sound ? String(hw.sound) + "%" : String("muet");
    g.drawString(t, x, cy);
    x -= g.textWidth(t) + 6;
    uint16_t ic = hw.sound ? (uint16_t)0xDEFB : (uint16_t)0xF8A2;
    g.fillRect(x - 16, cy - 3, 5, 6, ic);
    g.fillTriangle(x - 12, cy - 3, x - 6, cy - 8, x - 6, cy + 8, ic);
    g.fillTriangle(x - 12, cy + 3, x - 6, cy - 8, x - 6, cy + 8, ic);
    x -= 22;
    hdrSndX = x - 8;
  }
  struct tm tm;
  if (localTm(tm)) {
    char b[8];
    snprintf(b, sizeof(b), "%02d:%02d", tm.tm_hour, tm.tm_min);
    g.setFont(FONT_M);
    g.setTextDatum(middle_right);
    g.setTextColor(TFT_WHITE);
    g.drawString(b, x, cy);
    x -= g.textWidth(b) + 14;
  }
  if (timerMode.length()) {                                      // minuteur en cours (lancé d'une tuile ou des raccourcis)
    long left = max(0L, (long)(tmrEnd - millis()) / 1000);
    char b[12];
    snprintf(b, sizeof(b), "%ld:%02ld", left / 60, left % 60);
    g.setFont(FONT_S);
    g.setTextDatum(middle_right);
    g.setTextColor(timerPhase == 2 ? 0x87F0 : 0xFD20);
    g.drawString(b, x, cy);
    int tw = g.textWidth(b);
    g.drawCircle(x - tw - 10, cy, 6, timerPhase == 2 ? 0x87F0 : 0xFD20);
    g.drawLine(x - tw - 10, cy, x - tw - 10, cy - 4, timerPhase == 2 ? 0x87F0 : 0xFD20);
    x -= tw + 26;
  }
  if (WiFi.status() == WL_CONNECTED) {                         // Wi-Fi connecté
    for (int r = 4; r <= 12; r += 4) g.drawArc(x - 8, cy + 6, r, r - 1, 225, 315, 0xBDF7);
    g.fillCircle(x - 8, cy + 6, 2, 0xBDF7);
    x -= 24;
  }
  if (linkMode == 0) glyphUsb(g, x - 8, cy, 0xBDF7);
  else glyphBt(g, x - 8, cy, bleLinked() ? (uint16_t)0x253F : (uint16_t)0x7BCF);
  x -= 26;
  if (joyNav) {
    g.setFont(FONT_S);
    g.setTextDatum(middle_right);
    g.setTextColor(0xFFE0);
    g.drawString("JOY", x, cy);
    x -= g.textWidth("JOY") + 10;
  }
  if (mode == M_MENU && !cur.pages.isNull() && cur.pages.size() > 1) {
    int n = cur.pages.size();
    for (int i = n - 1; i >= 0; i--) {
      g.fillCircle(x - 5, cy, (i == cur.page) ? 4 : 3, (i == cur.page) ? TFT_WHITE : 0x7BCF);
      x -= 14;
    }
    x -= 6;
  }

  int tx = 10;                                                   // à gauche : retour + titre (ou message bref)
  bool showBack = (mode != M_MENU) || !stack.empty();
  if (showBack) {
    g.fillTriangle(14, cy, 24, cy - 9, 24, cy + 9, TFT_WHITE);
    tx = 36;
  }
  g.setFont(FONT_M);
  g.setTextDatum(middle_left);
  String title;
  if (millis() < toastUntil) { title = toastText; g.setTextColor(TFT_YELLOW); }
  else {
    g.setTextColor(TFT_WHITE);
    if (mode == M_PAD) title = "Pad 3D";
    else if (mode == M_VOL) title = "Volume";
    else if (mode == M_GAMES) title = "Jeux";
    else if (mode == M_WEATHER) title = "Météo";
    else if (mode == M_SHORT) title = "Raccourcis";
    else if (mode == M_JUMP || mode == M_SNAKE) title = gameHud;
    else { for (auto& l : stack) title += l.name + " > "; title += cur.name; }
  }
  while (title.length() > 3 && g.textWidth(title) > x - tx - 8) title.remove(isGameMode() ? title.length() - 1 : 0, 1);
  g.drawString(title, tx, cy);
  if (mode == M_MENU && millis() >= toastUntil) {               // petit triangle : toucher l'en-tête ouvre les raccourcis
    int ax = tx + g.textWidth(title) + 12;
    if (ax < x - 10) g.fillTriangle(ax, cy - 3, ax + 10, cy - 3, ax + 5, cy + 3, 0xBDF7);
  }
  if (ok) hdr.pushSprite(0, 0);
}
#endif

static void drawToast() {
  lcd.setFont(FONT_M);
  lcd.setTextColor(TFT_YELLOW, 0x101820);
  lcd.setTextDatum(middle_right);
  lcd.drawString(toastText + "  ", SCREEN_W - SX(28), HEADER_H / 2);
}

static void drawHeader() {
#if JC_BOARD == 2
  drawHeaderV2();
  return;
#endif
  lcd.fillRect(0, 0, SCREEN_W, HEADER_H, 0x101820);
  lcd.setFont(FONT_M);
  lcd.setTextColor(TFT_WHITE, 0x101820);
  lcd.setTextDatum(middle_left);

  String title;
  bool showBack = (mode != M_MENU) || !stack.empty();
  if (mode == M_PAD) title = "Pad 3D";
  else if (mode == M_VOL) title = "Volume";
  else {
    for (auto& l : stack) title += l.name + " > ";
    title += cur.name;
  }
  int tx = 8;
  if (showBack) {
    lcd.fillTriangle(SX(16), HEADER_H / 2, SX(24), HEADER_H / 2 - SY(7), SX(24), HEADER_H / 2 + SY(7), TFT_WHITE);
    tx = SX(34);
  }
  while (title.length() > 3 && lcd.textWidth(title) > SCREEN_W - tx - SX(150)) title.remove(0, 1);
  lcd.drawString(title, tx, HEADER_H / 2);

  {   // mode de liaison : « USB » ou « BT » (bleu = connecté, gris = en attente d'appairage)
    uint16_t col = (linkMode == 0) ? 0xBDF7 : (bleLinked() ? (uint16_t)0x253F : (uint16_t)0x7BCF);
    lcd.setFont(FONT_S);
    lcd.setTextColor(col, 0x101820);
    lcd.setTextDatum(middle_right);
    int np = (mode == M_MENU && !cur.pages.isNull() && cur.pages.size() > 1) ? (int)cur.pages.size() : 0;
    int lx = SCREEN_W - SX(36) - (np ? np * SX(10) + SX(8) : 0);
    lcd.drawString(linkMode == 0 ? "USB" : "BT", lx, HEADER_H / 2);
    if (joyNav) { lcd.setTextColor(0xFFE0, 0x101820); lcd.drawString("JOY", lx - SX(34), HEADER_H / 2); }
    lcd.setFont(FONT_M);
    lcd.setTextColor(TFT_WHITE, 0x101820);
    lcd.setTextDatum(middle_left);
  }

  if (mode == M_MENU && !cur.pages.isNull() && cur.pages.size() > 1) {
    int n = cur.pages.size();
    int x0 = SCREEN_W - SX(30) - n * SX(10);
    for (int i = 0; i < n; i++)
      lcd.fillCircle(x0 + i * SX(10), HEADER_H / 2, (i == cur.page) ? 3 : 2, (i == cur.page) ? TFT_WHITE : 0x7BCF);
  }
  lcd.fillCircle(SCREEN_W - SX(12), HEADER_H / 2, SY(5), pcConnected() ? TFT_GREEN : TFT_RED);
  if (millis() < toastUntil) drawToast();
}

// Redémarre dans le chargeur ROM de l'ESP32-S3 (équivalent de BOOT + RESET) : le téléversement Arduino fonctionne ensuite.
static void enterDownloadMode() {
  lcd.fillScreen(TFT_BLACK);
  lcd.setTextColor(TFT_WHITE);
  lcd.setTextDatum(middle_center);
  lcd.setFont(FONT_L);
  lcd.drawString("Mode programmation", SCREEN_W / 2, SCREEN_H / 2 - SY(16));
  lcd.setFont(FONT_M);
  lcd.drawString("Televersez depuis l'Arduino IDE", SCREEN_W / 2, SCREEN_H / 2 + SY(14));
  Out.println("HCD_BOOT_OK");
  Serial.flush();
  delay(400);
  usb_persist_restart(RESTART_BOOTLOADER);   // méthode officielle du cœur Arduino : rebascule la prise USB sur le chargeur ROM puis redémarre
  ESP.restart();                              // (repli si la fonction n'a pas pu s'exécuter)
}

// Tuile en dégradé vertical (haut plus clair, bas plus sombre), coins arrondis : même formule que HCD Studio.
static void tileBg(int x, int y, int w, int h, uint32_t rgb, bool pressed) {
  int r0 = (rgb >> 16) & 0xFF, g0 = (rgb >> 8) & 0xFF, b0 = rgb & 0xFF;
  if (pressed) { r0 = min(255, r0 + 60); g0 = min(255, g0 + 60); b0 = min(255, b0 + 60); }
  const int R = 8;
  for (int j = 0; j < h; j++) {
    float t = (h > 1) ? (float)j / (h - 1) : 0;
    int r = (int)((r0 + (255 - r0) * 0.10f) * (1 - t) + r0 * 0.74f * t);
    int g = (int)((g0 + (255 - g0) * 0.10f) * (1 - t) + g0 * 0.74f * t);
    int b = (int)((b0 + (255 - b0) * 0.10f) * (1 - t) + b0 * 0.74f * t);
    float dy = (j < R) ? (R - j - 0.5f) : (j >= h - R ? (j - (h - R) + 0.5f) : 0);
    int inset = dy > 0 ? (int)ceilf(R - sqrtf((float)R * R - dy * dy)) : 0;
    lcd.drawFastHLine(x + inset, y + j, w - 2 * inset, lcd.color565(r, g, b));
  }
}

static void drawCellFlat(int i, bool pressed) {
  int cw = cellW();
  int x = (i % COLS) * cw + 3;
  int y = HEADER_H + (i / COLS) * CELL_H + 3;
  int w = cw - 6, h = CELL_H - 6;
  Slot s = getSlot(i);
  if (!s.used) { lcd.fillRoundRect(x, y, w, h, 8, TFT_BLACK); return; }
  tileBg(x, y, w, h, s.color, pressed);
  lcd.setTextColor(TFT_WHITE);
  lcd.setTextDatum(middle_center);
  #if JC_BOARD == 2
  const int iconY = y + (h - ICON_PX - 26) / 2, labelDy = 16;      // tuiles plus hautes : icône centrée au-dessus du libellé
#else
  const int iconY = y + 8, labelDy = 12;
#endif
  bool hasIcon = s.icon.length() && drawIcon(s.icon.c_str(), x + (w - ICON_PX) / 2, iconY);
  bool narrow = (COLS == 4);
  if (hasIcon) lcd.setFont(narrow ? FONT_S : FONT_M);
  else lcd.setFont(narrow ? FONT_M : FONT_L);
  String label = s.label;
  while (label.length() > 2 && lcd.textWidth(label) > w - 6) label.remove(label.length() - 1);
  lcd.drawString(label, x + w / 2, hasIcon ? y + h - labelDy : y + h / 2);
  if (s.folder) lcd.fillTriangle(x + w - 14, y + 6, x + w - 6, y + 11, x + w - 14, y + 16, TFT_WHITE);
  if (joyNav && mode == M_MENU && i == navSel) {         // tuile sélectionnée au joystick
    lcd.drawRoundRect(x, y, w, h, 8, TFT_WHITE);
    lcd.drawRoundRect(x + 1, y + 1, w - 2, h - 2, 7, TFT_WHITE);
    lcd.drawRoundRect(x + 2, y + 2, w - 4, h - 4, 6, 0x07FF);
  }
}

#if JC_BOARD == 2
// ---- Tuiles en relief (V2) : une touche bombée posée sur son socle. À l'appui, la face descend sur le socle.
// La tuile est dessinée d'abord en mémoire (PSRAM) puis envoyée d'un bloc : pas de scintillement.
// Même rendu que l'aperçu de JCharles desktop (widgets.py, _paint_tile_relief).
static LGFX_Sprite tileSpr(&lcd);
static bool tileSprOk = false;
static const int RELIEF_D = 7, RELIEF_R = 12;          // hauteur du socle visible, rayon des coins

static uint16_t shade(uint32_t rgb, float k, float toWhite = 0) {   // k : assombrit (<1) ; toWhite : éclaircit vers le blanc
  int c[3] = {(int)(rgb >> 16) & 0xFF, (int)(rgb >> 8) & 0xFF, (int)rgb & 0xFF};
  for (int i = 0; i < 3; i++) c[i] = constrain((int)((c[i] + (255 - c[i]) * toWhite) * k), 0, 255);
  return lcd.color565(c[0], c[1], c[2]);
}

static uint16_t blend565(uint16_t a, uint16_t b, float t) {   // t = part de a (0..1)
  int ar = (a >> 11) & 31, ag = (a >> 5) & 63, ab = a & 31, br = (b >> 11) & 31, bg = (b >> 5) & 63, bb = b & 31;
  return ((int)(br + (ar - br) * t) << 11) | ((int)(bg + (ag - bg) * t) << 5) | (int)(bb + (ab - bb) * t);
}

// rectangle aux coins arrondis rempli d'un dégradé vertical (haut -> bas).
// smooth : bords des coins lissés (mélange avec le fond) — seulement dans un tampon mémoire (lisible).
static void roundGrad(LovyanGFX& g, int x, int y, int w, int h, int R, uint32_t rgb, float kTop, float wTop, float kBot, float wBot,
                      bool smooth = false) {
  for (int j = 0; j < h; j++) {
    float t = (h > 1) ? (float)j / (h - 1) : 0;
    uint16_t c = shade(rgb, kTop + (kBot - kTop) * t, wTop + (wBot - wTop) * t);
    float dy = (j < R) ? (R - j - 0.5f) : (j >= h - R ? (j - (h - R) + 0.5f) : 0);
    if (dy <= 0) { g.drawFastHLine(x, y + j, w, c); continue; }
    float e = R - sqrtf((float)R * R - dy * dy);           // bord exact du coin, en pixels
    int inset = (int)ceilf(e);
    g.drawFastHLine(x + inset, y + j, w - 2 * inset, c);
    if (smooth && inset > 0) {
      float cov = inset - e;                               // part du pixel de bord couverte par la tuile
      if (cov > 0.02f) {
        int xl = x + inset - 1, xr = x + w - inset;
        g.drawPixel(xl, y + j, blend565(c, g.readPixel(xl, y + j), cov));
        g.drawPixel(xr, y + j, blend565(c, g.readPixel(xr, y + j), cov));
      }
    }
  }
}

static void drawCellRelief(int i, bool pressed) {
  int cw = cellW();
  int x0 = (i % COLS) * cw + 3, y0 = HEADER_H + (i / COLS) * CELL_H + 3;
  int w = cw - 6, h = CELL_H - 6;
  if (!tileSprOk || tileSpr.width() != w || tileSpr.height() != h) {     // tampon de la taille d'une tuile (3 ou 4 colonnes)
    tileSpr.deleteSprite();
    tileSprOk = makeSprite(tileSpr, w, h);
  }
  LovyanGFX& g = tileSprOk ? (LovyanGFX&)tileSpr : (LovyanGFX&)lcd;
  int ox = tileSprOk ? 0 : x0, oy = tileSprOk ? 0 : y0;
  if (wallOk && tileSprOk) pushRaw565(&tileSpr, -x0, -y0, SCREEN_W, SCREEN_H, wall);    // le fond d'écran passe derrière
  else g.fillRect(ox, oy, w, h, TFT_BLACK);
  Slot s = getSlot(i);
  if (s.used) {
    const int D = RELIEF_D, R = RELIEF_R;
    int fy = oy + (pressed ? D - 2 : 0), fh = h - D;              // face de la touche (descend à l'appui)
    roundGrad(g, ox, oy + D, w, h - D, R, s.color, 0.50f, 0, 0.30f, 0, tileSprOk);               // socle (flanc sombre)
    roundGrad(g, ox, fy, w, fh, R, s.color, 1.0f, pressed ? 0.32f : 0.22f, 0.82f, 0, tileSprOk); // face bombée
    g.drawFastHLine(ox + R, fy + 1, w - 2 * R, shade(s.color, 1.0f, 0.60f));                     // reflet en haut
    g.drawFastHLine(ox + R / 2, fy + 2, w - R, shade(s.color, 1.0f, 0.38f));
    if (pressed && touchX >= 0) {                                 // rond lumineux à l'endroit touché
      int cx = constrain(touchX - x0, R, w - R) + ox, cyy = constrain(touchY - y0, R, fh - R) + fy;
      g.fillCircle(cx, cyy, 30, shade(s.color, 1.0f, 0.30f));
      g.fillCircle(cx, cyy, 18, shade(s.color, 1.0f, 0.45f));
    }
    // valeur en direct (PC, heure) ou temps restant du minuteur : remplace l'icône
    String live;
    const char* lk = s.item["live"] | "";
    if (*lk) {
      int li = liveIndex(lk);
      struct tm tm;
      if (li >= 0) live = liveVal[li];
      else if (!strcmp(lk, "weather")) live = wxTileText();
      else if (!strcmp(lk, "clock") && localTm(tm)) { char b[8]; snprintf(b, sizeof(b), "%02d:%02d", tm.tm_hour, tm.tm_min); live = b; }
    }
    if (s.isMode && timerMode.length() && timerMode == (const char*)(s.item["mode"] | "")) {
      long left = max(0L, (long)(tmrEnd - millis()) / 1000 + 1);
      if ((long)(tmrEnd - millis()) <= 0) left = 0;
      char b[12];
      snprintf(b, sizeof(b), "%ld:%02ld", left / 60, left % 60);
      live = b;
    } else if (s.isMode) {                                     // minuteur à l'arrêt : sa durée
      const char* md = s.item["mode"] | "";
      if (!strcmp(md, "pomodoro")) live = "25:00";
      else if (!strncmp(md, "timer", 5)) live = String(atoi(md + (md[5] == ':' ? 6 : 5))) + ":00";
    }
    bool narrow = (COLS == 4);
    bool hasIcon = false;
    if (live.length()) {
      g.setFont(live.length() > 7 ? (narrow ? FONT_S : FONT_M) : FONT_L);
      g.setTextDatum(middle_center);
      String v = live;
      while (v.length() > 2 && g.textWidth(v) > w - 12) v.remove(v.length() - 1);
      if (v.length() < live.length()) v += ".";
      g.setTextColor(shade(s.color, 0.35f));
      g.drawString(v, ox + w / 2 + 1, fy + fh * 2 / 5 + 1);
      g.setTextColor(TFT_WHITE);
      g.drawString(v, ox + w / 2, fy + fh * 2 / 5);
      hasIcon = true;                                          // le nom passe en bas, en petit
    } else {
      hasIcon = s.icon.length() && drawIcon(s.icon.c_str(), ox + (w - ICON_PX) / 2, fy + (fh - ICON_PX - 26) / 2, &g);
    }
    if (hasIcon) g.setFont(narrow ? FONT_S : FONT_M);
    else g.setFont(narrow ? FONT_M : FONT_L);
    g.setTextDatum(middle_center);
    String label = s.label;
    while (label.length() > 2 && g.textWidth(label) > w - 10) label.remove(label.length() - 1);
    int ty = hasIcon ? fy + fh - 16 : fy + fh / 2;
    g.setTextColor(shade(s.color, 0.35f));                    // ombre portée du texte
    g.drawString(label, ox + w / 2 + 1, ty + 1);
    g.setTextColor(TFT_WHITE);
    g.drawString(label, ox + w / 2, ty);
    if (s.folder) g.fillTriangle(ox + w - 16, fy + 8, ox + w - 7, fy + 13, ox + w - 16, fy + 18, TFT_WHITE);
    if (i == flashSlot && millis() < flashUntil) {               // coche : l'action est partie
      int cx = ox + w - 20, cyy = fy + 20;
      g.fillSmoothCircle(cx, cyy, 13, TFT_WHITE);
      g.drawWideLine(cx - 6, cyy, cx - 2, cyy + 5, 2.0f, 0x2D85);
      g.drawWideLine(cx - 2, cyy + 5, cx + 7, cyy - 6, 2.0f, 0x2D85);
    }
    if (joyNav && mode == M_MENU && i == navSel) {               // tuile sélectionnée au joystick
      g.drawRoundRect(ox, fy, w, fh, R, TFT_WHITE);
      g.drawRoundRect(ox + 1, fy + 1, w - 2, fh - 2, R - 1, TFT_WHITE);
      g.drawRoundRect(ox + 2, fy + 2, w - 4, fh - 4, R - 2, 0x07FF);
    }
  }
  if (tileSprOk) tileSpr.pushSprite(x0, y0);
}
#endif

#if JC_BOARD == 2
// ---- Curseur de volume à droite du menu (V2) : glisser le doigt règle le son, l'icône du haut coupe/remet.
static const int VB_MUTE_H = 44;                               // zone de l'icône (couper le son)
static int vbTop() { return HEADER_H + VB_MUTE_H + 4; }
static int vbBot() { return SCREEN_H - 30; }
static int vbLevelFromY(int y) {
  int l = (vbBot() - y) * 100 / (vbBot() - vbTop());
  return constrain((l + 1) / 2 * 2, 0, 100);                   // pas de 2 %, comme les touches volume de Windows
}
static void drawSideVol() {
  if (!hw.volBar || mode != M_MENU || saverOn) return;
  static LGFX_Sprite sp(&lcd);
  static bool ok = false;
  const int x0 = SCREEN_W - VB_W, h = SCREEN_H - HEADER_H;
  if (!ok) ok = makeSprite(sp, VB_W, h);
  LovyanGFX& g = ok ? (LovyanGFX&)sp : (LovyanGFX&)lcd;
  int ox = ok ? 0 : x0, oy = ok ? 0 : HEADER_H;
  if (wallOk && ok) pushRaw565(&sp, -x0, -HEADER_H, SCREEN_W, SCREEN_H, wall);
  else g.fillRect(ox, oy, VB_W, h, TFT_BLACK);
  // haut-parleur
  int cx = ox + VB_W / 2 - 4, cy = oy + VB_MUTE_H / 2 + 2;
  uint16_t ic = volMuted ? (uint16_t)0xF8A2 : (uint16_t)0xD69A;
  g.fillRect(cx - 9, cy - 4, 6, 8, ic);
  g.fillTriangle(cx - 4, cy - 4, cx + 3, cy - 10, cx + 3, cy + 10, ic);
  g.fillTriangle(cx - 4, cy + 4, cx + 3, cy - 10, cx + 3, cy + 10, ic);
  if (volMuted) {
    g.drawWideLine(cx + 8, cy - 5, cx + 16, cy + 5, 1.5f, ic);
    g.drawWideLine(cx + 8, cy + 5, cx + 16, cy - 5, 1.5f, ic);
  } else {
    g.drawArc(cx + 3, cy, 9, 8, -50, 50, ic);
    g.drawArc(cx + 3, cy, 15, 14, -50, 50, ic);
  }
  // rail, remplissage, bouton
  const int tw = 20, tx = ox + (VB_W - tw) / 2;
  int t = vbTop() - HEADER_H + oy, b = vbBot() - HEADER_H + oy;
  int ky = b - (b - t) * volLevel / 100;
  g.fillRoundRect(tx, t - 6, tw, b - t + 12, tw / 2, 0x2124);
  uint16_t fc = volMuted ? (uint16_t)0x7BCF : (uint16_t)0x2CDC;
  if (b - ky > 0) g.fillRoundRect(tx, ky - 6, tw, b - ky + 12, tw / 2, fc);
  g.fillRoundRect(tx - 5, ky - 11, tw + 10, 22, 11, TFT_WHITE);
  g.drawRoundRect(tx - 5, ky - 11, tw + 10, 22, 11, 0x8410);
  g.setFont(FONT_S);
  g.setTextDatum(middle_center);
  g.setTextColor(0xDEFB);
  g.drawString(String(volLevel), ox + VB_W / 2, oy + h - 14);
  if (ok) sp.pushSprite(x0, HEADER_H);
}
// Amène le volume du PC au niveau voulu par des appuis « volume + / - » (2 % chacun).
static void sideVolTo(int target) {
  int n = 0;
  while (volLevel != target && n++ < 50) {
    bool up = target > volLevel;
    sendConsumer(up ? "vol_up" : "vol_down");
    volLevel = constrain(volLevel + (up ? 2 : -2), 0, 100);
    if (up) volMuted = false;                                     // Windows remet le son en montant le volume
  }
  drawSideVol();
}
#endif

static void drawCell(int i, bool pressed) {
#if JC_BOARD == 2
  drawCellRelief(i, pressed);
#else
  drawCellFlat(i, pressed);
#endif
}

// --- Pad 3D : disposition ---
static const int PAD_BTN_Y = SY(196), PAD_BTN_H = SCREEN_H - PAD_BTN_Y, PAD_BTN_N = 5;
static const int PAD_ZOOM_X = SX(262);
static const char* PAD_BTN_LABEL[PAD_BTN_N] = {"Orbite", "Pan", "X 180", "Y 180", "Vue"};

static void drawPad() {
  lcd.fillScreen(TFT_BLACK);
  drawHeader();
  lcd.fillRoundRect(4, HEADER_H + 4, PAD_ZOOM_X - 8, PAD_BTN_Y - HEADER_H - 8, 10, 0x2124);
  lcd.setFont(FONT_M);
  lcd.setTextColor(0x8410);
  lcd.setTextDatum(middle_center);
  lcd.drawString(padPan ? "Glisser : deplacer" : "Glisser : tourner", PAD_ZOOM_X / 2, (HEADER_H + PAD_BTN_Y) / 2);
  lcd.fillRoundRect(PAD_ZOOM_X + 4, HEADER_H + 4, SCREEN_W - PAD_ZOOM_X - 8, PAD_BTN_Y - HEADER_H - 8, 10, 0x2945);
  lcd.setTextColor(0xFFFF);
  lcd.drawString("Zoom", PAD_ZOOM_X + (SCREEN_W - PAD_ZOOM_X) / 2, (HEADER_H + PAD_BTN_Y) / 2);
  int bw = SCREEN_W / PAD_BTN_N;
  for (int i = 0; i < PAD_BTN_N; i++) {
    bool active = (i == 0 && !padPan) || (i == 1 && padPan);
    lcd.fillRoundRect(i * bw + 2, PAD_BTN_Y + 2, bw - 4, PAD_BTN_H - 4, 8, active ? 0xE3A0 : 0x3A49);
    lcd.setTextColor(TFT_WHITE);
    lcd.drawString(PAD_BTN_LABEL[i], i * bw + bw / 2, PAD_BTN_Y + PAD_BTN_H / 2);
  }
}

// --- Volume : disposition ---
static const int VOL_X = SX(120), VOL_W = SX(80), VOL_Y = HEADER_H + SY(14), VOL_H = SY(150);
static const int VOL_MUTE_Y = SY(200), VOL_MUTE_X = SX(100), VOL_MUTE_W = SX(120), VOL_MUTE_H = SY(34);

static void drawVolBar() {
  lcd.fillRoundRect(VOL_X, VOL_Y, VOL_W, VOL_H, 12, 0x2124);
  int fh = VOL_H * volLevel / 100;
  if (fh > 0) lcd.fillRoundRect(VOL_X, VOL_Y + VOL_H - fh, VOL_W, fh, 12, 0x2EA9);
  lcd.setFont(FONT_L);
  lcd.setTextColor(TFT_WHITE, TFT_BLACK);
  lcd.setTextDatum(middle_center);
  lcd.drawString(String(volLevel) + "%  ", VOL_X / 2, VOL_Y + SY(40));
}

static void drawVol() {
  lcd.fillScreen(TFT_BLACK);
  drawHeader();
  drawVolBar();
  lcd.setFont(FONT_M);
  lcd.setTextColor(0x8410);
  lcd.setTextDatum(middle_center);
  lcd.drawString("Glisser", SX(60), VOL_Y + SY(100));
  lcd.drawString("(niveau estime)", SX(260), VOL_Y + SY(100));
  lcd.fillRoundRect(VOL_MUTE_X, VOL_MUTE_Y, VOL_MUTE_W, VOL_MUTE_H, 8, 0xC000);
  lcd.setTextColor(TFT_WHITE);
  lcd.drawString("Muet", VOL_MUTE_X + VOL_MUTE_W / 2, VOL_MUTE_Y + VOL_MUTE_H / 2);
}

static void drawAll() {
  if (mode == M_PAD) { drawPad(); return; }
  if (mode == M_VOL) { drawVol(); return; }
#if JC_BOARD == 2
  if (saverOn) { drawSaver(); return; }
  if (isGameMode()) { lcd.fillScreen(TFT_BLACK); drawHeader(); gamesDraw(); return; }
  if (mode == M_WEATHER) { drawHeader(); drawWeather(); return; }
  if (mode == M_SHORT) { lcd.fillScreen(TFT_BLACK); drawHeader(); drawShortcuts(); return; }
  if (wallOk) pushRaw565(&lcd, 0, 0, SCREEN_W, SCREEN_H, wall);
  else lcd.fillScreen(TFT_BLACK);
#else
  lcd.fillScreen(TFT_BLACK);
#endif
  drawHeader();
  for (int i = 0; i < slots(); i++) drawCell(i, false);
#if JC_BOARD == 2
  drawSideVol();
#endif
}

// ---------------------------------------------------------- Navigation ------
static void enterMode(Mode m) { mode = m; drawAll(); }

static void goBack() {
#if JC_BOARD == 2
  if (mode == M_JUMP || mode == M_SNAKE) { mode = M_GAMES; drawAll(); return; }
#endif
  if (mode != M_MENU) { mode = M_MENU; drawAll(); return; }
  if (stack.empty()) return;
  cur = stack.back();
  stack.pop_back();
  navSel = 0;
  drawAll();
}

static void changePage(int delta) {
  int n = cur.pages.isNull() ? 0 : (int)cur.pages.size();
  if (n < 2) return;
  cur.page = (cur.page + delta + n) % n;
  drawAll();
}

static void goHomeAndDraw() { goHome(); navSel = 0; drawAll(); }

static void activate(int slot) {
  Slot s = getSlot(slot);
  if (!s.used) return;
  if (s.folder) {
    stack.push_back(cur);
    Level nl;
    nl.pages = s.item["pages"].as<JsonArrayConst>();
    nl.page = 0;
    nl.name = s.label;
    cur = nl;
    navSel = 0;
    drawAll();
  } else if (s.isMode) {
    const char* m = s.item["mode"] | "";
    if (!strcmp(m, "pad")) enterMode(M_PAD);
    else if (!strcmp(m, "volume")) enterMode(M_VOL);
#if JC_BOARD == 2
    else if (!strcmp(m, "weather")) enterMode(M_WEATHER);
    else if (!strcmp(m, "games")) {
      if (hw.games) enterMode(M_GAMES); else toast("Jeux desactives");
    } else if (!strncmp(m, "timer", 5) || !strcmp(m, "pomodoro")) {
      if (timerMode == m) {                                     // deuxième appui : arrêt
        timerMode = ""; alarmUntil = 0;
        toast("Minuteur arrete");
      } else {
        bool pomo = !strcmp(m, "pomodoro");
        int minutes = pomo ? 25 : constrain(atoi(m + (m[5] == ':' ? 6 : 5)), 1, 600);
        timerMode = m; timerPhase = pomo ? 1 : 0; alarmUntil = 0;
        tmrEnd = millis() + minutes * 60000UL;
        toast(pomo ? "Pomodoro : 25 min de travail" : (String("Minuteur ") + minutes + " min").c_str());
      }
      drawCell(slot, false);
    }
#else
    else toast("Pad V2 seulement");
#endif
  } else {
    execute(s.item);
#if JC_BOARD == 2
    flashSlot = slot; flashUntil = millis() + 550;
    drawCell(slot, false);
#endif
  }
}

static void activateLong(int slot) {
  Slot s = getSlot(slot);
  if (!s.used || s.folder || s.isMode) return;
  JsonVariantConst l = s.item["long"];
  if (!l.isNull()) {
    execute(l);
#if JC_BOARD == 2
    flashSlot = slot; flashUntil = millis() + 550;
    drawCell(slot, false);
#endif
  }
}

// --- Pad 3D tactile : actions ---
static void orbitBegin() {
  if (!padPan) keyboard.press(KEY_LEFT_SHIFT);
  mouse.press(MOUSE_MIDDLE);
}
static void orbitEnd() { mouse.release(MOUSE_MIDDLE); keyboard.releaseAll(); }

static void rotate180(bool horizontal) {
  keyboard.press(KEY_LEFT_SHIFT);
  mouse.press(MOUSE_MIDDLE);
  delay(30);
  int total = hw.rot180;
  while (total > 0) {
    int s = min(total, 40);
    mouse.move(horizontal ? s : 0, horizontal ? 0 : s);
    total -= s;
    delay(8);
  }
  delay(30);
  orbitEnd();
}

static void padButton(int i) {
  if (i == 0) { padPan = false; drawPad(); }
  else if (i == 1) { padPan = true; drawPad(); }
  else if (i == 2) rotate180(false);
  else if (i == 3) rotate180(true);
  else if (i == 4) { keyboard.press(KEY_HOME); delay(25); keyboard.releaseAll(); }
}

// ------------------------------------------------------------------- LED ----
static uint32_t ledShown[LED_COUNT];
static int pwmShown[4] = {-1, -1, -1, -1};

static uint32_t scaleRgb(uint32_t rgb, int level) {
  int m = constrain(level, 0, 255) * ledMaster / 255;
  uint32_t r = ((rgb >> 16) & 0xFF) * m / 255;
  uint32_t g = ((rgb >> 8) & 0xFF) * m / 255;
  uint32_t b = (rgb & 0xFF) * m / 255;
  return (r << 16) | (g << 8) | b;
}

static void ledPwm(int idx, int level) {
  int m = constrain(level, 0, 255) * ledMaster / 255;
  int duty = (m * m) / 255;
  if (duty == pwmShown[idx]) return;
  pwmShown[idx] = duty;
  ledcWrite(idx < 3 ? PIN_LED_KEY[idx] : PIN_LED_STATUS, duty);
}

static void ledTask() {
  static uint32_t last = 0;
  uint32_t now = millis();
  if (now - last < 20) return;
  last = now;

  static bool charging = false;
  static uint8_t lowCount = 0;
  if (hw.chrgDetect) {                         // plot CHRG du TP4056 : bas = charge en cours (filtré ~0,4 s)
    if (digitalRead(PIN_CHRG) == LOW) { if (lowCount < 20) lowCount++; } else { if (lowCount > 0) lowCount--; }
    if (lowCount >= 15) charging = true; else if (lowCount <= 3) charging = false;
  } else charging = false;
  if (charging) {                              // respiration lente de la LED verte
    uint32_t ph = now % 2000;
    int tri = ph < 1000 ? ph : 2000 - ph;      // 0..1000
    ledPwm(3, hw.ledStatus * (80 + tri * 175 / 1000) / 255);
  } else ledPwm(3, hw.ledStatus);
  for (int k = 0; k < 3; k++) {
    int lv = 0;
    if (hw.ledKeys > 0) {
      switch (keyCfg[k].mode) {
        case 1: lv = keyDown[k] ? hw.ledKeys : 0; break;
        case 2: lv = keyToggled[k] ? hw.ledKeys : 0; break;
        case 3: lv = keyDown[k] ? hw.ledKeys : hw.ledKeys * 35 / 100; break;
        default: lv = 0;
      }
    }
    ledPwm(k, lv);
  }

  uint32_t bar = 0;
  bool active = T.down || keyDown[0] || keyDown[1] || keyDown[2] || millis() < activityUntil;
  if (hw.ledBar > 0 && (hw.barMode == B_SOLID || (hw.barMode == B_TOUCH && active)))
    bar = scaleRgb(hw.barColor, hw.ledBar);
#if JC_BOARD == 2
  if (alarmUntil && now < alarmUntil)                      // fin du minuteur : le ruban clignote
    bar = ((now / 350) % 2) ? scaleRgb(alarmColor, max(hw.ledBar, 160)) : 0;
#endif
  if (!stripReady) return;
  if (stripSimpleInit) {                    // ruban simple : luminosité seule (couleur ignorée), PWM sur la broche
    static int lastDuty = -1;
    int duty = 0;
    if (bar) duty = max((int)((bar >> 16) & 0xFF), max((int)((bar >> 8) & 0xFF), (int)(bar & 0xFF))) * ledMaster / 255;
    if (duty != lastDuty) { lastDuty = duty; ledcWrite(PIN_LEDS, duty); }
    return;
  }

  bool changed = ledForce;
  for (int i = LED_BAR_IX; i < LED_COUNT; i++) {
    if (bar != ledShown[i]) { ledShown[i] = bar; strip.setPixelColor(i, bar); changed = true; }
  }
  if (changed) { strip.show(); ledForce = false; }
}

// -------------------------------------------------------- Touches physiques -
static void keyTask() {
  static bool raw[3] = {false, false, false};
  static bool longDone[3] = {false, false, false};
  static uint32_t tChange[3] = {0, 0, 0}, tDown[3] = {0, 0, 0};
  static bool cand[3] = {false, false, false};
  static uint32_t tSeen[3] = {0, 0, 0};
  uint32_t now = millis();
  for (int k = 0; k < 3; k++) {
    bool p = (digitalRead(PIN_KEY[k]) == (hw.keyTouch ? HIGH : LOW));
    JsonVariantConst kk = menuDoc["keys"][k];
    if (p != cand[k]) { cand[k] = p; tSeen[k] = now; }          // nouvel état : on attend qu'il soit stable
    // Un appui doit durer touchMs (touches sensitives, réglable) ou 25 ms (touches mécaniques) ; relâcher : 25 ms.
    uint32_t need = (p && hw.keyTouch) ? (uint32_t)hw.touchMs : 25;
    if (p != raw[k] && now - tSeen[k] >= need) {
      raw[k] = p; tChange[k] = now;
      markActivity();
      if (p) {
        keyDown[k] = true; longDone[k] = false; tDown[k] = now;
        comboUsed[k] = false;
        if (keyCfg[k].mode == 2) keyToggled[k] = !keyToggled[k];
#if JC_BOARD == 2
        if (alarmUntil) alarmUntil = 1;                            // une touche arrête le clignotement
        if (isGameMode()) continue;                                // pendant un jeu, les touches servent au jeu
#endif
        if (!keyCfg[k].hasLong && !keyCfg[k].hasCombo) execute(kk);
      } else {
        keyDown[k] = false;
#if JC_BOARD == 2
        if (isGameMode()) continue;
#endif
        if ((keyCfg[k].hasLong || keyCfg[k].hasCombo) && !longDone[k] && !comboUsed[k]) execute(kk);
      }
    } else if (raw[k] && keyCfg[k].hasLong && !longDone[k] && !comboUsed[k] && now - tDown[k] >= LONG_PRESS_MS
#if JC_BOARD == 2
               && !isGameMode()
#endif
               ) {
      longDone[k] = true;
      execute(kk["long"]);
    }
  }
}

// ------------------------------------------------------------ Potentiomètre -
static void potTask() {
  static uint32_t last = 0;
  static float ema = -1;
  static int acted = -1000, step = -1, lastPct = -1, lastFn = -1;
  uint32_t now = millis();
  if (now - last < 35) return;
  last = now;
  int ck = -1, fn = hw.pot;                       // touche maintenue + potentiomètre : autre réglage
  for (int i = 0; i < nCombos; i++)
    if (combos[i].src == 0 && keyDown[combos[i].key]) { ck = combos[i].key; fn = combos[i].fn; break; }
  if (fn != lastFn) { step = -1; lastPct = -1; lastFn = fn; }
  if (fn == P_OFF) { ema = -1; return; }

  int raw = readADC(PIN_POT);
  ema = (ema < 0) ? raw : ema * 0.85f + raw * 0.15f;
  if (abs((int)ema - acted) < 60) return;
  acted = (int)ema;
  markActivity();
  if (ck >= 0) comboUsed[ck] = true;
  int v = hw.potInv ? 4095 - acted : acted;
  int pct = constrain(v * 100 / 4095, 0, 100);

  switch (fn) {
    case P_VOL_USB: {
      int s = pct / 2;
      if (step < 0) { step = s; break; }
      if (step != s) {
        sendConsumer(s > step ? "vol_up" : "vol_down");
        step += (s > step) ? 1 : -1;
        toast(String("Vol ") + String(step * 2) + "%");
      }
      break;
    }
    case P_VOL_PC:
      if (pct != lastPct) { lastPct = pct; Out.printf("HCD_POT %d\n", pct); toast(String("Vol ") + pct + "%"); }
      break;
    case P_SCREEN:
      lcd.setBrightness(map(pct, 0, 100, 10, 255));
      toast(String("Ecran ") + pct + "%");
      break;
    case P_LED:
      ledMaster = map(pct, 0, 100, 0, 255);
      ledForce = true;
      toast(String("LED ") + pct + "%");
      break;
    case P_PCBRI:                                  // luminosité des écrans du PC (réglée par le logiciel)
      if (pct != lastPct) { lastPct = pct; Out.printf("HCD_POTBRI %d\n", pct); toast(String("Ecrans PC ") + pct + "%"); }
      break;
    case P_MIC:
      if (pct != lastPct) { lastPct = pct; Out.printf("HCD_POTMIC %d\n", pct); toast(String("Micro ") + pct + "%"); }
      break;
    default: break;
  }
}

// ----------------------------------------------------------------- Joystick -
static float joyCx = 2048, joyCy = 2048;     // centre mesuré (suivi lentement)
static int joyNoiseX = 0, joyNoiseY = 0;      // bruit mesuré au repos, par axe (points ADC)
static bool joyHeld = false, joyPan = false;
static bool joyDebug = false;

static void joyCalibrate() {
  delay(300);                                  // laisse les tensions se stabiliser (LED, rétroéclairage)
  const int N = 48;
  int xs[N], ys[N];
  long sx = 0, sy = 0;
  for (int i = 0; i < N; i++) {
    xs[i] = readADC(PIN_JOY_X); ys[i] = readADC(PIN_JOY_Y);
    sx += xs[i]; sy += ys[i];
    delay(4);
  }
  joyCx = sx / (float)N; joyCy = sy / (float)N;
  int dx = 0, dy = 0;
  for (int i = 0; i < N; i++) { dx = max(dx, abs(xs[i] - (int)joyCx)); dy = max(dy, abs(ys[i] - (int)joyCy)); }
  joyNoiseX = dx; joyNoiseY = dy;
}

static void joyRelease() {
  if (joyHeld) { mouse.release(MOUSE_MIDDLE); keyboard.releaseAll(); joyHeld = false; }
}

// zone morte en points ADC, par axe : le réglage (%) ou 3 x le bruit mesuré sur cet axe, plafonnée à 900
// (un axe très bruité ne désactive plus l'autre axe)
static float joyDeadCounts(int noise) {
  float base = hw.joyDead / 100.0f * 2047.0f;
  return min(900.0f, max(base, noise * 3.0f + 40.0f));
}

// d = écart au centre (points ADC) -> -1..1 avec zone morte puis courbe douce
static float joyNorm(float d, float dz) {
  float a = fabsf(d);
  if (a <= dz) return 0;
  float span = max(400.0f, 2047.0f - dz);
  a = constrain((a - dz) / span, 0.0f, 1.0f);
  a = a * a;
  return d < 0 ? -a : a;
}

// dir : 1 haut, 2 bas, 3 gauche, 4 droite. Déplace la sélection ; en butée gauche/droite, change de page.
static void navMove(int dir) {
  JsonArrayConst items = curItems();
  int n = items.isNull() ? 0 : (int)items.size();
  if (n == 0) return;
  int old = navSel, ns = navSel;
  int np = cur.pages.isNull() ? 0 : (int)cur.pages.size();
  if (dir == 4) {
    ns++;
    if (ns >= n) {
      if (np > 1) { navSel = 0; changePage(+1); return; }
      ns = old;
    }
  } else if (dir == 3) {
    ns--;
    if (ns < 0) {
      if (np > 1) {
        int prev = (cur.page + np - 1) % np;
        int pn = cur.pages[prev]["items"].size();
        navSel = max(0, pn - 1);
        changePage(-1);
        return;
      }
      ns = old;
    }
  } else if (dir == 2) {
    ns += COLS;
    if (ns >= n) ns = ((n - 1) / COLS > old / COLS) ? n - 1 : old;
  } else if (dir == 1) {
    ns -= COLS;
    if (ns < 0) ns = old;
  }
  if (ns == old) return;
  navSel = ns;
  drawCell(old, false);
  drawCell(ns, false);
}

static void joyTask() {
  static uint32_t last = 0, tSw = 0, tDbg = 0, tCalm = 0;
  static float ax = 0, ay = 0, fx = -1, fy = -1;
  static bool swRaw = false, leftHeld = false;
  uint32_t now = millis();
  if (now - last < 10) return;
  last = now;
#if JC_BOARD == 2
  if (isGameMode()) { if (joyHeld) joyRelease(); return; }
#endif
  bool navActive = joyNav && mode == M_MENU;
  bool comboJoy = false;                           // une touche maintenue a des combinaisons avec le joystick
  for (int i = 0; i < nCombos; i++) if (combos[i].src >= 1 && keyDown[combos[i].key]) comboJoy = true;
  if (hw.joy == J_OFF && !navActive && !comboJoy) return;

  // Clic joystick
  bool sw = hw.joySw && digitalRead(PIN_JOY_SW) == LOW;
  if (sw != swRaw && now - tSw > 25) {
    swRaw = sw; tSw = now;
    if (navActive) {
      // navigation : clic = ouvrir/activer la tuile, clic long = retour (dossier précédent)
      static uint32_t tPress = 0;
      if (sw) tPress = now;
      else if (now - tPress > 700) goBack();
      else activate(navSel);
    } else if (hw.joy == J_MOUSE) {
      if (sw) { mouse.press(MOUSE_LEFT); leftHeld = true; }
      else { mouse.release(MOUSE_LEFT); leftHeld = false; }
    } else if (sw && (hw.joy == J_ORBIT || hw.joy == J_PAN)) {
      joyRelease();
      joyPan = !joyPan;
      toast(((hw.joy == J_PAN) != joyPan) ? "Deplacement" : "Orbite");
    }
  }
  if (!sw && leftHeld) { mouse.release(MOUSE_LEFT); leftHeld = false; }
  if (navActive) { joyRelease(); }

  // Lecture lissée (pas de filtre sur les extrémités : le plein débattement doit rester utilisable)
  int rawX = readADC(PIN_JOY_X);
  int rawY = readADC(PIN_JOY_Y);
  fx = (fx < 0) ? rawX : fx * 0.6f + rawX * 0.4f;
  fy = (fy < 0) ? rawY : fy * 0.6f + rawY * 0.4f;

  float dzx = joyDeadCounts(joyNoiseX), dzy = joyDeadCounts(joyNoiseY);

  // Suivi lent du centre : si le manche reste au repos 1,5 s, on recale le centre (dérive, tension qui bouge)
  if (fabsf(fx - joyCx) < dzx * 0.7f && fabsf(fy - joyCy) < dzy * 0.7f) {
    if (now - tCalm > 1500) { joyCx += (fx - joyCx) * 0.02f; joyCy += (fy - joyCy) * 0.02f; }
  } else {
    tCalm = now;
  }

  float nx = joyNorm(fx - joyCx, dzx);
  float ny = joyNorm(fy - joyCy, dzy);
  if (hw.joySwap) { float t = nx; nx = ny; ny = t; }
  if (hw.joyInvX) nx = -nx;
  if (hw.joyInvY) ny = -ny;
  float speed = hw.joySpeed * 1.5f;
  joyLeftHeld = (nx < -0.6f);
  if (nx != 0 || ny != 0 || sw) markActivity();
  if (comboJoy) {                                  // touche maintenue + joystick : action de la combinaison
    static int cLast = 0;
    static uint32_t cRep = 0;
    int dir = 0;
    if (fmaxf(fabsf(nx), fabsf(ny)) > 0.6f) {
      if (fabsf(nx) > fabsf(ny)) dir = nx > 0 ? 4 : 3;
      else dir = ny > 0 ? 2 : 1;
    }
    if (joyHeld) joyRelease();
    ax = ay = 0;
    if (dir == 0) { cLast = 0; return; }
    bool first = (dir != cLast);
    if (first || now > cRep) {
      for (int i = 0; i < nCombos; i++) {
        if (combos[i].src != dir || !keyDown[combos[i].key]) continue;
        JsonVariantConst act = menuDoc["combos"][combos[i].idx]["do"];
        comboUsed[combos[i].key] = true;
        execute(act);
        const char* t = act["type"] | "";
        bool rep = !strcmp(t, "media") || !strcmp(t, "hotkey");
        cRep = rep ? now + (first ? 350 : 200) : 0xFFFFFFFFu;
        break;
      }
      cLast = dir;
    }
    return;
  }

  if (joyDebug && now - tDbg > 150) {
    tDbg = now;
    Out.printf("HCD_JOY brut X=%d Y=%d centre=%d,%d bruit=%d,%d zone=%d,%d nx=%.2f ny=%.2f\n",
                  rawX, rawY, (int)joyCx, (int)joyCy, joyNoiseX, joyNoiseY, (int)dzx, (int)dzy, nx, ny);
  }

  if (nx == 0 && ny == 0) { ax = ay = 0; }

  if (navActive) {
    static int lastDir = 0;               // 1 haut, 2 bas, 3 gauche, 4 droite
    static uint32_t tRep = 0;
    int dir = 0;
    if (fmaxf(fabsf(nx), fabsf(ny)) > 0.5f) {
      if (fabsf(nx) > fabsf(ny)) dir = nx > 0 ? 4 : 3;
      else dir = ny > 0 ? 2 : 1;
    }
    if (dir == 0) { lastDir = 0; return; }
    if (dir != lastDir) { lastDir = dir; tRep = now + 350; navMove(dir); }
    else if (now > tRep) { tRep = now + 200; navMove(dir); }
    return;
  }

  if (hw.joy == J_MOUSE) {
    ax += nx * speed; ay += ny * speed;
    int mx = (int)ax, my = (int)ay;
    ax -= mx; ay -= my;
    if (mx != 0 || my != 0) mouse.move(clamp8(mx), clamp8(my));
  } else if (hw.joy == J_ORBIT || hw.joy == J_PAN) {
    bool active = (nx != 0 || ny != 0);
    bool pan = (hw.joy == J_PAN) != joyPan;
    if (active && !joyHeld) {
      if (!pan) keyboard.press(KEY_LEFT_SHIFT);
      mouse.press(MOUSE_MIDDLE);
      joyHeld = true;
    } else if (!active && joyHeld) {
      joyRelease();
    }
    if (joyHeld) {
      ax += nx * speed; ay += ny * speed;
      int mx = (int)ax, my = (int)ay;
      ax -= mx; ay -= my;
      if (mx != 0 || my != 0) mouse.move(clamp8(mx), clamp8(my));
    }
  } else if (hw.joy == J_SCROLL) {
    ay += ny * hw.joySpeed * 0.15f;
    ax += nx * hw.joySpeed * 0.15f;
    int wy = (int)ay, wx = (int)ax;
    ay -= wy; ax -= wx;
    if (wy || wx) mouse.move(0, 0, clamp8(-wy), clamp8(wx));
  }
}

// ----------------------------------------------------- Configuration matérielle
#if JC_BOARD == 2
static void markActivity();
#include "JC_Sound.h"
// Volume du haut-parleur réglé sur le pad (toucher le haut-parleur dans l'en-tête des jeux) :
// 100 -> 75 -> 50 -> 25 -> 10 -> muet -> 100. Mémorisé dans hw.json et signalé au logiciel.
static void padSoundStep() {
  static const int STEPS[] = {100, 75, 50, 25, 10, 0};
  int nv = 100;
  for (int i = 0; i < 6; i++) if (STEPS[i] < hw.sound) { nv = STEPS[i]; break; }
  if (hw.sound == 0) nv = 100;
  hw.sound = nv;
  {
    JsonDocument d;
    File f = LittleFS.open(HW_FILE, "r");
    if (f) { deserializeJson(d, f); f.close(); }
    d["sound"] = nv;
    File w = LittleFS.open(HW_FILE, "w");
    if (w) { serializeJson(d, w); w.close(); }
  }
  Out.printf("HCD_SOUND %d\n", nv);
  drawHeader();
  if (nv > 0) sfx(SFX_COIN);
}
#include "JC_Games.h"
#include "JC_Weather.h"
#include "JC_Wifi.h"

// ---- Raccourcis (pad V2) : toucher l'en-tête du menu ouvre Météo, Jeux, Pomodoro et Volume, sans tuile à créer.
static const char* SC_NAME[4] = {"Météo", "Jeux", "Pomodoro", "Volume"};
static const uint32_t SC_COL[4] = {0x2E86C1, 0x8E44AD, 0xC0392B, 0x27AE60};
static const int SC_OFF_H = 44;          // barre « Éteindre le pad » en bas de l'écran des raccourcis
static void scRect(int i, int& x, int& y, int& w, int& h) {
  if (i == 4) { x = 10; w = SCREEN_W - 20; h = SC_OFF_H; y = SCREEN_H - SC_OFF_H - 8; return; }
  w = (SCREEN_W - 30) / 2; h = (SCREEN_H - HEADER_H - 30 - SC_OFF_H - 8) / 2;
  x = 10 + (i % 2) * (w + 10); y = HEADER_H + 10 + (i / 2) * (h + 10);
}
static void drawShortcuts() {
  gameColors();
  for (int i = 0; i < 4; i++) {
    int x, y, w, h;
    scRect(i, x, y, w, h);
    roundGrad(lcd, x, y + 6, w, h - 6, 14, SC_COL[i], 0.5f, 0, 0.3f, 0);
    roundGrad(lcd, x, y, w, h - 6, 14, SC_COL[i], 1.0f, 0.22f, 0.82f, 0);
    lcd.setBaseColor(shade(SC_COL[i], 0.9f));
    lcd.setFont(FONT_L);
    lcd.setTextDatum(middle_left);
    lcd.setTextColor(TFT_WHITE);
    lcd.drawString(SC_NAME[i], x + 16, y + 26);
    lcd.setFont(FONT_S);
    String sub = i == 0 ? (wx.ok ? String((int)lroundf(wx.t)) + "\u00B0  " + wxText(wx.code) : String("Animation et 3 jours"))
               : i == 1 ? String("Plateformes, serpent")
               : i == 2 ? (timerMode == "pomodoro" ? String("En cours : toucher pour arrêter") : String("25 min de travail, 5 de pause"))
               : String("Glisser pour régler");
    lcd.drawString(sub, x + 16, y + h - 26);
    if (i == 0) wxScene(lcd, x + w - 100, y + 4, 90, h - 40, wx.ok ? wx.code : 2, true, 0, 0.42f);
    if (i == 1) { bipRight = false; jHurtUntil = 0; bip.ground = false; jDrawBip(lcd, x + w - 50, y + h / 2 - 14); }
  }
  {   // barre « Éteindre »
    int x, y, w, h;
    scRect(4, x, y, w, h);
    roundGrad(lcd, x, y, w, h, 12, 0x3A3F47, 1.0f, 0.10f, 0.75f, 0);
    lcd.setBaseColor(0x2945);
    int cx = x + w / 2 - 92, cy = y + h / 2;
    lcd.drawArc(cx, cy, 11, 9, -60, 240, 0xF8A2);                // symbole marche/arrêt
    lcd.fillRect(cx - 1, cy - 14, 3, 12, 0xF8A2);
    lcd.setFont(FONT_M);
    lcd.setTextDatum(middle_left);
    lcd.setTextColor(TFT_WHITE);
    lcd.drawString("Éteindre le pad", cx + 22, cy);
  }
  lcd.setBaseColor(TFT_BLACK);
}
static void sleepNow();
static void padPowerOff(const char* title = "Extinction...");
static void shortcutTap(int px, int py) {
  for (int i = 0; i < 5; i++) {
    int x, y, w, h;
    scRect(i, x, y, w, h);
    if (px < x || px > x + w || py < y || py > y + h) continue;
    if (i == 4) { padPowerOff(); return; }
    if (i == 0) enterMode(M_WEATHER);
    else if (i == 1) { if (hw.games) enterMode(M_GAMES); else toast("Jeux desactives"); }
    else if (i == 3) enterMode(M_VOL);
    else {
      if (timerMode == "pomodoro") { timerMode = ""; alarmUntil = 0; toast("Pomodoro arrêté"); }
      else { timerMode = "pomodoro"; timerPhase = 1; alarmUntil = 0; tmrEnd = millis() + 25 * 60000UL; toast("Pomodoro : 25 min de travail"); }
      mode = M_MENU;
      drawAll();
    }
    return;
  }
}
#endif

static void applyHw(JsonDocument& d) {
  hw.screen = constrain(d["screen"] | hw.screen, 5, 255);
  hw.ledStatus = constrain(d["led_status"] | hw.ledStatus, 0, 255);
  hw.ledKeys = constrain(d["led_keys"] | hw.ledKeys, 0, 255);
  hw.ledBar = constrain(d["led_bar"] | hw.ledBar, 0, 255);
  hw.barMode = (BarMode)enumFrom(d["bar_mode"] | "", BAR_NAMES, 3, hw.barMode);
  hw.barColor = parseColor(d["bar_color"] | "", hw.barColor);
  hw.dimS = constrain(d["dim_s"] | hw.dimS, 0, 3600);
  hw.offS = constrain(d["off_s"] | hw.offS, 0, 7200);
  hw.sleepMin = constrain(d["sleep_min"] | hw.sleepMin, 0, 240);
  hw.chrgDetect = d["chrg_detect"] | hw.chrgDetect;
  {
    const char* st = d["strip"] | "";
    if (*st) {
      bool sv = !strcmp(st, "simple");
      if (stripReady && sv != stripSimpleInit) restartAt = millis() + 700;     // changement de type : redémarrage
      hw.stripSimple = sv;
    }
  }
  hw.pot = (PotMode)enumFrom(d["pot"] | "", POT_NAMES, 5, hw.pot);
  hw.potInv = d["pot_invert"] | hw.potInv;
  hw.joy = (JoyMode)enumFrom(d["joy"] | "", JOY_NAMES, 5, hw.joy);
  hw.joySpeed = constrain(d["joy_speed"] | hw.joySpeed, 1, 20);
  hw.joyDead = constrain(d["joy_dead"] | hw.joyDead, 0, 40);
  hw.joyInvX = d["joy_inv_x"] | hw.joyInvX;
  hw.joyInvY = d["joy_inv_y"] | hw.joyInvY;
  hw.joySwap = d["joy_swap"] | hw.joySwap;
  hw.joySw = d["joy_sw"] | hw.joySw;
  {
    bool nv = d["joy_nav"] | hw.joyNav;
    if (nv != hw.joyNav) { hw.joyNav = nv; joyNav = nv; navSel = 0; }
  }
  hw.rot180 = constrain(d["rot180"] | hw.rot180, 50, 5000);
  hw.battShow = d["batt"] | hw.battShow;
  hw.volBar = d["volbar"] | hw.volBar;
  hw.games = d["games"] | hw.games;
  hw.touchMs = constrain(d["touchms"] | hw.touchMs, 20, 600);
  hw.touchZ = constrain(d["touchz"] | hw.touchZ, 30, 600);
#if JC_BOARD == 2
  {   // vitesse de l'écran : mémorisée et appliquée au redémarrage
    int mhz = d["spimhz"] | 0;
    if (mhz >= 8 && mhz <= 40) {
      Preferences pr; pr.begin("hcd", false);
      uint8_t old = pr.getUChar("spimhz", 20);
      if (old != mhz) { pr.putUChar("spimhz", mhz); if (uiReady) restartAt = millis() + 700; }
      pr.end();
    }
  }
#endif
  lcd.touchDev().zMin = hw.touchZ;
  if ((bool)(d["flip"] | hw.flip) != hw.flip) {         // retournement de l'écran : appliqué tout de suite
    hw.flip = d["flip"] | hw.flip;
    lcd.setRotation(screenRotation());
    if (uiReady) drawAll();
  }
  {
    int sv = constrain(d["sound"] | hw.sound, 0, 100);
    bool changed = sv != hw.sound;
    hw.sound = sv;
#if JC_BOARD == 2
    if (changed && uiReady && sv > 0) sfx(SFX_COIN);   // bip d'essai quand on règle le volume dans le logiciel
#endif
  }
  hw.music = d["music"] | hw.music;
  {   // "touch" ou "mech" seulement ; "auto" (ou absent) = selon la carte : on garde la valeur par défaut
    const char* kt = d["keys"] | "";
    if (!strcmp(kt, "touch")) hw.keyTouch = true;
    else if (!strcmp(kt, "mech")) hw.keyTouch = false;
  }
  for (int k = 0; k < 3; k++) pinMode(PIN_KEY[k], hw.keyTouch ? INPUT_PULLDOWN : INPUT_PULLUP);
  { const char* wm = d["wifi"] | ""; if (*wm) hw.wifiMode = !strcmp(wm, "always") ? 2 : !strcmp(wm, "periodic") ? 1 : 0; }
  { const char* sv = d["saver"] | ""; if (*sv) hw.saverClock = !strcmp(sv, "clock"); }
  lcd.setBrightness(hw.screen);
  ledMaster = 255;
  ledForce = true;
  joyRelease();
  mouse.release(MOUSE_LEFT);
}

static int screenRotation() {
#if JC_BOARD == 2
  return hw.flip ? 1 : 3;
#else
  return hw.flip ? 3 : 1;
#endif
}

static bool loadHwFromFile() {
  File f = LittleFS.open(HW_FILE, "r");
  if (!f) return false;
  JsonDocument d;
  DeserializationError err = deserializeJson(d, f);
  f.close();
  if (err) return false;
  applyHw(d);
  return true;
}

// -------------------------------------------------------- Liaison série -----
static String rxLine;

static String nextToken(String& s) {
  s.trim();
  int sp = s.indexOf(' ');
  String t = (sp < 0) ? s : s.substring(0, sp);
  s = (sp < 0) ? "" : s.substring(sp + 1);
  return t;
}

static bool validName(const String& n) {
  if (n.length() == 0 || n.length() > 16) return false;
  for (size_t i = 0; i < n.length(); i++) {
    char c = n[i];
    if (!(isalnum(c) || c == '_' || c == '-')) return false;
  }
  return true;
}

static void clearIcons() {
  std::vector<String> names;
  File d = LittleFS.open("/ic");
  if (d && d.isDirectory()) {
    File e = d.openNextFile();
    while (e) { names.push_back(String("/ic/") + e.name()); e = d.openNextFile(); }
  }
  for (auto& n : names) LittleFS.remove(n);
}

static bool readBody(size_t n, String& body) {
  body.reserve(n);
  uint32_t t0 = millis();
  while (body.length() < n && millis() - t0 < 5000) {
    if (Serial.available()) { body += (char)Serial.read(); t0 = millis(); } else delay(1);
  }
  return body.length() == n;
}

static void usbDetachRestart();
static void handleLine(const String& line) {
  String rest = line;
  String cmd = nextToken(rest);

  if (cmd == "HCD_PING") {
    lastPing = millis();
    Out.printf("HCD_PONG %s %s\n", FW_NAME, FW_VERSION);

  } else if (cmd == "HCD_INFO") {
    Out.printf("HCD_INFO %s %s cols=%d\n", FW_NAME, FW_VERSION, COLS);

  } else if (cmd == "HCD_MENU_GET") {
    Out.printf("HCD_MENU_BEGIN %u\n", (unsigned)measureJson(menuDoc));
    serializeJson(menuDoc, Serial);
    Serial.println();
    Out.println("HCD_MENU_END");

  } else if (cmd == "HCD_MENU_PUT") {
    size_t n = rest.toInt();
    if (n == 0 || n > MENU_MAX) { Out.println("HCD_MENU_ERR size"); return; }
    String body;
    if (!readBody(n, body)) { Out.println("HCD_MENU_ERR timeout"); return; }
    JsonDocument test;
    if (deserializeJson(test, body) || !test["pages"].is<JsonArray>()) {
      Out.println("HCD_MENU_ERR json");
      return;
    }
    test.clear();
    writeFile(MENU_FILE, body);
    if (loadMenuFromFile()) { mode = M_MENU; drawAll(); Out.println("HCD_MENU_OK"); }
    else Out.println("HCD_MENU_ERR load");

  } else if (cmd == "HCD_HW_PUT") {
    size_t n = rest.toInt();
    if (n == 0 || n > HW_MAX) { Out.println("HCD_HW_ERR size"); return; }
    String body;
    if (!readBody(n, body)) { Out.println("HCD_HW_ERR timeout"); return; }
    JsonDocument d;
    if (deserializeJson(d, body)) { Out.println("HCD_HW_ERR json"); return; }
    writeFile(HW_FILE, body);
    applyHw(d);
    Out.println("HCD_HW_OK");

  } else if (cmd == "HCD_ICON_CLEAR") {
    clearIcons();
    Out.println("HCD_ICON_OK");

  } else if (cmd == "HCD_ICON_PUT") {
    String name = nextToken(rest);
    size_t n = rest.toInt();
#if JC_BOARD == 2
    bool sizeOk = n == ICON_BYTES || n == 48 * 48 * 2;      // 64 px (logiciel 0.16) ou 48 px (ancien logiciel)
#else
    bool sizeOk = n == ICON_BYTES;
#endif
    if (!validName(name) || !sizeOk) { Out.println("HCD_ICON_ERR args"); return; }
    LittleFS.mkdir("/ic");
    File f = LittleFS.open(String("/ic/") + name + ".raw", "w");
    if (!f) { Out.println("HCD_ICON_ERR open"); return; }
    uint8_t buf[256];
    size_t got = 0;
    uint32_t t0 = millis();
    while (got < n && millis() - t0 < 5000) {
      int a = Serial.available();
      if (a > 0) {
        size_t want = min((size_t)a, min(sizeof(buf), n - got));
        size_t r = Serial.readBytes(buf, want);
        f.write(buf, r);
        got += r;
        t0 = millis();
      } else delay(1);
    }
    f.close();
    if (got == n) Out.println("HCD_ICON_OK");
    else { LittleFS.remove(String("/ic/") + name + ".raw"); Out.println("HCD_ICON_ERR timeout"); }

#if JC_BOARD == 2
  } else if (cmd == "HCD_TIME") {                // heure locale du PC, en secondes depuis 1970
    struct timeval tv = {(time_t)strtoll(rest.c_str(), nullptr, 10), 0};
    settimeofday(&tv, nullptr);
    Out.println("HCD_TIME_OK");
    drawHeader();

  } else if (cmd == "HCD_WALL_CLEAR") {
    LittleFS.remove(WALL_FILE);
    wallOk = false;
    if (mode == M_MENU) drawAll();
    Out.println("HCD_WALL_OK");

  } else if (cmd == "HCD_WALL_PUT") {            // fond d'écran : 480x320 RGB565, écrit directement dans le fichier
    size_t n = rest.toInt();
    if (n != WALL_BYTES) { Out.println("HCD_WALL_ERR size"); return; }
    File f = LittleFS.open(WALL_FILE, "w");
    if (!f) { Out.println("HCD_WALL_ERR open"); return; }
    uint8_t buf[512];
    size_t got = 0;
    uint32_t t0 = millis();
    while (got < n && millis() - t0 < 5000) {
      int a = Serial.available();
      if (a > 0) {
        size_t r = Serial.readBytes(buf, min((size_t)a, min(sizeof(buf), n - got)));
        f.write(buf, r);
        got += r;
        t0 = millis();
      } else delay(1);
    }
    f.close();
    if (got != n) { LittleFS.remove(WALL_FILE); Out.println("HCD_WALL_ERR timeout"); return; }
    loadWall();
    if (mode == M_MENU) drawAll();
    Serial.println(wallOk ? "HCD_WALL_OK" : "HCD_WALL_ERR load");

  } else if (cmd == "HCD_WIFI") {               // réglages Wi-Fi (JSON) ; le mot de passe n'est jamais renvoyé
    wifiSet(rest);

  } else if (cmd == "HCD_WEATHER") {            // météo envoyée par le PC (JSON sur une ligne)
    weatherSet(rest);

  } else if (cmd == "HCD_LIVE") {               // « HCD_LIVE cpu 37 % » : valeur d'une tuile vivante ; pas de réponse
    String key = nextToken(rest);
    int li = liveIndex(key.c_str());
    rest.trim();
    if (li >= 0 && liveVal[li] != rest) {
      liveVal[li] = rest;
      if (mode == M_MENU && !saverOn && !T.down)
        for (int i = 0; i < slots(); i++) { Slot sl = getSlot(i); if (sl.used && key == (const char*)(sl.item["live"] | "")) drawCell(i, false); }
    }

  } else if (cmd == "HCD_GOTO") {                // page automatique : chemin « page.case/page.case », vide = accueil
    if (T.down) { Out.println("HCD_GOTO_BUSY"); return; }
    rest.trim();
    mode = M_MENU;
    goHome();
    while (rest.length()) {
      int sl = rest.indexOf('/');
      String seg = sl < 0 ? rest : rest.substring(0, sl);
      rest = sl < 0 ? "" : rest.substring(sl + 1);
      int dot = seg.indexOf('.');
      if (dot < 0) break;
      int pg = seg.substring(0, dot).toInt(), it = seg.substring(dot + 1).toInt();
      if (cur.pages.isNull() || pg < 0 || pg >= (int)cur.pages.size()) break;
      cur.page = pg;
      Slot sl2 = getSlot(it);
      if (!sl2.used || !sl2.folder) break;
      stack.push_back(cur);
      Level nl;
      nl.pages = sl2.item["pages"].as<JsonArrayConst>();
      nl.page = 0;
      nl.name = sl2.label;
      cur = nl;
    }
    navSel = 0;
    drawAll();
    Out.println("HCD_GOTO_OK");
#endif

  } else if (cmd == "HCD_VOL") {                 // vrai volume du PC : « HCD_VOL 62 0 » (niveau, muet) ; pas de réponse
    int sp = rest.indexOf(' ');
    int lvl = constrain((int)(sp < 0 ? rest : rest.substring(0, sp)).toInt(), 0, 100);
    bool mu = sp >= 0 && rest.substring(sp + 1).toInt() != 0;
    if ((lvl != volLevel || mu != volMuted) && !T.down) {
      volLevel = lvl;
      volMuted = mu;
      if (mode == M_VOL) drawVolBar();
#if JC_BOARD == 2
      drawSideVol();
#endif
    }

  } else if (cmd == "HCD_JOY_CAL") {
    joyRelease();
    joyCalibrate();
    toast("Joystick calibre !");
    Out.println("HCD_JOY_OK");

  } else if (cmd == "HCD_LINK") {
    rest.trim();
    if (rest == "usb" || rest == "ble" || rest == "auto") {
      int want = (rest == "ble") ? 1 : (rest == "auto") ? 2 : 0;
      if (want != linkPref) {
        Preferences pr; pr.begin("hcd", false); pr.putUChar("link", want); pr.end();
        Out.printf("HCD_LINK_OK %s\n", rest.c_str());
        restartAt = millis() + 700;       // redémarrage pour appliquer le nouveau mode
      } else {
        Out.printf("HCD_LINK_OK %s\n", rest.c_str());
      }
    } else {
      Out.printf("HCD_LINK_IS %s\n", linkPref == 2 ? "auto" : linkPref == 1 ? "ble" : "usb");
    }

  } else if (cmd == "HCD_JOY_DBG") {
    joyDebug = (rest.toInt() != 0);          // affiche les valeurs brutes du joystick (moniteur série)
    Out.println("HCD_JOY_OK");

  } else if (cmd == "HCD_BOOT") {
    enterDownloadMode();
  } else if (cmd == "HCD_BLE_DIAG") {
    bleDiag = rest.toInt() != 0;
    int hs[4]; for (int i = 0; i < 4; i++) hs[i] = bleConnH[i] == 0xFFFF ? -1 : bleConnH[i];
    Serial.printf("HCD_BLE_DIAG_OK actif=%d mode=%d pref=%d connexions=%d poignees=%d,%d,%d,%d lignes_recues=%d notif=%d code=%d\n",
                  (int)bleOn, linkMode, linkPref, (int)bleConnCount, hs[0], hs[1], hs[2], hs[3], bleRxLines, bleNotifyN, bleNotifyRc);
  } else if (cmd == "HCD_BLE_FORGET") {      // oublie les PC appairés en Bluetooth (clés gardées par NimBLE)
    nvs_handle_t h;
    if (nvs_open("nimble_bond", NVS_READWRITE, &h) == ESP_OK) { nvs_erase_all(h); nvs_commit(h); nvs_close(h); }
    Out.println("HCD_BLE_OK");
    toast("Appairages Bluetooth effacés");
    restartAt = millis() + 800;
  } else if (cmd == "HCD_CAL") {
    Preferences p; p.begin("hcd", false); p.remove("cal"); p.end();
    Out.println("HCD_CAL_OK");
    delay(100);
    usbDetachRestart();
  }
}

static void serialTask() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') { rxLine.trim(); if (rxLine.length()) handleLine(rxLine); rxLine = ""; }
    else if (c != '\r' && rxLine.length() < 400) rxLine += c;   // 400 : ligne météo (JSON)
  }
  if (bleOn) {                                  // mêmes commandes reçues par Bluetooth
    static String bleLine;
    int c;
    while ((c = bleRxGet()) >= 0) {
      if (c == '\n') {
        bleLine.trim();
        // les envois en blocs binaires (menu, icônes, réglages, fond d'écran) ne passent que par l'USB
        if (bleLine.length() && !bleLine.endsWith("_PUT") && bleLine.indexOf("_PUT ") < 0) {
          bleRxLines++;
          if (bleDiag) Serial.printf("HCD_LOG BLE recu : %s\n", bleLine.c_str());
          handleLine(bleLine);
          if (bleDiag) Serial.printf("HCD_LOG BLE envoi : notif=%d connexions=%d code=%d (poignee TX %u)\n",
                                     bleNotifyN, bleNotifyConns, bleNotifyRc, bleNusTx ? bleNusTx->getHandle() : 0);
        }
        bleLine = "";
      } else if (c != '\r' && bleLine.length() < 400) bleLine += (char)c;
    }
  }
}

// --------------------------------------------------------------- Setup ------
static void setupTouch() {
  Preferences p;
  p.begin("hcd", false);
  uint16_t cal[8];
  if (p.getBytes("cal", cal, sizeof(cal)) == sizeof(cal)) {
    lcd.setTouchCalibrate(cal);
  } else {
    lcd.fillScreen(TFT_BLACK);
    lcd.setFont(FONT_M);
    lcd.setTextColor(TFT_WHITE);
    lcd.setTextDatum(middle_center);
    lcd.drawString("Touchez les fleches aux coins", SCREEN_W / 2, SCREEN_H / 2);
    lcd.calibrateTouch(cal, TFT_WHITE, TFT_BLACK, 20);
    p.putBytes("cal", cal, sizeof(cal));
  }
  p.end();
}

static bool linkSwitchedAtBoot = false;

void setup() {
  // au réveil d'une mise en veille, les broches maintenues (écran, LED, son) doivent être relâchées
  gpio_deep_sleep_hold_dis();
  for (int g : {PIN_BL, PIN_LEDS, PIN_LED_KEY[0], PIN_LED_KEY[1], PIN_LED_KEY[2], PIN_LED_STATUS}) gpio_hold_dis((gpio_num_t)g);
#if JC_BOARD == 2
  for (int g : {PIN_I2S_BCLK, PIN_I2S_LRC, PIN_I2S_DIN}) gpio_hold_dis((gpio_num_t)g);
#endif
#if JC_BOARD == 2
  // fils de l'ampli au repos tout de suite : flottants pendant le démarrage, ils faisaient « bzzz » dans le haut-parleur
  for (int p : {PIN_I2S_BCLK, PIN_I2S_LRC, PIN_I2S_DIN}) { pinMode(p, OUTPUT); digitalWrite(p, LOW); }
#endif
  pinMode(PIN_LEDS, OUTPUT);               // éteint le ruban au plus tôt (évite l'allumage au démarrage)
  digitalWrite(PIN_LEDS, LOW);
  for (int k = 0; k < 3; k++) pinMode(PIN_KEY[k], hw.keyTouch ? INPUT_PULLDOWN : INPUT_PULLUP);
  pinMode(PIN_JOY_SW, INPUT_PULLUP);
  pinMode(PIN_NAV_BTN, INPUT_PULLUP);
  analogReadResolution(12);

  for (int k = 0; k < 3; k++) ledcAttach(PIN_LED_KEY[k], 5000, 8);
  ledcAttach(PIN_LED_STATUS, 5000, 8);
  pinMode(PIN_CHRG, INPUT_PULLUP);

  {   // mode de liaison mémorisé ; touches 1 + 2 maintenues au démarrage = changer de mode
    Preferences pr; pr.begin("hcd", false);
    linkPref = pr.getUChar("link", 2);       // par défaut : automatique (USB si un PC est relié, sinon Bluetooth)
    if (linkPref > 2) linkPref = 0;
    linkMode = (linkPref == 1) ? 1 : 0;
    delay(60);
    // touches TTP223 : elles se calibrent à la mise sous tension, un doigt posé n'est pas vu ici ;
    // la bascule se fait alors dans les 8 premières secondes (voir loop()).
    if (!hw.keyTouch && digitalRead(PIN_KEY[0]) == LOW && digitalRead(PIN_KEY[1]) == LOW) {
      linkMode = (linkPref == 1) ? 0 : 1;        // touches 1 + 2 : bascule USB / Bluetooth (quitte le mode automatique)
      linkPref = linkMode;
      pr.putUChar("link", linkPref);
      linkSwitchedAtBoot = true;
    }
    pr.end();
  }

  USB.manufacturerName("HackMan3D");
  USB.productName("JCharles desktop");     // nom vu par Windows (USB) ; FW_NAME reste l'identifiant du protocole
  keyboard.begin();
  mouse.begin();
  consumer.begin();
  Serial.setRxBufferSize(16384);     // gros envois du PC (menu, icônes) sans perte ; avant Serial.begin()
  Serial.begin(115200);
  USB.begin();
  if (linkPref == 2) {                       // automatique : un PC énumère la carte en USB, un simple chargeur non
    uint32_t t0 = millis();
    while (millis() - t0 < 2500 && !usbHostPresent()) delay(50);
    linkMode = usbHostPresent() ? 0 : 1;
  }
  if (linkMode == 1 || linkPref == 2) bleStart();    // automatique : Bluetooth toujours prêt

  LittleFS.begin(true);
  LittleFS.mkdir("/ic");
  if (!LittleFS.exists(MENU_FILE)) writeFile(MENU_FILE, String(DEFAULT_MENU));
  if (!loadMenuFromFile()) {
    writeFile(MENU_FILE, String(DEFAULT_MENU));
    loadMenuFromFile();
  }

#if JC_BOARD == 2
  {   // vitesse de la liaison avec l'écran (réglage du logiciel, appliqué au démarrage) : trop rapide = image abîmée
    Preferences pr; pr.begin("hcd", true);
    uint8_t mhz = pr.getUChar("spimhz", 20);
    pr.end();
    if (mhz < 8 || mhz > 40) mhz = 20;
    lcd.setWriteFreq(mhz * 1000000UL);
  }
#endif
  lcd.init();
  lcd.setRotation(screenRotation());
#if JC_BOARD == 2
  fontsBegin();
#endif
#if JC_BOARD == 2
  loadWall();
  soundBegin();
  wifiLoad();
#endif
  setupTouch();
  loadHwFromFile();
  stripSimpleInit = hw.stripSimple;
  if (stripSimpleInit) {
    ledcAttach(PIN_LEDS, 2000, 8);
    ledcWrite(PIN_LEDS, 0);
  } else {
    strip.begin();
    strip.setBrightness(255);
    strip.clear();
    strip.show();
  }
  stripReady = true;
  lcd.setBrightness(hw.screen);
  joyCalibrate();
  uiReady = true;
#if JC_BOARD == 2
  sfx(SFX_BOOT);                           // petit bip : le pad est prêt
#endif
  drawAll();
  lastActivity = millis();
  if (linkSwitchedAtBoot) toast(linkMode ? "Mode Bluetooth" : "Mode USB");
}

// ---------------------------------------------------------------- Boucle ----
static void onDown(int32_t x, int32_t y) {
  T.down = true; T.moved = false; T.longDone = false;
  T.sx = T.lx = x; T.sy = T.ly = y;
  T.t0 = millis(); T.slot = -1; T.region = 0; T.acc = 0;

#if JC_BOARD == 2
  if (y < HEADER_H || (y < HEADER_H + 10 && x < SX(70) && (mode != M_MENU || !stack.empty()))) {   // flèche retour : zone un peu plus haute
    T.slot = (x < SX(70)) ? -2 : -3; return;
  }
#else
  if (y < HEADER_H) { T.slot = (x < SX(70)) ? -2 : -3; return; }
#endif
#if JC_BOARD == 2
  if (mode == M_SHORT) { T.slot = -4; return; }
#endif
#if JC_BOARD == 2
  if (alarmUntil) alarmUntil = 1;                                // un toucher arrête le clignotement
  if (isGameMode()) { gameTouchDown(x, y); return; }
#endif

#if JC_BOARD == 2
  if (mode == M_MENU && hw.volBar && x >= SCREEN_W - VB_W) {    // curseur de volume
    if (y < HEADER_H + VB_MUTE_H) T.region = 6;
    else { T.region = 5; sideVolTo(vbLevelFromY(y)); }
    return;
  }
#endif
  if (mode == M_MENU) {
    int col = constrain(x / cellW(), 0, COLS - 1);
    int row = constrain((y - HEADER_H) / CELL_H, 0, ROWS - 1);
    int s = row * COLS + col;
#if JC_BOARD == 2
    touchX = x; touchY = y;
#endif
    if (getSlot(s).used) { T.slot = s; drawCell(s, true); }
  } else if (mode == M_PAD) {
    if (y >= PAD_BTN_Y) { T.region = 3; T.slot = constrain(x / (SCREEN_W / PAD_BTN_N), 0, PAD_BTN_N - 1); }
    else if (x >= PAD_ZOOM_X) T.region = 2;
    else { T.region = 1; orbitBegin(); }
  } else if (mode == M_VOL) {
    if (y >= VOL_MUTE_Y && x >= VOL_MUTE_X && x <= VOL_MUTE_X + VOL_MUTE_W) T.region = 3;
    else T.region = 1;
  }
}

static void onMove(int32_t x, int32_t y) {
  int dx = x - T.lx, dy = y - T.ly;
  T.lx = x; T.ly = y;
#if JC_BOARD == 2
  if (isGameMode()) return;
  if (!T.moved && millis() - T.t0 < TOUCH_SETTLE_MS) { T.sx = x; T.sy = y; return; }   // appui pas encore stable
#endif
  if (abs(x - T.sx) > MOVE_THRESHOLD_PX || abs(y - T.sy) > MOVE_THRESHOLD_PX) {
    if (!T.moved && mode == M_MENU && T.slot >= 0) drawCell(T.slot, false);
    T.moved = true;
  }

#if JC_BOARD == 2
  if (mode == M_MENU && T.region == 5) { sideVolTo(vbLevelFromY(y)); return; }
#endif
  if (mode == M_MENU) {
    if (!T.moved && !T.longDone && T.slot >= 0 && millis() - T.t0 >= LONG_PRESS_MS) {
      T.longDone = true;
      activateLong(T.slot);
    }
  } else if (mode == M_PAD) {
    if (T.region == 1) {
      mouse.move(clamp8(dx), clamp8(dy));
    } else if (T.region == 2) {
      T.acc += -dy;
      while (abs(T.acc) >= 8) {
        mouse.move(0, 0, T.acc > 0 ? 1 : -1);
        T.acc += (T.acc > 0) ? -8 : 8;
      }
    }
  } else if (mode == M_VOL && T.region == 1) {
    T.acc += -dy;
    while (abs(T.acc) >= 12) {
      bool up = T.acc > 0;
      sendConsumer(up ? "vol_up" : "vol_down");
      volLevel = constrain(volLevel + (up ? 2 : -2), 0, 100);
      T.acc += up ? -12 : 12;
      drawVolBar();
    }
  }
}

static void onUp() {
  T.down = false;

  if (mode == M_PAD && T.region == 1) orbitEnd();

#if JC_BOARD == 2
  // en-tête du menu principal (hors flèche retour) : écran des raccourcis
  if (mode == M_MENU && !T.moved && (T.slot == -3 || (T.slot == -2 && stack.empty()))) { enterMode(M_SHORT); return; }
  if (mode == M_SHORT && T.slot == -4 && !T.moved) { shortcutTap(T.sx, T.sy); return; }
#endif
#if JC_BOARD == 2
  if (isGameMode() && T.slot == -3 && !T.moved && hdrSndX >= 0 && T.sx >= hdrSndX) { padSoundStep(); return; }
#endif
  if (T.slot == -2 && !T.moved) { goBack(); return; }
#if JC_BOARD == 2
  if (isGameMode()) { gameTouchUp(); return; }
#endif

#if JC_BOARD == 2
  if (mode == M_MENU && T.region == 6) {
    if (!T.moved) { sendConsumer("mute"); volMuted = !volMuted; drawSideVol(); }
    return;
  }
  if (mode == M_MENU && T.region == 5) return;
#endif
  if (mode == M_MENU) {
    int dx = T.lx - T.sx, dy = T.ly - T.sy;
    if (T.sy >= HEADER_H && abs(dx) >= SWIPE_MIN_PX && abs(dx) > 2 * abs(dy)) {
      changePage(dx < 0 ? +1 : -1);
      return;
    }
    if (T.slot >= 0) {
      int s = T.slot;
      drawCell(s, false);
      if (!T.longDone && !T.moved) activate(s);
    }
  } else if (mode == M_PAD) {
    if (T.region == 3 && !T.moved) padButton(T.slot);
  } else if (mode == M_VOL) {
    if (T.region == 3 && !T.moved) { sendConsumer("mute"); volMuted = !volMuted; }
  }
}

// ------------------------------------------------ Économie d'énergie -
static void setScreenLevel(int st) {
#if JC_BOARD == 2
  bool wasSaver = saverOn;
  saverOn = (st == 2 && hw.saverClock);
  screenState = st;
  if (saverOn) {
    if (!wasSaver) drawSaver();
    lcd.setBrightness(max(6, hw.screen / 10));
    return;
  }
  if (wasSaver) drawAll();                                       // sortie de l'horloge : on redessine le menu
#endif
  screenState = st;
  lcd.setBrightness(st == 0 ? hw.screen : st == 1 ? max(4, hw.screen / 6) : 0);
}

static void markActivity() {
  lastActivity = millis();
  if (screenState) setScreenLevel(0);
}

static void sleepNow() {
  lcd.setBrightness(0);
  for (int k = 0; k < 3; k++) ledcWrite(PIN_LED_KEY[k], 0);
  ledcWrite(PIN_LED_STATUS, 0);
  if (stripSimpleInit) ledcWrite(PIN_LEDS, 0);
  const int hold[] = {PIN_BL, PIN_LEDS, PIN_LED_KEY[0], PIN_LED_KEY[1], PIN_LED_KEY[2], PIN_LED_STATUS};
  for (int g : hold) { pinMode(g, OUTPUT); digitalWrite(g, LOW); gpio_hold_en((gpio_num_t)g); }
  gpio_deep_sleep_hold_en();
  uint64_t mask = (1ULL << PIN_KEY[0]) | (1ULL << PIN_KEY[1]);      // réveil : touche 1 ou 2
  for (int i = 0; i < 2; i++) {
    gpio_num_t g = (gpio_num_t)PIN_KEY[i];
    if (hw.keyTouch) { rtc_gpio_pulldown_en(g); rtc_gpio_pullup_dis(g); }      // TTP223 (reste alimenté en veille)
    else { rtc_gpio_pullup_en(g); rtc_gpio_pulldown_dis(g); }
  }
  esp_sleep_enable_ext1_wakeup(mask, hw.keyTouch ? ESP_EXT1_WAKEUP_ANY_HIGH : ESP_EXT1_WAKEUP_ANY_LOW);
#if JC_BOARD == 2
  if (hw.joySw) {                                   // clic du joystick (vers GND) : réveil aussi
    rtc_gpio_pullup_en((gpio_num_t)PIN_JOY_SW); rtc_gpio_pulldown_dis((gpio_num_t)PIN_JOY_SW);
    esp_sleep_enable_ext0_wakeup((gpio_num_t)PIN_JOY_SW, 0);
  }
#endif
  esp_deep_sleep_start();
}
// Extinction demandée sur le pad (V2) : écran, LED et son coupés, la carte s'endort.
// Rallumage : toucher la touche 1 ou 2. Sur batterie, l'interrupteur coupe tout, comme avant.
static void padPowerOff(const char* title) {
#if JC_BOARD == 2
  lcd.fillScreen(TFT_BLACK);
  lcd.setFont(FONT_L);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(TFT_WHITE);
  lcd.drawString(title, SCREEN_W / 2, SCREEN_H / 2 - 16);
  lcd.setFont(FONT_S);
  lcd.setTextColor(0xBDF7);
  lcd.drawString("Touche 1 ou 2, ou clic du joystick, pour rallumer", SCREEN_W / 2, SCREEN_H / 2 + 20);
  musicPlay(false);
  delay(1500);
  for (int p : {PIN_I2S_BCLK, PIN_I2S_LRC, PIN_I2S_DIN}) { pinMode(p, OUTPUT); digitalWrite(p, LOW); gpio_hold_en((gpio_num_t)p); }
  if (!stripSimpleInit) { for (int i = 0; i < LED_COUNT; i++) strip.setPixelColor(i, 0); strip.show(); }
  Serial.flush();
#endif
  sleepNow();
}

// Mode automatique : bascule USB <-> Bluetooth quand on branche / débranche la carte d'un PC (la carte redémarre).
// Redémarrage propre : on se déconnecte d'abord de l'USB, sinon Windows peut ne plus reconnaître la carte
// (« périphérique mal installé ») et oblige à changer de port.
static void usbDetachRestart() {
  tud_disconnect();
  delay(500);
  ESP.restart();
}

static void autoLinkTask() {
  static uint32_t last = 0, since = 0;
  static bool lastState = false, init = false;
  uint32_t now = millis();
  if (linkPref != 2 || restartAt || now - last < 250) return;
  last = now;
  bool host = usbHostPresent();
  if (!init) { init = true; lastState = host; since = now; return; }
  if (host != lastState) { lastState = host; since = now; return; }
  bool wantUsb = host;
  if (wantUsb == (linkMode == 0)) return;
  uint32_t need = host ? 1500 : 8000;        // débrancher : on attend plus (veille/redémarrage du PC)
  if (now - since > need) {
    // USB et Bluetooth tournent tous les deux en mode automatique : on change de liaison sans redémarrer
    // (un redémarrage pendant que le câble est branché faisait perdre la carte à Windows).
    keyboard.releaseAll();
    linkMode = wantUsb ? 0 : 1;
    keyboard.releaseAll();
    Out.printf("HCD_LINK_AUTO %s\n", wantUsb ? "usb" : "ble");
    toast(wantUsb ? "Liaison : USB" : "Liaison : Bluetooth");
    drawHeader();
  }
}

static void powerTask() {
  uint32_t now = millis(), idle = now - lastActivity;
  if (hw.offS > 0 && idle > (uint32_t)hw.offS * 1000UL) { if (screenState != 2) setScreenLevel(2); }
  else if (hw.dimS > 0 && idle > (uint32_t)hw.dimS * 1000UL) { if (screenState == 0) setScreenLevel(1); }
#if JC_BOARD == 2
  // veille sur batterie (pas de PC relié par USB) ou en Bluetooth, après hw.sleepMin minutes sans toucher
  if (hw.sleepMin > 0 && (linkMode == 1 || !usbHostPresent()) && idle > (uint32_t)hw.sleepMin * 60000UL && !T.down)
    padPowerOff("Mise en veille");
#else
  if (hw.sleepMin > 0 && linkMode == 1 && idle > (uint32_t)hw.sleepMin * 60000UL && !T.down) sleepNow();
#endif
}

void loop() {
  static uint32_t lastHeader = 0;
  static bool lastConn = false;

  if (restartAt && millis() > restartAt) { Serial.flush(); usbDetachRestart(); }
  {   // bouton dédié (GPIO3 vers GND) : bascule la navigation au joystick
    static bool nbPrev = false;
    static uint32_t nbT = 0;
    bool nb = digitalRead(PIN_NAV_BTN) == LOW;
#if JC_BOARD == 2
    static bool nbLong = false;
    if (nb && nbPrev && !nbLong && millis() - nbT > 3000) { nbLong = true; padPowerOff(); }
    if (!nb) nbLong = false;
#endif
    if (nb != nbPrev && millis() - nbT > 40) {
      nbPrev = nb; nbT = millis();
      if (nb && mode == M_MENU) toggleJoyNav();
#if JC_BOARD == 2
      else if (nb && isGameMode()) goBack();
#endif
    }
  }
  if (hw.keyTouch && millis() < 8000) {   // touches TTP223 : 1 + 2 maintenues 2 s juste après le démarrage = USB <-> Bluetooth
    static uint32_t t12 = 0;
    if (keyDown[0] && keyDown[1] && !keyDown[2]) {
      if (!t12) t12 = millis();
      else if (millis() - t12 > 2000) {
        Preferences pr; pr.begin("hcd", false);
        pr.putUChar("link", linkMode ? 0 : 1);
        pr.end();
        toast(linkMode ? "Passage en USB..." : "Passage en Bluetooth...");
        restartAt = millis() + 800;
        t12 = 0xFFFFFFFF;
      }
    } else if (t12 != 0xFFFFFFFF) t12 = 0;
  }
  {   // mode programmation : touches 1 + 3 maintenues + manche à gauche 1,5 s (ou touches 1 + 3 seules 5 s)
    static uint32_t tCombo = 0;
    static bool warned = false;
    if (keyDown[0] && keyDown[2]) {
      uint32_t now2 = millis();
      if (!tCombo) { tCombo = now2; warned = false; }
      uint32_t held = now2 - tCombo;
      if ((joyLeftHeld && held > 1500) || held > 5000) enterDownloadMode();
      else if (!warned && held > 900 && mode == M_MENU) { warned = true; toast("Mode programmation : maintenez..."); }
    } else {
      tCombo = 0;
    }
  }
  serialTask();
  keyTask();
  potTask();
  joyTask();
  ledTask();
  powerTask();
  autoLinkTask();
  if (bleOn) {                                   // message à l'écran quand le Bluetooth se connecte / se déconnecte
    static bool was = false;
    bool now = bleLinked();
    if (now != was) { was = now; if (linkMode == 1) toast(now ? "Bluetooth connecté" : "Bluetooth déconnecté"); drawHeader(); }
    bleScanConns();
    if (bleNeedAdv) { bleNeedAdv = false; BLEDevice::startAdvertising(); }   // reste visible pour le logiciel du PC
    uint8_t e = bleEvt;
    if (e) {
      bleEvt = 0;
      int n = bleConnCount;
      const char* t = e == 1 ? "connexion" : e == 2 ? "deconnexion" : e == 3 ? "appairage reussi" : "appairage refuse";
      Out.printf("HCD_LOG Bluetooth : %s (connexions=%d, etat=%d, code=0x%X)\n", t, n, (int)bleConnected, bleEvtArg);
      toast(String("BT : ") + t);
    }
  }
#if JC_BOARD == 2
  battTask();
  if (isGameMode()) gamesTask(); else musicPlay(false);
  if (mode == M_WEATHER) weatherTask();
  wifiTask();
  if (timerMode.length() || alarmUntil) {         // minuteur : mise à jour de la tuile chaque seconde, puis alarme
    static uint32_t lastSec = 0;
    if (timerMode.length() && (long)(millis() - tmrEnd) >= 0) {
      if (timerPhase == 1) {                        // fin du travail : 5 min de pause
        alarmColor = 0xFF2010; timerPhase = 2; tmrEnd = millis() + 5 * 60000UL;
        sfx(SFX_ALARM);
        toast("Pause : 5 minutes");
      } else {
        alarmColor = timerPhase == 2 ? 0x20FF40 : 0xFF9000;
        toast(timerPhase == 2 ? "Pause finie, au travail !" : "Minuteur termine");
        timerMode = "";
        sfx(SFX_ALARM);
      }
      alarmUntil = millis() + 15000;
      markActivity();
      if (mode == M_MENU) drawAll();
    }
    if (alarmUntil && millis() > alarmUntil) { alarmUntil = 0; ledForce = true; }
    if (millis() - lastSec >= 1000 && mode == M_MENU && !saverOn && !T.down && timerMode.length()) {
      lastSec = millis();
      for (int i = 0; i < slots(); i++) { Slot sl = getSlot(i); if (sl.isMode && timerMode == (const char*)(sl.item["mode"] | "")) drawCell(i, false); }
    }
  }
  {   // tuiles « heure » : une mise à jour par minute
    static int lastMinT = -1;
    struct tm tm;
    if (mode == M_MENU && !saverOn && !T.down && localTm(tm) && tm.tm_min != lastMinT) {
      lastMinT = tm.tm_min;
      for (int i = 0; i < slots(); i++) { Slot sl = getSlot(i); if (sl.used && !strcmp(sl.item["live"] | "", "clock")) drawCell(i, false); }
    }
  }
  if (flashSlot >= 0 && millis() > flashUntil) {               // fin de la coche de confirmation
    int fs = flashSlot; flashSlot = -1;
    if (mode == M_MENU && !saverOn && !T.down) drawCell(fs, false);
  }
  {   // horloge de veille : une mise à jour par minute
    static int lastMin = -1;
    struct tm tm;
    if (saverOn && localTm(tm) && tm.tm_min != lastMin) { lastMin = tm.tm_min; drawSaver(); }
  }
#endif

  uint32_t now = millis();
  bool conn = pcConnected();
  if (toastUntil && now > toastUntil) { toastUntil = 0; if (!T.down) drawHeader(); }
  if (conn != lastConn || now - lastHeader > 1000) {
    lastConn = conn; lastHeader = now;
    if (!T.down) drawHeader();
  }

  int32_t x, y;
  if (lcd.getTouch(&x, &y)) {
    T.tlast = now;
    if (!T.down) {
      if (screenState) {            // écran atténué/éteint : le premier toucher ne fait que le réveiller
        markActivity();
        T.down = true; T.moved = true; T.longDone = true; T.slot = -1; T.region = 0;
        T.sx = T.lx = x; T.sy = T.ly = y; T.t0 = now; T.acc = 0;
      } else {
        markActivity();
        onDown(x, y);
      }
    } else { markActivity(); onMove(x, y); }
  } else if (T.down && now - T.tlast > 70) {      // 70 ms : un appui léger qui « clignote » reste un seul appui
    onUp();
  }
}