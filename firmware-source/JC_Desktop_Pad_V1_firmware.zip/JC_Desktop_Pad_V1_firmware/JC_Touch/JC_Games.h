// =====================================================================================================
// JC_Games.h — menu « Jeux » du pad V2 : un jeu de plateformes (« Bip ») et un serpent.
// Inclus par JC_Touch.ino (V2 seulement). Commandes : joystick gauche/droite (et haut/bas pour le serpent),
// une des 3 touches ou le clic du joystick pour sauter / valider, bouton de navigation pour quitter.
// À l'écran : flèche « retour » en haut à gauche ; pendant le jeu de plateformes, toucher le tiers gauche /
// droit fait avancer, le milieu fait sauter.
// L'écran est redessiné par petites zones (fenêtre de 64 x 64 en mémoire) : pas de scintillement.
// =====================================================================================================

static const int GY = HEADER_H;              // haut de la zone de jeu
static const int TILE = 16, JUMP_COLS = 30, JUMP_ROWS = 17, JUMP_NROOMS = 4;
static const int PLAY_H = JUMP_ROWS * TILE;  // 272 px
static const char* const JUMP_ROOMS[JUMP_NROOMS][JUMP_ROWS] = {
  {
    "                              ",
    "                              ",
    "                              ",
    "                              ",
    "                              ",
    "                  o o o       ",
    "                 =======      ",
    "                              ",
    "         o  o                 ",
    "        ======                ",
    "                         o    ",
    "                       ====   ",
    "                              ",
    "   P             E            ",
    "##########    ################",
    "##########    ################",
    "##########    ################"
  },
  {
    "                              ",
    "                              ",
    "                              ",
    "            o o o             ",
    "           =======            ",
    "                              ",
    "     o                   o    ",
    "    ====              ======  ",
    "                              ",
    "           E                  ",
    "         =======              ",
    "                       o      ",
    "  o                  ====     ",
    "                 E            ",
    "######^^^#####################",
    "##############################",
    "##############################"
  },
  {
    "                              ",
    "                              ",
    "                     o        ",
    "                    ===       ",
    "              o               ",
    "             ===              ",
    "       o                      ",
    "      ===           E         ",
    "                 =======      ",
    "  o                           ",
    " ===                      o   ",
    "                         ===  ",
    "            ^^                ",
    "     E     ####       E       ",
    "#########  ####  #############",
    "#########  ####  #############",
    "#########  ####  #############"
  },
  {
    "                              ",
    "                              ",
    "                              ",
    "                              ",
    "          o o o               ",
    "         =======              ",
    "                          F   ",
    "   o                      F   ",
    "  ===          E          F   ",
    "            =======       F   ",
    "                     ##   F   ",
    "                   ####   F   ",
    "        E        ######   F   ",
    "               ########   F   ",
    "##############################",
    "##############################",
    "##############################"
  }
};

static uint16_t C_SKY, C_DIRT, C_DIRT2, C_GRASS, C_GRASS2, C_PLANK, C_PLANK2, C_COIN, C_COIN2, C_SPIKE,
                C_BIP, C_BIP2, C_FOE, C_FOE2, C_SNAKE_BG, C_SNAKE, C_SNAKE2, C_APPLE;
static bool gColorsOk = false;
static void gameColors() {
  if (gColorsOk) return;
  gColorsOk = true;
  C_SKY = lcd.color565(92, 168, 230);   C_DIRT = lcd.color565(178, 110, 56); C_DIRT2 = lcd.color565(128, 76, 36);
  C_GRASS = lcd.color565(64, 176, 72);  C_GRASS2 = lcd.color565(120, 220, 110);
  C_PLANK = lcd.color565(206, 132, 52); C_PLANK2 = lcd.color565(130, 76, 26);
  C_COIN = lcd.color565(255, 204, 40);  C_COIN2 = lcd.color565(196, 140, 0);  C_SPIKE = lcd.color565(200, 205, 215);
  C_BIP = lcd.color565(40, 190, 200);   C_BIP2 = lcd.color565(18, 110, 120);
  C_FOE = lcd.color565(214, 64, 52);    C_FOE2 = lcd.color565(120, 24, 20);
  C_SNAKE_BG = lcd.color565(16, 24, 36); C_SNAKE = lcd.color565(60, 190, 90); C_SNAKE2 = lcd.color565(30, 120, 50);
  C_APPLE = lcd.color565(230, 50, 50);
}

static int gamesSel = 0;                       // jeu sélectionné dans la liste
static int bestJump = 0, bestSnake = 0;
static bool gScoresLoaded = false;
static void loadBest() {
  if (gScoresLoaded) return;
  gScoresLoaded = true;
  Preferences p; p.begin("hcdgame", true);
  bestJump = p.getInt("jump", 0); bestSnake = p.getInt("snake", 0);
  p.end();
}
static void saveBest() {
  Preferences p; p.begin("hcdgame", false);
  p.putInt("jump", bestJump); p.putInt("snake", bestSnake);
  p.end();
}

// ------------------------------------------------------------------ entrées communes -----------------
static int8_t gTouchDir = 0;                   // -1 / +1 : tiers gauche / droit de l'écran touché
static bool gTouchJump = false, gTouchTap = false;
static void gameJoy(float& nx, float& ny) {
  nx = ny = 0;
  if (hw.joy == J_OFF) return;
  nx = joyNorm(readADC(PIN_JOY_X) - joyCx, joyDeadCounts(joyNoiseX));
  ny = joyNorm(readADC(PIN_JOY_Y) - joyCy, joyDeadCounts(joyNoiseY));
  if (hw.joySwap) { float t = nx; nx = ny; ny = t; }
  if (hw.joyInvX) nx = -nx;
  if (hw.joyInvY) ny = -ny;
}
static bool gameButton() {                     // une touche, le clic du joystick ou le milieu de l'écran
  return keyDown[0] || keyDown[1] || keyDown[2] || (hw.joySw && digitalRead(PIN_JOY_SW) == LOW) || gTouchJump;
}

static void gameOverlay(const char* l1, const String& l2, const String& l3) {
  const int w = 300, h = 130, x = (SCREEN_W - w) / 2, y = GY + (PLAY_H - h) / 2;
  lcd.fillRoundRect(x, y, w, h, 14, 0x18E3);
  lcd.drawRoundRect(x, y, w, h, 14, TFT_WHITE);
  lcd.setTextDatum(middle_center);
  lcd.setTextColor(TFT_WHITE);
  lcd.setFont(FONT_L);
  lcd.drawString(l1, SCREEN_W / 2, y + 30);
  lcd.setFont(FONT_M);
  lcd.setTextColor(TFT_YELLOW);
  lcd.drawString(l2, SCREEN_W / 2, y + 68);
  lcd.setFont(FONT_S);
  lcd.setTextColor(0xBDF7);
  lcd.drawString(l3, SCREEN_W / 2, y + 102);
}

// =============================================================== Jeu de plateformes « Bip » ========
struct GEnt { float x, y, vx, vy; int w, h; bool alive, ground; int dx, dy; };   // dx,dy : dernière position dessinée
static GEnt bip;
static GEnt foes[6];
static int nFoes = 0;
static int jRoom = 0, jLives = 3, jScore = 0, jState = 0;   // jState : 0 en jeu, 1 perdu, 2 gagné
static float jSpawnX = 0, jSpawnY = 0;
static uint32_t jCoins[JUMP_NROOMS];                         // pièces ramassées (un bit par pièce)
static bool bipRight = true, jJumpPrev = true;
static uint32_t jLast = 0, jHurtUntil = 0;
static LGFX_Sprite gWin(&lcd);
static bool gWinOk = false;
// décor de la salle dessiné une fois en mémoire (PSRAM) puis envoyé d'un bloc : bien moins de commandes
// vers l'écran qu'en dessinant chaque brique directement (une commande abîmée décalait des blocs entiers)
static LGFX_Sprite gBg(&lcd);
static bool gBgOk = false;

static char jTile(int tx, int ty) {
  if (tx < 0 || tx >= JUMP_COLS || ty < 0 || ty >= JUMP_ROWS) return ' ';
  return JUMP_ROOMS[jRoom][ty][tx];
}
static bool jSolid(int tx, int ty) {
  if (tx < 0 && jRoom == 0) return true;                                   // mur à gauche du début
  if (tx >= JUMP_COLS && jRoom == JUMP_NROOMS - 1) return true;            // mur à droite de la fin
  char c = jTile(tx, ty);
  return c == '#' || c == '=';
}
static int jCoinIndex(int tx, int ty) {
  int n = 0;
  for (int y = 0; y < JUMP_ROWS; y++)
    for (int x = 0; x < JUMP_COLS; x++) {
      if (y == ty && x == tx) return n;
      if (JUMP_ROOMS[jRoom][y][x] == 'o') n++;
    }
  return n;
}
static bool jCoinTaken(int tx, int ty) { return jCoins[jRoom] & (1u << (jCoinIndex(tx, ty) & 31)); }

static void jDrawTile(LovyanGFX& g, int tx, int ty, int sx, int sy) {
  char c = jTile(tx, ty);
  switch (c) {
    case '#': {
      g.fillRect(sx, sy, TILE, TILE, C_DIRT);
      g.drawPixel(sx + 4, sy + 9, C_DIRT2); g.drawPixel(sx + 11, sy + 6, C_DIRT2); g.drawPixel(sx + 9, sy + 13, C_DIRT2);
      g.drawPixel(sx + 2, sy + 14, C_DIRT2); g.drawPixel(sx + 13, sy + 11, C_DIRT2);
      if (jTile(tx, ty - 1) != '#') {
        g.fillRect(sx, sy, TILE, 5, C_GRASS);
        g.drawFastHLine(sx, sy, TILE, C_GRASS2);
        g.drawPixel(sx + 3, sy + 5, C_GRASS); g.drawPixel(sx + 10, sy + 5, C_GRASS);
      }
      break;
    }
    case '=':
      g.fillRoundRect(sx, sy, TILE, 9, 2, C_PLANK);
      g.drawFastHLine(sx + 1, sy + 1, TILE - 2, C_COIN);
      g.drawFastHLine(sx, sy + 8, TILE, C_PLANK2);
      g.drawFastVLine(sx + 8, sy + 2, 6, C_PLANK2);
      break;
    case 'o':
      if (!jCoinTaken(tx, ty)) {
        g.fillCircle(sx + 8, sy + 8, 5, C_COIN);
        g.drawCircle(sx + 8, sy + 8, 5, C_COIN2);
        g.drawFastVLine(sx + 8, sy + 5, 6, C_COIN2);
      }
      break;
    case '^':
      for (int i = 0; i < 3; i++) {
        int bx = sx + 1 + i * 5;
        g.fillTriangle(bx, sy + 15, bx + 4, sy + 15, bx + 2, sy + 5, C_SPIKE);
        g.drawLine(bx + 2, sy + 5, bx + 4, sy + 15, 0x7BCF);
      }
      break;
    case 'F':
      g.fillRect(sx + 7, sy, 2, TILE, 0xDEFB);
      if (jTile(tx, ty - 1) != 'F') {
        g.fillCircle(sx + 8, sy + 2, 2, C_COIN);
        g.fillTriangle(sx + 9, sy + 4, sx + 9, sy + 13, sx + 16, sy + 8, C_FOE);
      }
      break;
  }
}

static void jDrawBip(LovyanGFX& g, int x, int y) {        // x,y : coin haut-gauche de la boîte 14 x 16
  bool blink = millis() < jHurtUntil && (millis() / 80) % 2;
  if (blink) return;
  g.drawFastVLine(x + 7, y - 4, 4, C_BIP2);                 // antenne
  g.fillCircle(x + 7, y - 5, 2, C_FOE);
  g.fillRoundRect(x, y, 14, 13, 4, C_BIP);
  g.drawRoundRect(x, y, 14, 13, 4, C_BIP2);
  int ex = bipRight ? x + 8 : x + 5;
  g.fillCircle(ex, y + 5, 3, TFT_WHITE);
  g.fillCircle(ex + (bipRight ? 1 : -1), y + 5, 1, TFT_BLACK);
  int step = bip.ground && fabsf(bip.vx) > 0.5f ? ((millis() / 120) % 2) * 2 : 0;
  g.fillRect(x + 1 + step, y + 13, 4, 3, C_BIP2);
  g.fillRect(x + 9 - step, y + 13, 4, 3, C_BIP2);
}
static void jDrawFoe(LovyanGFX& g, int x, int y) {        // boîte 16 x 14
  g.fillCircle(x + 8, y + 8, 8, C_FOE);
  g.fillRect(x, y + 8, 16, 4, C_FOE);
  g.fillCircle(x + 5, y + 7, 2, TFT_WHITE);
  g.fillCircle(x + 11, y + 7, 2, TFT_WHITE);
  g.drawPixel(x + 5, y + 7, TFT_BLACK); g.drawPixel(x + 11, y + 7, TFT_BLACK);
  g.drawLine(x + 3, y + 3, x + 7, y + 5, C_FOE2);
  g.drawLine(x + 13, y + 3, x + 9, y + 5, C_FOE2);
  int step = (millis() / 150) % 2;
  g.fillRect(x + 1 + step, y + 12, 5, 2, C_FOE2);
  g.fillRect(x + 10 - step, y + 12, 5, 2, C_FOE2);
}

// redessine une fenêtre de 64 x 64 (coordonnées de la zone de jeu) : décor + personnages
static void jRegion(int x, int y) {
  x = constrain(x, 0, SCREEN_W - 64);
  y = constrain(y, 0, PLAY_H - 64);
  LovyanGFX& g = gWinOk ? (LovyanGFX&)gWin : (LovyanGFX&)lcd;
  int ox = gWinOk ? -x : 0, oy = gWinOk ? -y : GY;          // décalage entre zone de jeu et cible du dessin
  if (gWinOk && gBgOk) gBg.pushSprite(&gWin, -x, -y);   // copie du décor déjà dessiné
  else {
    if (gWinOk) gWin.fillScreen(C_SKY); else lcd.fillRect(x, GY + y, 64, 64, C_SKY);
    for (int ty = y / TILE; ty <= (y + 63) / TILE; ty++)
      for (int tx = x / TILE; tx <= (x + 63) / TILE; tx++)
        jDrawTile(g, tx, ty, tx * TILE + ox, ty * TILE + oy);
  }
  for (int i = 0; i < nFoes; i++) if (foes[i].alive) {
    int fx = (int)foes[i].x, fy = (int)foes[i].y;
    if (fx + 16 > x && fx < x + 64 && fy + 14 > y && fy < y + 64) jDrawFoe(g, fx + ox, fy + oy);
    foes[i].dx = fx; foes[i].dy = fy;
  }
  int bx = (int)bip.x, by = (int)bip.y;
  if (bx + 14 > x && bx < x + 64 && by + 16 > y - 6 && by < y + 64) { jDrawBip(g, bx + ox, by + oy); bip.dx = bx; bip.dy = by; }
  if (gWinOk) gWin.pushSprite(x, GY + y);
}
static void jBgTile(int tx, int ty) {             // redessine une case du décor en mémoire (pièce ramassée)
  if (!gBgOk) return;
  gBg.fillRect(tx * TILE, ty * TILE, TILE, TILE, C_SKY);
  jDrawTile(gBg, tx, ty, tx * TILE, ty * TILE);
}
static void jDrawRoom() {
  if (gBgOk && gWinOk) {
    gBg.fillScreen(C_SKY);
    for (int ty = 0; ty < JUMP_ROWS; ty++)
      for (int tx = 0; tx < JUMP_COLS; tx++)
        if (jTile(tx, ty) != ' ') jDrawTile(gBg, tx, ty, tx * TILE, ty * TILE);
    gBg.pushSprite(0, GY);
    lcd.fillRect(0, GY + PLAY_H, SCREEN_W, SCREEN_H - GY - PLAY_H, TFT_BLACK);
    for (int i = 0; i < nFoes; i++) if (foes[i].alive) jRegion((int)foes[i].x - 24, (int)foes[i].y - 25);
    jRegion((int)bip.x - 25, (int)bip.y - 26);
    return;
  }
  lcd.fillRect(0, GY, SCREEN_W, PLAY_H, C_SKY);
  lcd.fillRect(0, GY + PLAY_H, SCREEN_W, SCREEN_H - GY - PLAY_H, TFT_BLACK);
  for (int ty = 0; ty < JUMP_ROWS; ty++)
    for (int tx = 0; tx < JUMP_COLS; tx++)
      if (jTile(tx, ty) != ' ') jDrawTile(lcd, tx, ty, tx * TILE, GY + ty * TILE);
  for (int i = 0; i < nFoes; i++) if (foes[i].alive) { jDrawFoe(lcd, (int)foes[i].x, GY + (int)foes[i].y); foes[i].dx = (int)foes[i].x; foes[i].dy = (int)foes[i].y; }
  jDrawBip(lcd, (int)bip.x, GY + (int)bip.y);
  bip.dx = (int)bip.x; bip.dy = (int)bip.y;
}
static void jHud() {
  gameHud = String("Bip  ") + jScore + " pts   Vies " + jLives + "   " + (jRoom + 1) + "/" + JUMP_NROOMS;
  drawHeader();
}

static void jEnterRoom(int room, bool fromRight) {
  jRoom = room;
  nFoes = 0;
  for (int ty = 0; ty < JUMP_ROWS; ty++)
    for (int tx = 0; tx < JUMP_COLS; tx++) {
      char c = JUMP_ROOMS[room][ty][tx];
      if (c == 'E' && nFoes < 6) foes[nFoes++] = {(float)tx * TILE, (float)ty * TILE + 2, -0.9f, 0, 16, 14, true, false, 0, 0};
      if (c == 'P') { jSpawnX = tx * TILE; jSpawnY = ty * TILE; }
    }
  if (room > 0 || fromRight) {                     // arrivée par un bord : on garde la hauteur
    jSpawnX = fromRight ? SCREEN_W - 18 : 2;
    jSpawnY = bip.y;
  }
  bip.x = jSpawnX; bip.y = jSpawnY; bip.vx = bip.vy = 0;
  jDrawRoom();
  jHud();
}
static void jStart() {
  gameColors();
  loadBest();
  if (!gWinOk) gWinOk = makeSprite(gWin, 64, 64);
  // décor complet en mémoire : trop grand pour la mémoire interne, et la PSRAM abîmait l'image -> on dessine case par case
  memset(jCoins, 0, sizeof(jCoins));
  jLives = 3; jScore = 0; jState = 0; jJumpPrev = true; jHurtUntil = 0;
  bip = {0, 0, 0, 0, 12, 15, true, false, 0, 0};
  bipRight = true;
  jEnterRoom(0, false);
  sfx(SFX_START);
}
static bool jRectSolid(float x, float y, int w, int h) {
  int x0 = (int)floorf(x / TILE), x1 = (int)floorf((x + w - 1) / TILE);
  int y0 = (int)floorf(y / TILE), y1 = (int)floorf((y + h - 1) / TILE);
  for (int ty = y0; ty <= y1; ty++)
    for (int tx = x0; tx <= x1; tx++)
      if (jSolid(tx, ty)) return true;
  return false;
}
static void jMove(GEnt& e) {                      // déplacement avec collisions, axe par axe
  float nx = e.x + e.vx;
  if (jRectSolid(nx, e.y, e.w, e.h)) {
    float s = e.vx > 0 ? 1 : -1;
    while (!jRectSolid(e.x + s, e.y, e.w, e.h) && fabsf(nx - e.x) >= 1) e.x += s;
    e.vx = 0;
  } else e.x = nx;
  float ny = e.y + e.vy;
  e.ground = false;
  if (jRectSolid(e.x, ny, e.w, e.h)) {
    float s = e.vy > 0 ? 1 : -1;
    while (!jRectSolid(e.x, e.y + s, e.w, e.h) && fabsf(ny - e.y) >= 1) e.y += s;
    if (e.vy > 0) e.ground = true;
    e.vy = 0;
  } else e.y = ny;
}
static bool jTouches(char c, float x, float y, int w, int h, int* ctx = nullptr, int* cty = nullptr) {
  for (int ty = (int)(y + 3) / TILE; ty <= (int)(y + h - 3) / TILE; ty++)
    for (int tx = (int)(x + 3) / TILE; tx <= (int)(x + w - 3) / TILE; tx++)
      if (jTile(tx, ty) == c) { if (ctx) { *ctx = tx; *cty = ty; } return true; }
  return false;
}
static void jEnd(bool won) {
  jState = won ? 2 : 1;
  musicPlay(false);
  sfx(won ? SFX_WIN : SFX_OVER);
  if (won) jScore += jLives * 500;
  bool rec = jScore > bestJump;
  if (rec) { bestJump = jScore; saveBest(); }
  gameOverlay(won ? "Bravo, niveau fini !" : "Partie terminee", String("Score ") + jScore + (rec ? "  (record !)" : ""),
              String("Record ") + bestJump + "  -  une touche pour rejouer");
  jHud();
}
static void jHurt() {
  if (millis() < jHurtUntil) return;
  jLives--;
  if (jLives <= 0) { jEnd(false); return; }
  sfx(SFX_HURT);
  jHurtUntil = millis() + 1200;
  bip.x = jSpawnX; bip.y = jSpawnY; bip.vx = bip.vy = 0;
  jDrawRoom();
  jHud();
}

static void jStep() {
  float nx, ny;
  gameJoy(nx, ny);
  int dir = gTouchDir ? gTouchDir : (nx > 0.3f ? 1 : nx < -0.3f ? -1 : 0);
  bool jump = gameButton() || ny < -0.7f;
  if (dir || jump) markActivity();
  musicPlay(jState == 0);
  if (jState != 0) {                               // écran de fin : une touche relance
    if (jump && !jJumpPrev) jStart();
    jJumpPrev = jump;
    return;
  }
  float target = dir * 3.0f;
  bip.vx += (target - bip.vx) * 0.35f;
  if (dir) bipRight = dir > 0;
  if (jump && !jJumpPrev && bip.ground) { bip.vy = -9.0f; sfx(SFX_JUMP); }
  if (!jump && bip.vy < -3.5f) bip.vy = -3.5f;     // saut plus court si on relâche tôt
  jJumpPrev = jump;
  bip.vy = fminf(bip.vy + 0.55f, 9.5f);
  int ox = bip.dx, oy = bip.dy;
  jMove(bip);

  if (bip.x > SCREEN_W - bip.w / 2 && jRoom < JUMP_NROOMS - 1) { jEnterRoom(jRoom + 1, false); return; }
  if (bip.x < -bip.w / 2 && jRoom > 0) { jEnterRoom(jRoom - 1, true); return; }
  if (bip.y > PLAY_H) { jHurt(); return; }
  if (jTouches('^', bip.x, bip.y, bip.w, bip.h)) { jHurt(); return; }
  int ctx, cty;
  if (jTouches('o', bip.x, bip.y, bip.w, bip.h, &ctx, &cty) && !jCoinTaken(ctx, cty)) {
    jCoins[jRoom] |= 1u << (jCoinIndex(ctx, cty) & 31);
    jBgTile(ctx, cty);
    jScore += 10;
    sfx(SFX_COIN);
    jRegion(ctx * TILE - 24, cty * TILE - 24);
    jHud();
  }
  if (jTouches('F', bip.x, bip.y, bip.w, bip.h)) { jEnd(true); return; }

  for (int i = 0; i < nFoes; i++) {                // ennemis : marchent et font demi-tour au bord ou contre un mur
    GEnt& f = foes[i];
    if (!f.alive) continue;
    int fox = f.dx, foy = f.dy;
    int ahead = (int)(f.vx > 0 ? f.x + f.w + 1 : f.x - 1) / TILE;
    int below = (int)(f.y + f.h + 2) / TILE;
    if (f.ground && (!jSolid(ahead, below) || jSolid(ahead, (int)(f.y + 4) / TILE) || ahead < 0 || ahead >= JUMP_COLS)) f.vx = -f.vx;
    float keep = f.vx;
    f.vy = fminf(f.vy + 0.55f, 9.5f);
    jMove(f);
    if (f.vx == 0) f.vx = -keep;
    if (f.y > PLAY_H) { f.alive = false; }
    if (bip.x < f.x + f.w && bip.x + bip.w > f.x && bip.y < f.y + f.h && bip.y + bip.h > f.y) {
      if (bip.vy > 0 && bip.y + bip.h - bip.vy <= f.y + 6) {      // écrasé par le dessus
        f.alive = false;
        bip.vy = -6.5f;
        jScore += 100;
        sfx(SFX_STOMP);
        jHud();
      } else { jHurt(); return; }
    }
    if ((int)f.x != fox || (int)f.y != foy || !f.alive) jRegion(min(fox, (int)f.x) - 22, min(foy, (int)f.y) - 24);
  }
  if ((int)bip.x != ox || (int)bip.y != oy || millis() < jHurtUntil + 100)
    jRegion(min(ox, (int)bip.x) - 24, min(oy, (int)bip.y) - 26);
}

// ========================================================================== Serpent ================
static const int SN_COLS = 30, SN_ROWS = 17;
static uint16_t snBody[SN_COLS * SN_ROWS];         // positions (y * SN_COLS + x), de la queue à la tête
static int snLen = 0, snHead = 0, snDir = 0, snNext = 0, snFood = -1, snState = 0, snScore = 0;
static uint32_t snLast = 0, snStepMs = 150;
static bool snBtnPrev = true;
static const int8_t SN_DX[4] = {1, 0, -1, 0}, SN_DY[4] = {0, 1, 0, -1};   // droite, bas, gauche, haut

static void snCell(int p, uint16_t c, bool head = false) {
  int x = (p % SN_COLS) * TILE, y = GY + (p / SN_COLS) * TILE;
  if (c == C_SNAKE_BG) { lcd.fillRect(x, y, TILE, TILE, c); return; }
  lcd.fillRoundRect(x + 1, y + 1, TILE - 2, TILE - 2, 4, c);
  if (head) {
    int ex = SN_DX[snDir], ey = SN_DY[snDir];
    lcd.fillCircle(x + 8 + ex * 3 - ey * 3, y + 8 + ey * 3 - ex * 3, 2, TFT_WHITE);
    lcd.fillCircle(x + 8 + ex * 3 + ey * 3, y + 8 + ey * 3 + ex * 3, 2, TFT_WHITE);
  }
}
static bool snOnBody(int p) {
  for (int i = 0; i < snLen; i++) if (snBody[(snHead - i + SN_COLS * SN_ROWS) % (SN_COLS * SN_ROWS)] == p) return true;
  return false;
}
static void snPlaceFood() {
  do snFood = random(SN_COLS * SN_ROWS); while (snOnBody(snFood));
  int x = (snFood % SN_COLS) * TILE, y = GY + (snFood / SN_COLS) * TILE;
  lcd.fillCircle(x + 8, y + 9, 6, C_APPLE);
  lcd.drawFastVLine(x + 8, y + 1, 4, C_SNAKE2);
  lcd.fillCircle(x + 10, y + 3, 2, C_SNAKE);
}
static void snHud() { gameHud = String("Serpent  ") + snScore + " pts   record " + bestSnake; drawHeader(); }
static void snStart() {
  gameColors();
  loadBest();
  lcd.fillRect(0, GY, SCREEN_W, PLAY_H, C_SNAKE_BG);
  lcd.fillRect(0, GY + PLAY_H, SCREEN_W, SCREEN_H - GY - PLAY_H, TFT_BLACK);
  snLen = 3; snHead = 2; snDir = snNext = 0; snState = 0; snScore = 0; snStepMs = 150; snBtnPrev = true;
  int start = 8 * SN_COLS + 5;
  for (int i = 0; i < 3; i++) { snBody[i] = start + i; snCell(start + i, C_SNAKE, i == 2); }
  snPlaceFood();
  snHud();
}
static void snStep() {
  float nx, ny;
  gameJoy(nx, ny);
  bool btn = gameButton() || gTouchTap;
  gTouchTap = false;
  int want = -1;
  if (fabsf(nx) > 0.5f || fabsf(ny) > 0.5f) want = fabsf(nx) > fabsf(ny) ? (nx > 0 ? 0 : 2) : (ny > 0 ? 1 : 3);
  if (gTouchDir) { want = gTouchDir - 1; gTouchDir = 0; }   // toucher : direction vers le doigt (codée 1..4)
  if (want >= 0 || btn) markActivity();
  if (snState) {
    if (btn && !snBtnPrev) snStart();
    snBtnPrev = btn;
    return;
  }
  snBtnPrev = btn;
  if (want >= 0 && want != (snDir + 2) % 4) snNext = want;
  if (millis() - snLast < snStepMs) return;
  snLast = millis();
  snDir = snNext;
  int hp = snBody[snHead], hx = hp % SN_COLS + SN_DX[snDir], hy = hp / SN_COLS + SN_DY[snDir];
  int np = hy * SN_COLS + hx;
  if (hx < 0 || hx >= SN_COLS || hy < 0 || hy >= SN_ROWS || snOnBody(np)) {
    snState = 1;
    sfx(SFX_OVER);
    bool rec = snScore > bestSnake;
    if (rec) { bestSnake = snScore; saveBest(); }
    gameOverlay("Perdu !", String("Score ") + snScore + (rec ? "  (record !)" : ""), String("Record ") + bestSnake + "  -  une touche pour rejouer");
    return;
  }
  const int N = SN_COLS * SN_ROWS;
  snCell(hp, C_SNAKE);
  snHead = (snHead + 1) % N;
  snBody[snHead] = np;
  if (np == snFood) {
    snLen++;
    snScore += 10;
    sfx(SFX_EAT);
    snStepMs = snStepMs > 74 ? snStepMs - 4 : 70;
    snCell(np, C_SNAKE2, true);
    snPlaceFood();
    snHud();
  } else {
    int tail = snBody[(snHead - snLen + N) % N];
    snCell(tail, C_SNAKE_BG);
    snCell(np, C_SNAKE2, true);
  }
}

// ============================================================================ Liste des jeux ======
static void gamesListDraw() {
  gameColors();
  loadBest();
  lcd.fillRect(0, GY, SCREEN_W, SCREEN_H - GY, TFT_BLACK);
  const char* names[2] = {"Plateformes", "Serpent"};
  int best[2] = {bestJump, bestSnake};
  for (int i = 0; i < 2; i++) {
    int w = 210, h = 200, x = 20 + i * 240, y = GY + 24;
    uint32_t col = i == 0 ? 0x2E86C1 : 0x27AE60;
    lcd.fillRoundRect(x, y + 7, w, h - 7, 14, shade(col, 0.4f));
    lcd.fillRoundRect(x, y, w, h - 7, 14, shade(col, 1.0f, 0.1f));
    if (i == gamesSel) { lcd.drawRoundRect(x - 3, y - 3, w + 6, h + 4, 16, TFT_WHITE); lcd.drawRoundRect(x - 2, y - 2, w + 4, h + 2, 15, TFT_WHITE); }
    if (i == 0) {                                   // petit décor
      lcd.fillRect(x + 30, y + 110, 150, 16, C_DIRT); lcd.fillRect(x + 30, y + 110, 150, 5, C_GRASS);
      bip.ground = false; bipRight = true; jHurtUntil = 0;
      jDrawBip(lcd, x + 70, y + 92);
      jDrawFoe(lcd, x + 130, y + 96);
      lcd.fillCircle(x + 105, y + 60, 6, C_COIN);
    } else {
      for (int k = 0; k < 6; k++) lcd.fillRoundRect(x + 50 + k * 18, y + 90, 16, 16, 4, k == 5 ? C_SNAKE2 : C_SNAKE);
      lcd.fillCircle(x + 175, y + 98, 7, C_APPLE);
    }
    lcd.setTextDatum(middle_center);
    lcd.setTextColor(TFT_WHITE);
    lcd.setFont(FONT_L);
    lcd.drawString(names[i], x + w / 2, y + 30);
    lcd.setFont(FONT_S);
    lcd.setTextColor(0xEF7D);
    lcd.drawString(String("Record : ") + best[i], x + w / 2, y + h - 30);
  }
  lcd.setFont(FONT_S);
  lcd.setTextColor(0x8410);
  lcd.setTextDatum(middle_center);
  lcd.drawString("Joystick pour choisir, une touche pour jouer, bouton nav pour quitter", SCREEN_W / 2, SCREEN_H - 22);
}
static void gamesStartSel() {
  mode = gamesSel == 0 ? M_JUMP : M_SNAKE;
  drawHeader();
  if (mode == M_JUMP) jStart(); else snStart();
}
static void gamesListStep() {
  static bool prevBtn = true;
  static int8_t prevDir = 0;
  float nx, ny;
  gameJoy(nx, ny);
  int8_t d = nx > 0.5f ? 1 : nx < -0.5f ? -1 : 0;
  if (d && d != prevDir) { gamesSel = d > 0 ? 1 : 0; gamesListDraw(); markActivity(); sfx(SFX_CLICK); }
  prevDir = d;
  bool b = gameButton();
  if (b && !prevBtn) { markActivity(); gamesStartSel(); }
  prevBtn = b;
}

// ------------------------------------------------------------------ points d'entrée ---------------
static void gamesDraw() {                          // appelé par drawAll()
  if (mode == M_GAMES) gamesListDraw();
  else if (mode == M_JUMP) { jDrawRoom(); jHud(); }
  else { snStart(); }
}
static void gamesTask() {
  static uint32_t last = 0;
  if (millis() - last < 25) return;                // 40 images par seconde au plus
  last = millis();
  if (mode == M_GAMES) gamesListStep();
  else if (mode == M_JUMP) jStep();
  else if (mode == M_SNAKE) snStep();
}
static void gameTouchDown(int x, int y) {
  if (mode == M_GAMES) {
    gamesSel = x < SCREEN_W / 2 ? 0 : 1;
    gamesStartSel();
  } else if (mode == M_JUMP) {
    if (x < SCREEN_W / 3) gTouchDir = -1; else if (x > SCREEN_W * 2 / 3) gTouchDir = 1; else gTouchJump = true;
  } else if (mode == M_SNAKE) {                    // direction vers le doigt, par rapport à la tête
    int hp = snBody[snHead], hx = (hp % SN_COLS) * TILE + 8, hy = GY + (hp / SN_COLS) * TILE + 8;
    int dx = x - hx, dy = y - hy;
    gTouchDir = (abs(dx) > abs(dy) ? (dx > 0 ? 0 : 2) : (dy > 0 ? 1 : 3)) + 1;
    gTouchTap = true;
  }
}
static void gameTouchUp() { if (mode == M_JUMP) { gTouchDir = 0; gTouchJump = false; } }
