// =====================================================================================================
// JC_Wifi.h — Wi-Fi du pad V2 : le pad prend lui-même l'heure (NTP) et la météo (Open-Meteo), sans PC.
// Réglages envoyés par JCharles desktop (une fois, par le câble USB) :
//   HCD_WIFI {"s":"MaBox","p":"motdepasse","lat":47.9,"lon":1.91,"c":"Orleans"}
// Le mot de passe est gardé dans la mémoire du pad (Preferences « hcdwifi ») et n'est jamais renvoyé.
// Mode (réglage matériel "wifi") : off ; periodic = connexion de quelques secondes toutes les 30 minutes ;
// always = reste connecté (consomme davantage, à réserver au fonctionnement sur secteur).
// Le travail réseau tourne dans une tâche à part : l'écran et les touches ne sont jamais bloqués.
// =====================================================================================================
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>

static String wfSsid, wfPass, wfCity;
static float wfLat = 0, wfLon = 0;
static volatile bool wfBusy = false, wfResultReady = false;
static volatile bool wfAskNow = false;
static String wfMsg;                          // message pour l'écran (toast) à la fin d'une connexion
static WxData wfWx;                           // météo reçue, recopiée dans wx par la boucle principale
static bool wfWxOk = false;
static uint32_t wfNext = 15000;               // première connexion 15 s après le démarrage

static void wifiLoad() {
  Preferences p; p.begin("hcdwifi", true);
  wfSsid = p.getString("s", ""); wfPass = p.getString("p", ""); wfCity = p.getString("c", "");
  wfLat = p.getFloat("lat", 0); wfLon = p.getFloat("lon", 0);
  p.end();
}
static bool wifiConfigured() { return wfSsid.length() > 0; }

static int dayOfWeek(const char* iso) {       // « 2026-11-06 » -> 0 = dimanche
  int y = atoi(iso), m = atoi(iso + 5), d = atoi(iso + 8);
  static const int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
  if (m < 3) y -= 1;
  return (y + y / 4 - y / 100 + y / 400 + t[(m + 11) % 12] + d) % 7;
}

static void wifiJob(void*) {
  static const char* JOURS[] = {"Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"};
  String msg;
  WiFi.mode(WIFI_STA);
  WiFi.begin(wfSsid.c_str(), wfPass.c_str());
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) vTaskDelay(pdMS_TO_TICKS(200));
  if (WiFi.status() != WL_CONNECTED) {
    msg = "Wi-Fi : pas de connexion";
  } else {
    configTime(0, 0, "pool.ntp.org", "time.google.com");            // heure universelle ; décalage local plus bas
    time_t utc = 0;
    for (int i = 0; i < 25 && (utc = time(nullptr)) < 1700000000; i++) vTaskDelay(pdMS_TO_TICKS(200));
    bool gotWx = false;
    long offset = 0;
    if (wfLat != 0 || wfLon != 0) {
      WiFiClientSecure cli;
      cli.setInsecure();                      // pas de vérification du certificat : données publiques, sans secret
      HTTPClient http;
      String url = String("https://api.open-meteo.com/v1/forecast?latitude=") + String(wfLat, 3) + "&longitude=" + String(wfLon, 3) +
                   "&timezone=auto&forecast_days=3&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,is_day"
                   "&daily=weather_code,temperature_2m_max,temperature_2m_min";
      if (http.begin(cli, url)) {
        http.setTimeout(8000);
        if (http.GET() == 200) {
          JsonDocument d;
          if (!deserializeJson(d, http.getStream())) {
            offset = d["utc_offset_seconds"] | 0L;
            WxData w;
            w.city = wfCity;
            w.t = d["current"]["temperature_2m"] | 0.0f;
            w.code = d["current"]["weather_code"] | 0;
            w.day = (d["current"]["is_day"] | 1) != 0;
            w.hum = (int)lroundf(d["current"]["relative_humidity_2m"] | 0.0f);
            w.wind = (int)lroundf(d["current"]["wind_speed_10m"] | 0.0f);
            for (int i = 0; i < 3; i++) {
              w.fc[i] = d["daily"]["weather_code"][i] | 0;
              w.fmax[i] = (int)lroundf(d["daily"]["temperature_2m_max"][i] | 0.0f);
              w.fmin[i] = (int)lroundf(d["daily"]["temperature_2m_min"][i] | 0.0f);
              const char* day = d["daily"]["time"][i] | "2026-01-01";
              w.fname[i] = i == 0 ? "Auj." : JOURS[dayOfWeek(day)];
            }
            w.ok = true;
            wfWx = w;
            gotWx = true;
          }
        }
        http.end();
      }
    }
    if (utc > 1700000000) {                   // heure locale = UTC + décalage donné par Open-Meteo
      struct timeval tv = {utc + offset, 0};
      if (gotWx || offset == 0) settimeofday(&tv, nullptr);
    }
    wfWxOk = gotWx;
    msg = gotWx ? "Wi-Fi : meteo et heure a jour" : (utc > 1700000000 ? "Wi-Fi : heure a jour" : "Wi-Fi : Internet injoignable");
  }
  if (hw.wifiMode != 2) { WiFi.disconnect(true); WiFi.mode(WIFI_OFF); }    // connexion courte : on coupe
  wfMsg = msg;
  wfResultReady = true;
  wfBusy = false;
  vTaskDelete(nullptr);
}

static void wifiTask() {                      // appelé par loop()
  if (wfResultReady) {
    wfResultReady = false;
    if (wfWxOk) {
      wx = wfWx; wx.at = millis();
      if (mode == M_WEATHER && !saverOn) drawAll();
      else if (mode == M_MENU && !saverOn && !T.down)
        for (int i = 0; i < slots(); i++) { Slot sl = getSlot(i); if (sl.used && !strcmp(sl.item["live"] | "", "weather")) drawCell(i, false); }
    }
    drawHeader();
    if (wfAskNow) { wfAskNow = false; toast(wfMsg.c_str()); }
  }
  if (hw.wifiMode == 0 || !wifiConfigured() || wfBusy) return;
  if (!wfAskNow && (long)(millis() - wfNext) < 0) return;
  wfNext = millis() + 30UL * 60000UL;
  wfBusy = true;
  xTaskCreatePinnedToCore(wifiJob, "wifi", 12288, nullptr, 1, nullptr, 0);
}

static void wifiSet(const String& js) {
  JsonDocument d;
  if (deserializeJson(d, js)) { Out.println("HCD_WIFI_ERR json"); return; }
  Preferences p; p.begin("hcdwifi", false);
  if (d["s"].is<const char*>()) p.putString("s", (const char*)d["s"]);
  if (d["p"].is<const char*>()) p.putString("p", (const char*)d["p"]);
  if (d["c"].is<const char*>()) p.putString("c", (const char*)d["c"]);
  if (d["lat"].is<float>()) p.putFloat("lat", d["lat"]);
  if (d["lon"].is<float>()) p.putFloat("lon", d["lon"]);
  if (d["forget"] | false) p.clear();
  p.end();
  wifiLoad();
  Out.println("HCD_WIFI_OK");
  if (wifiConfigured()) { wfAskNow = true; wfNext = millis(); }   // essai dès que le mode Wi-Fi est actif
}
