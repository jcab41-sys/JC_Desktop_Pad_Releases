// =====================================================================================================
// JC_Weather.h — écran Météo du pad V2 (tuile « Mode spécial > Météo ») et tuile vivante « weather ».
// Le pad n'a pas Internet : JCharles desktop lit la météo (Open-Meteo, données CC BY 4.0) et l'envoie par
//   HCD_WEATHER {"c":"Paris","t":12.3,"w":61,"d":1,"h":80,"v":14,"f":[[61,14,7,"Auj."],[3,15,8,"Dim"],[0,17,6,"Lun"]]}
//   c ville, t température, w code météo WMO, d jour (1) ou nuit (0), h humidité %, v vent km/h,
//   f trois jours : [code, max, min, nom du jour].
// Animation : soleil (rayons qui tournent), lune et étoiles, nuages qui passent, pluie, neige, orage, brouillard.
// =====================================================================================================

struct WxData {
  bool ok = false;
  String city;
  float t = 0;
  int code = 0, hum = 0, wind = 0;
  bool day = true;
  int fc[3] = {0, 0, 0}, fmax[3] = {0, 0, 0}, fmin[3] = {0, 0, 0};
  String fname[3];
  uint32_t at = 0;                     // millis() de réception
};
static WxData wx;
static LGFX_Sprite wxSpr(&lcd);
static bool wxSprOk = false;
static const int WX_AW = 220, WX_AH = 160;     // zone animée

enum WxCat { WX_CLEAR, WX_PARTLY, WX_CLOUDY, WX_FOG, WX_DRIZZLE, WX_RAIN, WX_SNOW, WX_STORM };
static WxCat wxCat(int c) {
  if (c == 0) return WX_CLEAR;
  if (c <= 2) return WX_PARTLY;
  if (c == 3) return WX_CLOUDY;
  if (c == 45 || c == 48) return WX_FOG;
  if (c >= 51 && c <= 57) return WX_DRIZZLE;
  if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) return WX_RAIN;
  if ((c >= 71 && c <= 77) || c == 85 || c == 86) return WX_SNOW;
  if (c >= 95) return WX_STORM;
  return WX_CLOUDY;
}
static const char* wxText(int c) {
  switch (wxCat(c)) {
    case WX_CLEAR: return "Ciel dégagé";
    case WX_PARTLY: return "Peu nuageux";
    case WX_CLOUDY: return "Couvert";
    case WX_FOG: return "Brouillard";
    case WX_DRIZZLE: return "Bruine";
    case WX_RAIN: return (c >= 80) ? "Averses" : (c >= 65 ? "Forte pluie" : "Pluie");
    case WX_SNOW: return "Neige";
    default: return "Orage";
  }
}
static uint16_t wxBg(bool day) { return day ? lcd.color565(28, 64, 112) : lcd.color565(8, 14, 34); }

static void wxCloud(LovyanGFX& g, float cx, float cy, float s, uint16_t c) {   // nuage : 4 boules + base
  g.fillCircle(cx - 22 * s, cy + 4 * s, 14 * s, c);
  g.fillCircle(cx - 4 * s, cy - 8 * s, 19 * s, c);
  g.fillCircle(cx + 18 * s, cy, 15 * s, c);
  g.fillCircle(cx + 32 * s, cy + 8 * s, 10 * s, c);
  g.fillRoundRect(cx - 34 * s, cy + 4 * s, 74 * s, 16 * s, 8 * s, c);
}

// Dessine la scène météo dans le rectangle (ox, oy, w, h). t = temps en ms (0 = image fixe), s = échelle.
static void wxScene(LovyanGFX& g, int ox, int oy, int w, int h, int code, bool day, uint32_t t, float s) {
  WxCat k = wxCat(code);
  float cx = ox + w * 0.42f, cy = oy + h * 0.38f;
  uint16_t white = lcd.color565(240, 244, 250), grey = lcd.color565(150, 160, 175), dark = lcd.color565(95, 104, 120);
  bool sky = (k == WX_CLEAR || k == WX_PARTLY);
  if (sky && day) {                                         // soleil
    float sx = k == WX_CLEAR ? cx + 6 * s : cx - 18 * s, sy = k == WX_CLEAR ? cy + 8 * s : cy - 6 * s;
    float a0 = t * 0.0006f;
    for (int i = 0; i < 10; i++) {
      float a = a0 + i * 0.6283f;
      g.drawWideLine(sx + cosf(a) * 36 * s, sy + sinf(a) * 36 * s, sx + cosf(a) * 50 * s, sy + sinf(a) * 50 * s,
                     max(1.0f, 3 * s), lcd.color565(255, 196, 40));
    }
    g.fillCircle(sx, sy, 28 * s, lcd.color565(255, 210, 50));
    g.fillCircle(sx - 7 * s, sy - 7 * s, 12 * s, lcd.color565(255, 232, 120));
  } else if (sky) {                                         // lune et étoiles
    float mx = cx - 4 * s, my = cy;
    for (int i = 0; i < 7; i++) {
      int stx = ox + (int)(w * (0.08f + 0.85f * fmodf(i * 0.618f, 1))), sty = oy + (int)(h * (0.08f + 0.5f * fmodf(i * 0.371f, 1)));
      bool on = ((t / 400 + i * 3) % 7) != 0;
      if (on) g.fillCircle(stx, sty, max(1.0f, 1.6f * s), white);
    }
    g.fillCircle(mx, my, 26 * s, lcd.color565(236, 232, 200));
    g.fillCircle(mx + 12 * s, my - 8 * s, 22 * s, wxBg(false));
  }
  float drift = t ? fmodf(t * 0.012f, w + 120 * s) - 60 * s : 0;     // nuages qui passent
  if (k == WX_PARTLY) wxCloud(g, cx + 22 * s + (t ? sinf(t * 0.0008f) * 10 * s : 0), cy + 18 * s, s, white);
  if (k == WX_CLOUDY || k == WX_FOG) {
    wxCloud(g, t ? ox + drift : cx - 20 * s, cy - 6 * s, s * 0.8f, grey);
    wxCloud(g, cx + 14 * s, cy + 14 * s, s, white);
  }
  if (k == WX_DRIZZLE || k == WX_RAIN || k == WX_SNOW || k == WX_STORM) {
    uint16_t cc = k == WX_SNOW ? white : (k == WX_STORM ? dark : grey);
    wxCloud(g, cx - 18 * s + (t ? sinf(t * 0.0006f) * 6 * s : 0), cy - 12 * s, s * 0.85f, k == WX_STORM ? lcd.color565(70, 76, 92) : dark);
    wxCloud(g, cx + 10 * s, cy, s, cc);
  }
  float top = cy + 22 * s, bot = oy + h - 4;
  if (k == WX_DRIZZLE || k == WX_RAIN || k == WX_STORM) {   // gouttes
    int n = k == WX_DRIZZLE ? 9 : 16;
    uint16_t rc = lcd.color565(110, 170, 255);
    for (int i = 0; i < n; i++) {
      float x = cx - 34 * s + 74 * s * fmodf(i * 0.618f + 0.1f, 1);
      float y = top + fmodf(t * 0.18f + i * 37, max(8.0f, bot - top));
      float len = (k == WX_DRIZZLE ? 5 : 10) * s + 2;
      g.drawWideLine(x, y, x - 2 * s, y + len, max(1.0f, 1.2f * s), rc);
    }
  }
  if (k == WX_SNOW) {                                       // flocons qui tombent en se balançant
    for (int i = 0; i < 14; i++) {
      float x = cx - 34 * s + 74 * s * fmodf(i * 0.618f + 0.05f, 1) + (t ? sinf(t * 0.003f + i) * 5 * s : 0);
      float y = top + fmodf(t * 0.05f + i * 29, max(8.0f, bot - top));
      g.fillCircle(x, y, max(1.0f, 2.5f * s), white);
    }
  }
  if (k == WX_STORM && (t == 0 || (t / 120) % 18 < 2)) {    // éclair
    uint16_t yc = lcd.color565(255, 230, 60);
    float lx = cx + 4 * s, ly = top - 2 * s;
    g.fillTriangle(lx, ly, lx - 10 * s, ly + 22 * s, lx + 2 * s, ly + 20 * s, yc);
    g.fillTriangle(lx + 2 * s, ly + 16 * s, lx - 6 * s, ly + 40 * s, lx + 10 * s, ly + 14 * s, yc);
  }
  if (k == WX_FOG) {                                        // bandes de brume qui glissent
    for (int i = 0; i < 4; i++) {
      float y = cy + 28 * s + i * 11 * s, off = t ? sinf(t * 0.001f + i) * 14 * s : 0;
      g.drawWideLine(cx - 40 * s + off, y, cx + 44 * s + off, y, max(1.0f, 2.5f * s), grey);
    }
  }
}

static String wxTileText() { return wx.ok ? String((int)lroundf(wx.t)) + "\xC2\xB0" : String(""); }

static void drawWeather() {
  uint16_t bg = wxBg(wx.ok ? wx.day : true);
  lcd.fillRect(0, HEADER_H, SCREEN_W, SCREEN_H - HEADER_H, bg);
  lcd.setBaseColor(bg);                                  // fond pour le lissage des textes (écran non relisible)
  lcd.setTextDatum(middle_center);
  if (!wx.ok) {
    lcd.setFont(FONT_M);
    lcd.setTextColor(TFT_WHITE);
    lcd.drawString("Météo en attente", SCREEN_W / 2, SCREEN_H / 2 - 14);
    lcd.setFont(FONT_S);
    lcd.setTextColor(0xBDF7);
    lcd.drawString("Reliez le pad au PC en USB, avec JCharles desktop ouvert", SCREEN_W / 2, SCREEN_H / 2 + 16);
    return;
  }
  // à droite : ville, température, ciel, humidité et vent
  int rx = 240 + 120;
  lcd.setTextColor(0xDEFB);
  lcd.setFont(FONT_M);
  String city = wx.city;
  while (city.length() > 3 && lcd.textWidth(city) > 220) city.remove(city.length() - 1);
  lcd.drawString(city, rx, HEADER_H + 22);
  lcd.setFont(FONT_XL);                                // grands chiffres lissés (chiffres, « - » et « ° » seulement)
  lcd.setTextColor(TFT_WHITE, bg);
  lcd.drawString(String((int)lroundf(wx.t)) + "\u00B0", rx, HEADER_H + 82);
  lcd.setFont(FONT_M);
  lcd.setTextColor(lcd.color565(255, 214, 90));
  lcd.drawString(wxText(wx.code), rx, HEADER_H + 132);
  lcd.setFont(FONT_S);
  lcd.setTextColor(0xBDF7);
  lcd.drawString(String("Humidité ") + wx.hum + " %   Vent " + wx.wind + " km/h", rx, HEADER_H + 160);
  // en bas : trois jours
  const int cy = HEADER_H + 186, cw = 150, ch = SCREEN_H - cy - 16;
  for (int i = 0; i < 3; i++) {
    int x = 9 + i * (cw + 6);
    lcd.fillRoundRect(x, cy, cw, ch, 10, shade(wx.day ? 0x1C4070 : 0x0E1A38, 1.0f, 0.10f));
    lcd.setFont(FONT_S);
    lcd.setTextColor(TFT_WHITE);
    lcd.setTextDatum(middle_left);
    lcd.drawString(wx.fname[i], x + 10, cy + 18);
    lcd.setTextDatum(middle_right);
    lcd.setTextColor(lcd.color565(255, 150, 120));
    lcd.drawString(String(wx.fmax[i]) + "\xC2\xB0", x + cw - 10, cy + 18);
    lcd.setTextColor(lcd.color565(130, 190, 255));
    lcd.drawString(String(wx.fmin[i]) + "\xC2\xB0", x + cw - 10, cy + ch - 20);
    wxScene(lcd, x + 6, cy + 30, 92, ch - 34, wx.fc[i], true, 0, 0.42f);
  }
  lcd.setTextDatum(bottom_right);
  lcd.setFont(&fonts::Font0);
  lcd.setTextColor(0x8410);
  lcd.drawString("Données Open-Meteo.com", SCREEN_W - 6, SCREEN_H - 2);
  lcd.setTextDatum(middle_center);
  lcd.setBaseColor(TFT_BLACK);
}

static void weatherTask() {                    // animation : 20 images par seconde
  static uint32_t last = 0;
  if (!wx.ok || saverOn || millis() - last < 50) return;
  last = millis();
  if (!wxSprOk) wxSprOk = makeSprite(wxSpr, WX_AW, WX_AH);
  if (!wxSprOk) return;
  wxSpr.fillScreen(wxBg(wx.day));
  wxScene(wxSpr, 0, 0, WX_AW, WX_AH, wx.code, wx.day, millis(), 1.25f);
  wxSpr.pushSprite(10, HEADER_H + 14);
}

static void weatherSet(const String& js) {
  JsonDocument d;
  if (deserializeJson(d, js)) { Out.println("HCD_WEATHER_ERR json"); return; }
  wx.city = (const char*)(d["c"] | "");
  wx.t = d["t"] | 0.0f;
  wx.code = d["w"] | 0;
  wx.day = (d["d"] | 1) != 0;
  wx.hum = d["h"] | 0;
  wx.wind = d["v"] | 0;
  JsonArrayConst f = d["f"].as<JsonArrayConst>();
  for (int i = 0; i < 3; i++) {
    JsonArrayConst e = f[i].as<JsonArrayConst>();
    wx.fc[i] = e[0] | 0; wx.fmax[i] = e[1] | 0; wx.fmin[i] = e[2] | 0;
    wx.fname[i] = (const char*)(e[3] | "");
  }
  wx.ok = true;
  wx.at = millis();
  Out.println("HCD_WEATHER_OK");
  if (mode == M_WEATHER && !saverOn) drawAll();
  else if (mode == M_MENU && !saverOn && !T.down)
    for (int i = 0; i < slots(); i++) { Slot sl = getSlot(i); if (sl.used && !strcmp(sl.item["live"] | "", "weather")) drawCell(i, false); }
}
