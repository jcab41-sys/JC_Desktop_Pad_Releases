# HCD-S3-TOUCH v0.4 — ESP32-S3 + écran tactile ILI9341 2,8"

**Statut : code écrit mais non compilé ni testé sur matériel.** Prévoyez un temps de mise au point
(calibration tactile, brochage, polices, ordre des octets des icônes, sens du joystick). Ce n'est pas le
firmware officiel HackMan3D ; le protocole série est propre à ce prototype. Tout se configure avec
l'application **JCharles desktop** (dossier `JC_Studio`).

## Nouveautés v0.3
- **8 icônes par page** (grille 4 × 2) ou 6 (3 × 2), au choix dans JCharles desktop.
- **3 touches physiques** programmables (appui court / long), avec une LED chacune.
- **LED séparées** : une LED de couleur par touche et un voyant vert d'état (GPIO en PWM) ; **ruban WS2812** de 4 pixels pour la barre qui s'allume au toucher. Intensité réglable (ou éteinte) par groupe.
- **Potentiomètre** : volume du PC (touches USB, ou exact via JCharles desktop), luminosité de l'écran, intensité des LED.
- **Joystick type PS2** : souris, orbite ou déplacement 3D (Fusion 360), défilement.
- Pages par balayage, dossiers, icônes, mode Pad 3D tactile et mode Volume tactile (comme en v0.2).
- Pas de Bluetooth dans cette version.

## Brochage (mini carte ESP32-S3, GPIO 1 à 13, 18, TX et RX exposés)

| Fonction | GPIO | Branchement |
|---|---|---|
| SPI SCK | 12 | SCK et T_CLK de l'écran |
| SPI MOSI | 11 | SDI et T_DIN |
| SPI MISO | 13 | SDO et T_DO |
| TFT CS | 10 | CS |
| TFT DC | 9 | DC/RS |
| TFT RESET | — | **relier le RESET de l'écran au 3V3** (libère une broche) |
| Tactile CS | 7 | T_CS |
| Rétroéclairage | 5 | LED de l'écran (transistor conseillé) |
| Potentiomètre | 1 | curseur ; extrémités au 3V3 et au GND |
| Joystick X | 2 | VRx |
| Joystick Y | 4 | VRy |
| Joystick clic | 6 | SW, l'autre côté au GND |
| Bouton « navigation joystick » (optionnel) | 3 | poussoir entre GPIO3 et GND, sans résistance ; un appui active/désactive la navigation dans les tuiles |
| Touche 1 | 8 | interrupteur vers GND |
| Touche 2 | 18 | interrupteur vers GND |
| Touche 3 | 43 (TX) | interrupteur vers GND |
| Ruban LED (barre) | 44 (RX) | DIN du ruban de 4 pixels (résistance 330 Ω en série) |
| LED touche 1 | 14 | plot du dessous : anode → résistance → GPIO, cathode → GND |
| LED touche 2 | 16 | idem |
| LED touche 3 | 21 | idem |
| Voyant vert « allumé » | 38 | idem (LED verte) |
| (libres) | 15, 17, 39…42 | spare ; 3 est une broche de démarrage : à éviter |

**LED individuelles (plots 14 à 39 soudés en direct)** : les GPIO 14, 16, 21 et 38 sont choisis non consécutifs pour que deux
fils ne se touchent jamais (14 et 16 sont séparés par le plot 15, laissé vide). N'utilisez pas 19/20 (USB),
26 à 32 (mémoire flash), 33 à 37 (PSRAM octale sur beaucoup de modules), 45/46 (démarrage).
**Vérifiez sur votre carte que ces plots existent et leur position réelle avant de souder.**
Résistances : **470 Ω pour toutes les LED** (3,3 V : environ 2,5 à 3 mA en rouge, jaune, orange ou vert, ce qui suffit pour des LED
de 3 ou 5 mm, surtout « haute luminosité »). Une LED **bleue ou blanche** (chute de tension ≈ 3 V) serait presque éteinte :
préférez rouge / jaune / orange / vert, ou montez deux résistances de 470 Ω en parallèle (≈ 235 Ω) pour ces deux couleurs.
Exemple : touche 1 rouge, touche 2 orange, touche 3 jaune, voyant d'état vert. L'intensité se règle dans JCharles desktop ;
la couleur est celle de la LED soudée (le choix de couleur de touche dans l'application n'a plus d'effet).

**MOSFET IRLB8721 (optionnel)** : canal N « logic level », il s'ouvre bien avec 3,3 V sur la grille. Montage en interrupteur côté masse :
GPIO → résistance 100 Ω → grille ; grille → GND par 10 kΩ ; source → GND ; drain → cathode de la charge ; l'anode de la charge va au 5 V
(ou au 3,3 V). Il convient pour une LED bleue ou blanche alimentée en 5 V avec 470 Ω en série (≈ 4 mA), ou pour plusieurs LED
en parallèle sur une même sortie. Il est surdimensionné pour cet usage (un 2N7000 suffirait) mais fonctionne. Ne l'utilisez pas pour
couper la masse du ruban WS2812 (cela perturberait le signal de données), et ne le branchez au rétroéclairage de l'écran qu'après avoir
vérifié que la broche LED du module est bien l'anode ou la cathode du rétroéclairage. Le firmware n'a pas à changer : la sortie PWM
commande directement la grille.

Points d'attention :
- **Joystick et potentiomètre alimentés en 3,3 V** (pas en 5 V), sinon les entrées analogiques dépassent 3,3 V.
- **Ruban WS2812 alimenté en 5 V** (broche 5V de la carte) ; la sortie 3,3 V de la carte est limite pour ses
  entrées. Une diode (1N4001) en série sur le +5 V du ruban, ou un adaptateur de niveau (74AHCT125), fiabilise le signal.
- Courant : 8 LED à pleine puissance blanche peuvent dépasser 400 mA. Gardez des intensités modérées (valeurs par défaut) ;
  ajoutez un condensateur de 100 à 470 µF entre 5V et GND près du ruban.
- Le ruban WS2812 ne sert plus qu'à la barre sous l'écran : `LED_COUNT` (4 par défaut) se règle en tête du fichier.
- Les broches 43 et 44 portent le journal de démarrage de la puce : un appui sur la touche 3 pendant le démarrage est à éviter.
- Vérifiez sur la sérigraphie que la broche « 18 » existe bien sur votre carte. **Vérifiez aussi que la puce est un
  ESP32-S3** (l'annonce montre un marquage « C3 », qui n'a pas l'USB HID natif).

## Installation (Arduino IDE, core esp32 ≥ 3.0)
1. Bibliothèques : **LovyanGFX**, **ArduinoJson** (v7), **Adafruit NeoPixel**.
2. Carte : *ESP32S3 Dev Module* ; *USB Mode* : **USB-OTG (TinyUSB)** ; *USB CDC On Boot* : **Enabled** ;
   *Partition Scheme* : **Huge APP (3MB No OTA/1MB SPIFFS)** (le Bluetooth alourdit le programme : avec le schéma par défaut il
   tient à 1 Ko près et peut ne plus rentrer).
3. Téléverser `JC_Touch.ino`. Au premier démarrage, touchez les 4 flèches de calibration ; laissez le joystick au repos.

## Liaison USB ou Bluetooth (v0.4)
- La carte envoie clavier, souris et touches multimédia **par USB** (mode par défaut) **ou par Bluetooth Low Energy**.
- Choix dans JCharles desktop, page **Matériel**, carte « Liaison avec le PC » (câble USB branché) : la carte redémarre dans le nouveau mode.
  Sans PC : **maintenez les touches 1 et 2 en allumant la carte** pour basculer de mode ; l'écran affiche « Mode USB » ou « Mode Bluetooth ».
- Bluetooth : appairez une fois « HCD S3 Touch » (Windows > Paramètres > Bluetooth et appareils > Ajouter un appareil > Bluetooth).
  L'en-tête de l'écran affiche « USB » ou « BT » (bleu = connecté, gris = en attente).
- Le port USB reste actif dans les deux modes : JCharles desktop (menus, réglages) fonctionne toujours par le câble.
  Le Bluetooth ne transporte que clavier, souris et touches multimédia ; les actions « PC » (lancer un programme, volume exact,
  micro) ont besoin du câble et de JCharles desktop. Bluetooth Low Energy uniquement (pas de Bluetooth classique).
- Le code compile avec le core esp32 3.3.12 (vérifié) ; il n'a pas été essayé sur la carte.

## Fonctionnement des commandes
- **Calibrer l'écran** : action « Navigation et écran > Calibrer l'écran tactile » (sur un bouton ou une touche) ; suivez les flèches aux coins.
- **Navigation au joystick** : réglage « Naviguer dans les tuiles avec le joystick » (JCharles desktop, Matériel) ou action « Navigation et écran > Joystick : naviguer dans les tuiles » sur un bouton/une touche pour l'activer et la désactiver. Actif : un cadre blanc/cyan suit le joystick, un clic ouvre la tuile, un clic long (> 0,7 s) revient en arrière, « JOY » s'affiche dans l'en-tête. En butée gauche/droite, la page change. Dans les modes Pad 3D et Volume, le joystick garde sa fonction normale.
- **Touches physiques** : sans appui long défini, l'action part immédiatement ; avec un appui long, l'appui court
  part au relâchement. Modes de LED : éteinte, allumée pendant l'appui, bascule, veilleuse + pleine à l'appui.
- **Potentiomètre « volume USB »** : envoie des touches Volume + / − au fil du mouvement (comme un encodeur : la position du
  curseur ne correspond pas forcément au volume réel). « Volume exact » : l'appareil envoie `HCD_POT n` et JCharles desktop règle le volume.
- **Joystick** : *souris* (clic = clic gauche) ; *orbite* = Maj + molette maintenus pendant l'inclinaison, *déplacement* = molette
  maintenue ; le clic bascule orbite ↔ déplacement. Déplacer un objet (pas la vue) se fait avec l'outil Déplacer de Fusion et le mode souris.

## Protocole série (115200, lignes terminées par `\n`)

| PC → carte | Réponse |
|---|---|
| `HCD_PING` (toutes les secondes) | `HCD_PONG HCD-S3-TOUCH 0.3.0` |
| `HCD_MENU_GET` | `HCD_MENU_BEGIN n`, JSON compact sur une ligne, `HCD_MENU_END` |
| `HCD_MENU_PUT n` + n octets de JSON | `HCD_MENU_OK` ou `HCD_MENU_ERR cause` |
| `HCD_HW_PUT n` + n octets de JSON (réglages matériels) | `HCD_HW_OK` ou `HCD_HW_ERR cause` |
| `HCD_ICON_CLEAR` | `HCD_ICON_OK` |
| `HCD_ICON_PUT nom 4608` + 4608 octets RGB565 (little-endian) | `HCD_ICON_OK` ou `HCD_ICON_ERR cause` |
| `HCD_JOY_CAL` (recentrer le joystick) | `HCD_JOY_OK` |
| `HCD_LINK usb` ou `HCD_LINK ble` | `HCD_LINK_OK mode` (redémarrage si le mode change) |
| `HCD_LINK ?` | `HCD_LINK_IS usb` ou `ble` |
| `HCD_CAL` | `HCD_CAL_OK`, puis redémarrage |

Carte → PC : `HCD_EVT <id>` (bouton ou touche de type `pc`) ; `HCD_POT <0-100>` (potentiomètre en mode « volume exact »).

## Formats
- Menu (v3) : `cols` (3 ou 4), `keys` (3 touches : action + `led_color` + `led_mode`), `pages` → `items`
  (`label`, `color`, `icon`, `type` = `hotkey`, `text`, `media`, `pc`, `nav`, `folder` avec `pages`, `mode` = `pad` ou `volume`, `long`).
- Réglages matériels : `screen`, `led_status`, `led_keys`, `led_bar`, `bar_mode`, `bar_color`, `pot`, `pot_invert`, `joy`,
  `joy_speed`, `joy_dead`, `joy_inv_x`, `joy_inv_y`, `joy_sw`, `rot180`.

## Limites connues
- Tactile résistif : un seul doigt, donc **pas de pincement** ; le zoom se fait par la bande de droite du pad 3D.
- Rotation « 180° » du pad tactile : valeur à étalonner ; seuls X et Y sont possibles (pas Z).
- Texte tapé en clavier US ; icônes : ordre des octets RGB565 à confirmer à l'écran.
- Pas de licence indiquée sur le dépôt HackMan3D : contactez l'auteur avant de redistribuer un dérivé.

## Joystick : réglage et dépannage (v0.3.4)
1. Alimentez le module en **3,3 V** (jamais 5 V), manche **au repos** au démarrage ; ajoutez 100 µF entre 3V3 et GND près du joystick.
2. Moniteur série à 115200, envoyez `HCD_JOY_DBG 1` : la carte affiche `HCD_JOY brut X=… Y=… centre=… zone=…` (envoyez `HCD_JOY_DBG 0` pour arrêter).
   - Au repos, X et Y doivent rester proches du centre (≈ 1800 à 2300) ; le bruit au repos doit rester inférieur à ± 50.
   - Poussez à **droite** : si c'est X qui bouge, bon ; si c'est Y, cochez « Échanger les axes » (`joy_swap`).
   - Si le mouvement part dans le mauvais sens, cochez « Inverser l'axe horizontal » ou « vertical ».
   - Valeur bloquée à 0 ou 4095 au repos : fil débranché, module en 5 V ou mauvaise broche.
3. Le firmware recale le centre tout seul après 1,5 s de repos et agrandit la zone morte si le bruit est fort.
   « Recentrer le joystick » dans JCharles desktop relance la mesure.


## Mode programmation sans boutons BOOT/RESET (0.4.1)

- Sur la carte : maintenir les touches 1 et 3 et pousser le joystick à gauche 1,5 s (ou touches 1 et 3 seules 5 s) → la carte redémarre en mode
  chargeur (message à l'écran). Puis téléverser depuis l'Arduino IDE (un nouveau port COM apparaît).
- Depuis JCharles desktop : page Appareil > « Mode programmation (BOOT) » (commande série `HCD_BOOT`).
- Les icônes des tuiles sont affichées en dégradé, avec fond d'icône transparent (magenta 0xF81F réservé).

## Combinaisons touche + potentiomètre / joystick (0.5.0)

Menu JSON : `"combos":[{"key":0,"src":"pot","pot":"screen"},{"key":1,"src":"pot","pot":"mic"},{"key":0,"src":"left","do":{…}}]`.
Touche 1 maintenue + pot = luminosité écran ; touche 2 + pot = micro du PC (événement `HCD_POTMIC n`, exécuté par HCD Studio).
Une touche qui possède des combinaisons exécute son action au relâchement, sauf si une combinaison a été utilisée.
