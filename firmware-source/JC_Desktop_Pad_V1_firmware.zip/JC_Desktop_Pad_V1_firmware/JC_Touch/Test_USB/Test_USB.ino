// Test USB minimal : aucune autre broche utilisee.
// Reglages Outils : carte ESP32S3 Dev Module, USB CDC On Boot = Enabled,
// USB Mode = "Hardware CDC and JTAG", Flash Size = 4MB, PSRAM = Disabled.
void setup() {
  Serial.begin(115200);
}
void loop() {
  static int n = 0;
  Serial.printf("Test USB OK %d\n", n++);
  delay(1000);
}
