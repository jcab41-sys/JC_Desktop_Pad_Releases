# Câblage complet du pad HCD-S3-TOUCH (ESP32-S3 mini)

Firmware 0.7.2. Toutes les broches ci-dessous sont celles du fichier `JC_Touch.ino`.
Tous les **GND** sont reliés entre eux (une seule masse commune). Tout ce qui est en 3,3 V vient de la broche **3V3** de la carte.

## 1. Tableau général (par numéro de GPIO)

| GPIO | Rôle | Va vers | Remarque |
|---|---|---|---|
| 1 | Potentiomètre | curseur (point milieu) | extrémités du potentiomètre : 3V3 et GND |
| 2 | Joystick X | VRx | |
| 3 | Bouton « navigation joystick » (optionnel) | une patte du bouton, l'autre patte au GND | active/désactive la navigation dans les tuiles |
| 4 | Joystick Y | VRy | |
| 5 | Rétro-éclairage écran | LED (BL) de l'écran | réglé en PWM |
| 6 | Clic du joystick | SW | l'autre côté au GND |
| 7 | Tactile CS | T_CS | |
| 8 | Touche 1 | une patte de l'interrupteur MX | l'autre patte au GND |
| 9 | Écran DC | DC (ou RS) | |
| 10 | Écran CS | CS | |
| 11 | SPI MOSI | SDI (MOSI) **et** T_DIN | écran + tactile partagent le même fil |
| 12 | SPI SCK | SCK **et** T_CLK | écran + tactile partagent le même fil |
| 13 | SPI MISO | SDO (MISO) **et** T_DO | écran + tactile partagent le même fil |
| 14 | LED touche 1 | résistance 470 Ω puis LED (+) | patte (−) de la LED au GND |
| 16 | LED touche 2 | résistance 470 Ω puis LED (+) | |
| 18 | Touche 2 | une patte de l'interrupteur MX | l'autre patte au GND |
| 21 | LED touche 3 | résistance 470 Ω puis LED (+) | |
| 38 | Voyant vert « allumé » | résistance 470 Ω puis LED verte (+) | |
| 42 | Détection de charge (optionnel) | résistance 470 Ω puis plot CHRG du TP4056 | la LED verte respire pendant la charge |
| 43 (TX) | Touche 3 | une patte de l'interrupteur MX | l'autre patte au GND |
| 44 (RX) | Ruban LED | résistance 470 Ω vers la grille du MOSFET IRLB8721 (ruban COB) ou DIN (ruban WS2812) | voir `dessin_ruban_COB.png` |

Écran : **RESET** relié directement au 3V3 (pas de GPIO). Tactile : **T_IRQ** non raccordé.

## 2. Écran ILI9341 2,8" tactile (XPT2046)

| Broche du module | Va sur |
|---|---|
| VCC | 3V3 |
| GND | GND |
| CS | GPIO10 |
| RESET | 3V3 |
| DC / RS | GPIO9 |
| SDI (MOSI) | GPIO11 |
| SCK | GPIO12 |
| LED (rétro-éclairage) | GPIO5 |
| SDO (MISO) | GPIO13 |
| T_CLK | GPIO12 (même fil que SCK) |
| T_CS | GPIO7 |
| T_DIN | GPIO11 (même fil que SDI) |
| T_DO | GPIO13 (même fil que SDO) |
| T_IRQ | non raccordé |

## 3. Les 3 touches mécaniques MX
Chaque touche : une patte au GPIO (8, 18 ou 43), l'autre patte au GND. Aucune résistance : le firmware active les résistances internes.

## 4. LED (touches et voyant)
Même montage pour les 4 : GPIO → 470 Ω → patte longue (+) de la LED → patte courte (−) → GND. Voir `dessin_LED_simple.png`.
Touche 1 : GPIO14 · touche 2 : GPIO16 · touche 3 : GPIO21 · voyant vert : GPIO38.

## 5. Joystick et potentiomètre
- Joystick : VCC → 3V3, GND → GND, VRx → GPIO2, VRy → GPIO4, SW → GPIO6.
- Potentiomètre : une extrémité au 3V3, l'autre au GND, le curseur (milieu) au GPIO1.
- Bouton de navigation (optionnel) : GPIO3 → bouton → GND.

## 6. Ruban LED (GPIO44)
Ruban COB une couleur : GPIO44 → 470 Ω → grille du MOSFET IRLB8721 ; source au GND ; drain au moins (−) du ruban ; le plus (+) du ruban à l'alimentation 5 V. Voir `dessin_ruban_COB.png`. Dans le logiciel : Matériel > type de ruban « Simple ».

## 7. Alimentation sur batterie (optionnel)
La jauge de niveau de batterie a été retirée (0.14.2) : le GPIO17 est libre. Il reste la détection de charge (GPIO42).
Batterie LiPo → B+/B− du TP4056 protégé → OUT+ par un interrupteur → IN+ du MT3608 réglé à 5,1 V ; OUT− → IN− ; sortie du MT3608 : OUT+ → broche **5V** de l'ESP32, OUT− → **GND**. Voir `dessin_batterie_simple.png`.
Mettez l'interrupteur de la batterie sur arrêt quand la carte est branchée au PC en USB.

## 8. Broches à ne pas utiliser
- **Déjà prises** : 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 18, 21, 38, 42, 43, 44.
- **À éviter** : 0, 45, 46 (démarrage), 19 et 20 (USB), 26 à 37 (mémoire flash).
- **Encore libres** (si votre carte les expose) : 15, 17, 39, 40, 41, 47, 48.

## 9. Réglages Arduino IDE
ESP32S3 Dev Module · USB Mode : USB-OTG (TinyUSB) · USB CDC On Boot : Enabled · Partition : Huge APP (3MB No OTA/1MB SPIFFS). Pour programmer : touches 1 + 3 appuyées 5 s (ou joystick à gauche 1,5 s) met la carte en mode programmation.
