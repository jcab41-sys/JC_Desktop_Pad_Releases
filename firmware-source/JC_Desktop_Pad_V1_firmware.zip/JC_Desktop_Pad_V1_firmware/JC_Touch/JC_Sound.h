// =====================================================================================================
// JC_Sound.h — son du pad V2 : ampli I2S MAX98357A + petit haut-parleur.
// Câblage : BCLK -> GPIO 40, LRC -> GPIO 41, DIN -> GPIO 15, VIN -> 5 V, GND -> GND (SD et GAIN non reliés).
// Synthèse « 8 bits » faite ici (pas de fichiers) : une musique en boucle (mélodie + basse) et des bruitages.
// Une tâche FreeRTOS remplit l'ampli en continu ; les jeux et le minuteur appellent sfx() / musicPlay().
// Musique originale, composée pour le pad.
// =====================================================================================================
// Micro optionnel INMP441 (dictée Windows) : SCK -> GPIO 40 et WS -> GPIO 41 (mêmes fils que l'ampli), SD -> GPIO 1
// (à la place du potentiomètre), L/R -> GND, VDD -> 3V3. Le pad devient alors aussi un micro USB pour Windows.
// Micro actif : trames de 2 x 32 bits (format demandé par l'INMP441, accepté par le MAX98357A) ; sinon 16 bits comme avant.
#include <ESP_I2S.h>
#include <USB.h>
#include <USBAudioCard.h>

static const int PIN_I2S_BCLK = 40, PIN_I2S_LRC = 41, PIN_I2S_DIN = 15;
static const int PIN_MIC_SD = 1;
static USBAudioCard* uac = nullptr;
static volatile bool micStreaming = false;       // Windows enregistre (dictée ouverte)
static const int SND_RATE = 16000;

enum Sfx { SFX_JUMP, SFX_COIN, SFX_STOMP, SFX_HURT, SFX_WIN, SFX_OVER, SFX_EAT, SFX_ALARM, SFX_CLICK, SFX_START, SFX_BOOT };

struct SndSeg { uint16_t f0, f1, ms; uint8_t wave, vol; };   // wave : 0 carré, 1 triangle, 2 bruit
static const SndSeg SFX_TAB[][5] = {
  {{300, 760, 120, 0, 70}},                                                        // saut
  {{988, 988, 60, 0, 60}, {1319, 1319, 200, 0, 60}},                               // pièce
  {{220, 70, 110, 2, 80}},                                                         // ennemi écrasé
  {{500, 90, 420, 0, 80}},                                                         // touché
  {{523, 523, 110, 0, 70}, {659, 659, 110, 0, 70}, {784, 784, 110, 0, 70}, {1047, 1047, 380, 0, 70}},   // victoire
  {{392, 392, 180, 1, 90}, {330, 330, 180, 1, 90}, {262, 262, 180, 1, 90}, {196, 196, 500, 1, 90}},     // perdu
  {{600, 1000, 70, 0, 60}},                                                        // serpent mange
  {{880, 880, 160, 0, 80}, {0, 0, 90, 0, 0}, {880, 880, 160, 0, 80}, {0, 0, 90, 0, 0}, {1175, 1175, 300, 0, 80}},  // minuteur
  {{1500, 1200, 18, 0, 35}},                                                       // clic
  {{392, 392, 90, 0, 60}, {523, 523, 90, 0, 60}, {659, 659, 160, 0, 60}},          // départ
  {{1047, 1047, 70, 1, 55}, {0, 0, 40, 0, 0}, {1568, 1568, 110, 1, 55}},          // démarrage du pad (bip-bip doux)
};

// Musique du jeu de plateformes : 4 mesures en doubles croches (note MIDI, durée en 1/16) ; 0 = silence.
static const uint8_t TUNE_LEAD[] = {
  72, 2, 76, 2, 79, 2, 76, 2, 81, 4, 79, 4,
  77, 2, 81, 2, 79, 2, 76, 2, 74, 6, 0, 2,
  72, 2, 76, 2, 79, 2, 84, 2, 83, 4, 79, 4,
  77, 2, 76, 2, 74, 2, 71, 2, 72, 6, 0, 2,
};
static const uint8_t TUNE_BASS[] = {
  48, 4, 55, 4, 48, 4, 55, 4,
  53, 4, 60, 4, 55, 4, 50, 4,
  48, 4, 55, 4, 52, 4, 55, 4,
  53, 4, 55, 4, 43, 4, 48, 4,
};
static const int TUNE_16TH = SND_RATE * 60 / 140 / 4;   // 140 battements par minute

static I2SClass i2sOut;
static bool sndOk = false;
static volatile int sfxReq = -1;                 // bruitage demandé (lu par la tâche son)
static volatile bool musicOn = false;

static float midiHz(int n) { return n ? 440.0f * powf(2.0f, (n - 69) / 12.0f) : 0; }

static void sfx(Sfx s) { if (sndOk && hw.sound > 0) sfxReq = s; }
static void musicPlay(bool on) { musicOn = on && hw.music; }

static void soundTask(void*) {
  static int32_t buf[512];                      // stéréo 32 bits : chaque échantillon en double (gauche = droite)
  // voix bruitage
  int sId = -1, sSeg = 0; uint32_t sPos = 0, sLen = 0; float sPh = 0; uint32_t noise = 12345;
  // voix musique
  int lIx = 0, bIx = 0; uint32_t lLeft = 0, bLeft = 0; float lHz = 0, bHz = 0, lPh = 0, bPh = 0;
  bool wasMusic = false;
  uint32_t quiet = 0;
  for (;;) {
    int req = sfxReq;
    if (req >= 0) { sfxReq = -1; sId = req; sSeg = 0; sPos = 0; sLen = SFX_TAB[sId][0].ms * SND_RATE / 1000; }
    bool mus = musicOn && hw.music;
    if (mus && !wasMusic) { lIx = bIx = 0; lLeft = bLeft = 0; }
    wasMusic = mus;
    if (sId < 0 && !mus) {                       // rien à jouer : silence, peu de calcul
      if (quiet < 8) { memset(buf, 0, sizeof(buf)); i2sOut.write((uint8_t*)buf, micOn ? sizeof(buf) : sizeof(buf) / 2); quiet++; }
      else vTaskDelay(pdMS_TO_TICKS(10));
      continue;
    }
    quiet = 0;
    float master = hw.sound / 100.0f;
    for (int i = 0; i < 256; i++) {
      float out = 0;
      if (mus) {
        if (!lLeft) { lHz = midiHz(TUNE_LEAD[lIx]); lLeft = TUNE_LEAD[lIx + 1] * TUNE_16TH; lIx = (lIx + 2) % sizeof(TUNE_LEAD); }
        if (!bLeft) { bHz = midiHz(TUNE_BASS[bIx]); bLeft = TUNE_BASS[bIx + 1] * TUNE_16TH; bIx = (bIx + 2) % sizeof(TUNE_BASS); }
        lLeft--; bLeft--;
        uint32_t noteLen = TUNE_16TH * 2;
        float env = (lLeft % noteLen) > noteLen / 6 ? 1.0f : 0.35f;      // petite attaque à chaque note
        if (lHz > 0) { lPh += lHz / SND_RATE; if (lPh >= 1) lPh -= 1; out += (lPh < 0.25f ? 0.16f : -0.16f) * env; }
        if (bHz > 0) { bPh += bHz / SND_RATE; if (bPh >= 1) bPh -= 1; out += (bPh < 0.5f ? 4 * bPh - 1 : 3 - 4 * bPh) * 0.22f; }
      }
      if (sId >= 0) {
        const SndSeg& g = SFX_TAB[sId][sSeg];
        float t = sLen ? (float)sPos / sLen : 1;
        float hz = g.f0 + (g.f1 - (float)g.f0) * t;
        float v = g.vol / 100.0f * (1.0f - 0.6f * t);
        float smp = 0;
        if (g.vol && hz > 0) {
          sPh += hz / SND_RATE; if (sPh >= 1) sPh -= 1;
          if (g.wave == 0) smp = sPh < 0.5f ? 1 : -1;
          else if (g.wave == 1) smp = sPh < 0.5f ? 4 * sPh - 1 : 3 - 4 * sPh;
          else { noise ^= noise << 13; noise ^= noise >> 17; noise ^= noise << 5; smp = (noise & 0x8000) ? 1 : -1; }
        }
        out += smp * v * 0.45f;
        if (++sPos >= sLen) {
          sSeg++; sPos = 0;
          if (sSeg >= 5 || SFX_TAB[sId][sSeg].ms == 0) sId = -1;
          else sLen = SFX_TAB[sId][sSeg].ms * SND_RATE / 1000;
        }
      }
      int16_t v = (int16_t)(constrain(out * master, -1.0f, 1.0f) * 12000);
      if (micOn) { buf[2 * i] = (int32_t)v << 16; buf[2 * i + 1] = (int32_t)v << 16; }   // trames 32 bits (micro actif)
      else { ((int16_t*)buf)[2 * i] = v; ((int16_t*)buf)[2 * i + 1] = v; }               // trames 16 bits, comme avant      // même son à gauche et à droite : l'ampli le joue quel que soit son réglage
    }
    i2sOut.write((uint8_t*)buf, micOn ? sizeof(buf) : sizeof(buf) / 2);
  }
}

static void micEvent(void*, esp_event_base_t base, int32_t id, void* data) {
  if (base == ARDUINO_USB_AUDIO_CARD_EVENTS && id == ARDUINO_USB_AUDIO_CARD_INTERFACE_ENABLE_EVENT) {
    auto* d = (arduino_usb_audio_card_event_data_t*)data;
    if (d->interface_enable.interface == UAC_INTERFACE_MIC) micStreaming = d->interface_enable.enable;
  }
}

// Avant USB.begin() : ajoute le micro USB (mono, 16 kHz, 16 bits) si le réglage est actif.
static void micUsbSetup() {
  Preferences pr; pr.begin("hcd", true);
  micOn = pr.getBool("mic", false);
  pr.end();
  if (!micOn) return;
  uac = new USBAudioCard(SND_RATE, UAC_BPS_16, UAC_SPK_NONE, UAC_MIC_MONO);
  uac->onEvent(micEvent);
  uac->begin();
}

// Lit l'INMP441 (voie gauche, 24 bits dans 32) et l'envoie à Windows par l'USB, par blocs de 4 ms.
static void micTask(void*) {
  static int32_t raw[128];                       // 64 trames stéréo
  static int16_t pcm[64];
  float hpX = 0, hpY = 0;                        // filtre passe-haut : retire le décalage continu du micro
  for (;;) {
    if (!micStreaming) { vTaskDelay(pdMS_TO_TICKS(20)); continue; }
    size_t got = i2sOut.readBytes((char*)raw, sizeof(raw));
    int n = got / 8;
    for (int i = 0; i < n; i++) {
      float x = (float)(raw[2 * i] >> 8);        // échantillon 24 bits signé
      hpY = x - hpX + 0.995f * hpY; hpX = x;
      float y = hpY / 64.0f;                     // gain : 24 bits -> 16 bits x 4 (voix à distance de bureau)
      pcm[i] = (int16_t)constrain(y, -32767.0f, 32767.0f);
    }
    if (n && uac) uac->write(pcm, n * 2);
  }
}

static void soundBegin() {
  if (micOn) i2sOut.setPins(PIN_I2S_BCLK, PIN_I2S_LRC, PIN_I2S_DIN, PIN_MIC_SD);
  else i2sOut.setPins(PIN_I2S_BCLK, PIN_I2S_LRC, PIN_I2S_DIN);
  // Stéréo plutôt que mono : selon le module et sa broche SD, le MAX98357A joue la voie gauche, la droite ou
  // les deux ; en mono, l'ESP32 n'en remplit qu'une et l'ampli peut rester muet.
  sndOk = i2sOut.begin(I2S_MODE_STD, SND_RATE, micOn ? I2S_DATA_BIT_WIDTH_32BIT : I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO);
  if (sndOk) xTaskCreatePinnedToCore(soundTask, "son", 4096, nullptr, 2, nullptr, 0);
  if (sndOk && micOn) xTaskCreatePinnedToCore(micTask, "micro", 4096, nullptr, 3, nullptr, 0);
}
