# Câblage complet du JC Desktop Pad V2

Firmware **2.0.0** (`JC_Touch/JC_Touch.ino`, `#define JC_BOARD 2`) · logiciel **JCharles desktop 0.16.0**.
Toutes les broches ci-dessous sont celles du firmware. Les numéros sont ceux **imprimés sur la carte Freenove**.

> **Avant de souder :** vérifiez chaque fil au multimètre (continuité) et mesurez les tensions avant de brancher l'écran.
> **Une seule masse :** tous les **GND** sont reliés entre eux.
> **3V3 / 5 V :** « 3V3 » est la broche 3,3 V de la carte, « 5V » sa broche 5 V.

---

## 1. Vue d'ensemble : toutes les broches utilisées

| GPIO | Composant | Broche du composant | Remarque |
|---|---|---|---|
| 1 | Potentiomètre | curseur (patte du milieu) | facultatif, voir § 6 |
| 2 | Joystick | VRx | |
| 3 | Bouton navigation | une patte (l'autre au GND) | |
| 4 | Joystick | VRy | |
| 5 | Écran | LED (rétroéclairage) | réglé en PWM |
| 6 | Joystick | SW (clic) | |
| 7 | Mesure batterie | milieu du pont 2 × 100 kΩ | voir § 9 |
| 8 | Touche 1 (TTP223) | OUT | |
| 9 | Écran | DC/RS | |
| 10 | Écran | CS | |
| 11 | Écran + tactile | SDI (MOSI) **et** T_DIN | un seul fil pour les deux |
| 12 | Écran + tactile | SCK **et** T_CLK | un seul fil pour les deux |
| 13 | Tactile | T_DO | le SDO de l'écran n'est **pas** relié |
| 14 | LED touche 1 | 470 Ω puis LED (+) | |
| 15 | Ampli MAX98357A | DIN | |
| 16 | LED touche 2 | 470 Ω puis LED (+) | |
| 17 | Touche 3 (TTP223) | OUT | |
| 18 | Touche 2 (TTP223) | OUT | |
| 21 | LED touche 3 | 470 Ω puis LED (+) | |
| 38 | Voyant d'état (vert) | 470 Ω puis LED (+) | |
| 39 | Tactile | T_CS | |
| 40 | Ampli MAX98357A | BCLK | |
| 41 | Ampli MAX98357A | LRC | |
| 42 | Chargeur TP4056 | 470 Ω puis plot CHRG | facultatif, voir § 9 |
| 47 | Ruban LED | DIN (WS2812) ou grille du MOSFET (ruban simple) | voir § 8 |

**À ne jamais utiliser :**
- 0, 45 et 46 : broches lues au démarrage ;
- 19 et 20 : USB ;
- 35, 36 et 37 : réservées à la PSRAM ;
- 43 (TX) et 44 (RX) : reliées à la puce USB-série de la carte ;
- 48 : LED RVB de la carte.

**Broches encore libres :** aucune broche sûre. Prévenez avant d'ajouter un composant.

---

## 2. Carte ESP32-S3 Freenove (8 Mo flash, 8 Mo PSRAM)

- **Prise USB-C « OTG »** (reliée aux GPIO 19 et 20) : c'est celle à brancher au PC, pour l'usage normal et les mises à jour depuis le logiciel.
- **Autre prise USB-C** (puce USB-série) : seulement en secours, pour téléverser si la carte ne répond plus.
- Alimentation sur batterie : par la broche **5V**, voir § 9.

---

## 3. Écran LAFVIN 4,0" ST7796S 480 × 320 (connecteur de 14 broches)

| N° | Broche de l'écran | Va sur | Remarque |
|---|---|---|---|
| 1 | VCC | 3V3 | le module accepte 3,3 à 5 V (voir la note) |
| 2 | GND | GND | |
| 3 | CS | GPIO 10 | |
| 4 | RESET | 3V3 | relié en permanence, pas de GPIO |
| 5 | DC/RS | GPIO 9 | |
| 6 | SDI (MOSI) | GPIO 11 | |
| 7 | SCK | GPIO 12 | |
| 8 | LED | GPIO 5 | rétroéclairage |
| 9 | SDO (MISO) | **non relié** | voir la note |
| 10 | T_CLK | GPIO 12 | même fil que SCK |
| 11 | T_CS | **GPIO 39** | |
| 12 | T_DIN | GPIO 11 | même fil que SDI |
| 13 | T_DO | GPIO 13 | |
| 14 | T_IRQ | non relié | |

- **SDO non relié :** sur ces modules, la sortie SDO de l'écran peut rester active et brouiller le tactile, qui partage le fil MISO. Le firmware ne relit jamais l'écran.
- **Alimentation :** le 4" consomme plus que le 2,8" de la V1. Si la carte redémarre toute seule ou chauffe à pleine luminosité, passez le VCC de l'écran sur **5V**. Le module l'accepte, et ses signaux restent en 3,3 V.
- Le lecteur de carte SD au dos (SD_CS, SD_MOSI, SD_MISO, SD_SCK) n'est pas utilisé.

---

## 4. Touches sensitives TTP223 (× 3)

| Broche du module | Va sur |
|---|---|
| VCC | **3V3**, surtout pas 5 V : la sortie OUT enverrait du 5 V dans l'ESP32 |
| GND | GND |
| OUT | GPIO **8** (touche 1), **18** (touche 2), **17** (touche 3) |

- **Ponts A et B non soudés** (réglage d'usine) : la sortie est à l'état haut tant que le doigt est posé.
- **Si le pont A est soudé** (sortie inversée), choisissez « Mécaniques vers GND » dans le logiciel, Matériel > Écran > Touches 1 à 3.
- **Ne touchez pas les touches pendant la première demi-seconde** après l'allumage : le module se règle à ce moment-là.
- **Trop sensibles ?** Deux réglages :
  - dans le logiciel, Matériel > Écran > « Sensibilité TTP223 » : un toucher doit durer au moins ce temps (60 ms par défaut, jusqu'à 600 ms) pour compter, ce qui ignore les effleurements ;
  - sur le module, souder un petit condensateur (quelques pF, jusqu'à 50 pF) sur l'emplacement prévu entre la zone sensible et le GND : la puce elle-même devient moins sensible. Seul ce réglage matériel change vraiment la distance de détection.
- **Pose :** le module détecte le doigt à travers 1 à 3 mm de plastique imprimé. Collez-le sous le capot, sans trou.
- **Réveil :** les touches 1 et 2 réveillent le pad de la veille profonde.
- **Bascule USB ↔ Bluetooth :** après l'allumage, maintenez les touches 1 + 2 pendant 2 secondes, dans les 8 premières secondes.

---

## 5. Joystick (type PS2) et bouton de navigation

| Broche du joystick | Va sur |
|---|---|
| +5V / VCC | **3V3**, pas 5 V : les entrées analogiques de l'ESP32 ne supportent pas plus de 3,3 V |
| GND | GND |
| VRx | GPIO 2 |
| VRy | GPIO 4 |
| SW | GPIO 6 |

**Bouton de navigation :** un poussoir entre le **GPIO 3** et le **GND**, sans résistance (le firmware active la résistance interne). Il active ou coupe la navigation au joystick, et quitte les jeux.

---

## 6. Potentiomètre (facultatif)

- Une extrémité au **3V3**, l'autre au **GND**, le curseur (patte du milieu) au **GPIO 1**.
- **Sans potentiomètre :** reliez le GPIO 1 au GND, et choisissez « désactivé » dans Matériel > Potentiomètre. Le volume se règle alors avec le curseur de l'écran.

---

## 7. LED des touches et voyant d'état

Même montage pour les 4 LED : **GPIO → résistance 470 Ω → patte longue (+) de la LED, patte courte (−) → GND.**

| LED | GPIO |
|---|---|
| Touche 1 | 14 |
| Touche 2 | 16 |
| Touche 3 | 21 |
| Voyant vert « allumé » | 38 |

Les LED des touches peuvent éclairer les zones sensibles des TTP223 par l'arrière.

---

## 8. Ruban LED (GPIO 47)

**Ruban adressable WS2812 :**
- GPIO 47 → **résistance 330 Ω** → DIN du ruban ;
- 5V et GND du ruban sur le 5V et le GND.
- Dans le logiciel : Matériel > type de ruban « WS2812 ».

**Ruban simple d'une seule couleur (COB) :**
- GPIO 47 → **470 Ω** → grille (G) du MOSFET IRLB8721 ;
- source (S) au GND, drain (D) au moins (−) du ruban ;
- plus (+) du ruban au 5 V.
- Dans le logiciel : type de ruban « Simple ». Voir `dessin_ruban_COB_V2.png` (ruban WS2812 : `dessin_ruban_V2.png`).

Le ruban sert aussi à prévenir à la fin d'un minuteur (il clignote).

---

## 9. Batterie, charge et mesure du niveau

**Chaîne d'alimentation (comme en V1) :**
```
Accu LiPo ──► TP4056 protégé (B+ / B−)
                 OUT+ ──► interrupteur ──► IN+ du MT3608 (réglé à 5,1 V)
                 OUT− ─────────────────► IN−
              MT3608 : OUT+ ──► broche 5V de l'ESP32 ; OUT− ──► GND
```
- Réglez le MT3608 à **5,1 V** au multimètre **avant** de le relier à la carte.
- Mettez l'interrupteur de la batterie sur arrêt quand le pad est branché au PC en USB.
- Voir `dessin_batterie_V2.png` (batterie, charge et jauge sur un seul dessin).

**Détection de charge (facultative) :**
- **GPIO 42 → 470 Ω → plot CHRG du TP4056.**
- Pendant la charge, le voyant vert « respire » et la barre d'état affiche un éclair.
- À activer dans Matériel > Énergie.

**Mesure du niveau (nouveau en V2) :**
```
BAT+ du TP4056 ──► 100 kΩ ──┬──► GPIO 7
                            ├──► 100 nF ──► GND
                            └──► 100 kΩ ──► GND
```
- Prenez le + **côté accu** (BAT+ ou B+ du TP4056), pas sur la sortie 5 V.
- Le niveau en % s'affiche dans la barre d'état et sur l'horloge de veille.
- Sans ce pont, la jauge ne s'affiche pas. Si elle affiche n'importe quoi, décochez-la dans Matériel > Énergie.

---

## 10. Son : ampli I2S MAX98357A et haut-parleur

| Broche de l'ampli | Va sur |
|---|---|
| VIN | 5V |
| GND | GND |
| BCLK | GPIO **40** |
| LRC | GPIO **41** |
| DIN | GPIO **15** + résistance 10 kΩ vers GND |
| SD | non relié (ampli allumé) |
| GAIN | non relié (gain 9 dB) |
| sortie + / − | haut-parleur **4 ou 8 Ω**, 3 W maximum |

- **Résistance de 10 kΩ entre DIN et GND**, à souder sur le bornier de l'ampli : elle maintient le fil de
  données à zéro pendant le démarrage de la carte. Sans elle, le haut-parleur grésille à chaque allumage,
  surtout sur batterie (la carte met environ une demi-seconde à prendre la main sur ses broches).
- **Ne reliez jamais une borne du haut-parleur au GND :** les deux sorties de l'ampli sont actives.
- Volume et musique se règlent dans Matériel > Son et jeux.

---

## 11. Ordre de montage conseillé

1. Carte seule en USB (prise OTG) : téléverser le firmware et vérifier que le logiciel la reconnaît.
2. Écran et tactile : au premier allumage, calibrer le tactile en touchant les 4 coins au stylet.
3. Touches TTP223, LED et voyant.
4. Joystick, bouton de navigation, potentiomètre.
5. Ampli et haut-parleur.
6. Ruban LED.
7. Batterie : TP4056, MT3608 réglé à 5,1 V, pont de mesure, CHRG.

Après chaque étape, rallumez et testez avant de passer à la suivante.

## 12. Si quelque chose ne va pas au premier allumage

| Ce que vous voyez | Que faire |
|---|---|
| Écran en négatif (fond blanc au lieu de noir) | mettre `PANEL_INVERT` à `true` dans le firmware |
| Rouge et bleu inversés | mettre `c.rgb_order` à `true` |
| Le tactile répond à côté du doigt | refaire le calibrage (Matériel > Écran tactile) |
| Une touche TTP223 reste « appuyée » | vérifier le pont A ; régler « Touches 1 à 3 » dans Matériel > Écran |
| Joystick inversé | cocher l'inversion X ou Y dans Matériel > Joystick |
| Aucun son | vérifier BCLK / LRC / DIN et le volume dans Matériel > Son et jeux |
| Grésillement au démarrage | résistance de 10 kΩ manquante entre DIN et GND |
| Grésillement au lieu du son | erreur de branchement de l'ampli : BCLK et LRC inversés (BCLK → 40, LRC → 41), DIN mal enfoncé (→ 15), GND de l'ampli non relié au GND de l'ESP32, ou haut-parleur sur GND au lieu des bornes + / − de l'ampli. Si toujours muet : SD → VIN (5V) |
| La carte redémarre à pleine luminosité | passer le VCC de l'écran sur 5V (§ 3) |

## 13. Réglages de compilation

ESP32S3 Dev Module, avec les réglages suivants :
- **Flash Size : 8MB**, **PSRAM : OPI PSRAM** ;
- USB Mode : USB-OTG (TinyUSB), USB CDC On Boot : Enabled ;
- Partition Scheme : Huge APP.

En PlatformIO :
```
board_build.arduino.memory_type = qio_opi
board_upload.flash_size = 8MB
build_flags = -DJC_BOARD=2 -DARDUINO_USB_MODE=0 -DARDUINO_USB_CDC_ON_BOOT=1
board_build.partitions = huge_app.csv
```
Le dossier `JC_Touch` doit contenir `JC_Touch.ino`, `JC_Games.h`, `JC_Sound.h`, `JC_Weather.h` et `JC_Wifi.h`.

## Micro INMP441 (option, firmware 2.5.0)

| Broche INMP441 | Va sur | Remarque |
|---|---|---|
| VDD | 3V3 | pas le 5 V |
| GND | GND | |
| L/R | GND | voie gauche |
| SCK | GPIO 40 | même fil que BCLK de l'ampli |
| WS | GPIO 41 | même fil que LRC de l'ampli |
| SD | GPIO 1 | à la place du potentiomètre |

Dans le logiciel : Matériel > Son et jeux > « Micro INMP441 ». Le pad redémarre et Windows voit un micro USB
(câble USB seulement, pas en Bluetooth). Dictée : Win + H.
